import { Celebrity, Testimonial, EnagicOffice, WaterType } from './types';

export const CELEBRITIES: Celebrity[] = [
  {
    id: 'kohli',
    name: 'Virat Kohli',
    role: 'Elite Indian Cricketer & National Fitness Icon',
    quote: 'Understands that world-class athletic endurance requires peak cell hydration. He fuels his high-octane performance and intense training with premium alkaline antioxidant water to quickly flush out systemic lactic acid.',
    image: 'https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?auto=format&fit=crop&q=80&w=400&h=400',
  },
  {
    id: 'shetty',
    name: 'Shilpa Shetty',
    role: 'Leading Bollywood Actress & Holistic Yoga Advocate',
    quote: 'Attributes her ageless glowing skin complexion, daily system detoxification, and active yoga lifestyle to drinking rich, mineral-packed alkaline water, which neutralizes oxidative cellular stress.',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400&h=400',
  },
  {
    id: 'roshan',
    name: 'Hrithik Roshan',
    role: 'Acclaimed Bollywood Actor & Fitness Evangelist',
    quote: 'Integrates electrolyzed water into his highly disciplined daily workout regimes and muscle regeneration diets to sustain cellular energy, peak physical shape, and focus under demanding shoots.',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=400&h=400',
  },
  {
    id: 'gates',
    name: 'Bill Gates',
    role: 'Founder of Microsoft & Global Philanthropist',
    quote: 'Reportedly uses original Kangen Water devices in his smart estates worldwide to ensure the ultimate grade of purified drinking water and antioxidant cell nourishment.',
    image: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&q=80&w=400&h=400',
  },
  {
    id: 'beyonce',
    name: 'Beyoncé',
    role: 'Global Pop Icon & Record-Breaking Performer',
    quote: 'Considers ionizer systems essential for vocal purification and metabolic energy, maintaining pristine pH alkaline hydration as a fundamental staple of her intense stadium worldツアー runs.',
    image: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&q=80&w=400&h=400',
  },
  {
    id: 'trady',
    name: 'Tom Brady',
    role: '7-Time Super Bowl Champion & Hydration Expert',
    quote: 'Strictly bases his TB12 elite diet plan on supreme cellular alkalization and continuous pure water intake to counter physiological acid build-up and reduce joint inflammation.',
    image: 'https://images.unsplash.com/photo-1542909168-82c3e7fdca5c?auto=format&fit=crop&q=80&w=400&h=400',
  },
  {
    id: 'rdj',
    name: 'Robert Downey Jr.',
    role: 'Legendary Hollywood Oscar-Winning Actor',
    quote: 'Maintains active medical-grade Kangen systems directly inside his trailers on film locations to foster sharp mental clarity, toxin extraction, and continuous clean physical drive.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400&h=400',
  },
  {
    id: 'woods',
    name: 'Tiger Woods',
    role: 'Iconic Golf Champion & Athletic Veteran',
    quote: 'Enhances multi-day stamina and counters muscle fatigue by replenishing with rich active-hydrogen micro-clustered water throughout the heat of championship match play.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400&h=400',
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Marcus Vance',
    role: 'Marathon Runner & Trainer',
    location: 'San Diego, USA',
    text: 'Switching to Kangen Water was a game-changer for my training. The micro-clustered composition means faster cellular absorption. No heavy, sloshing feeling in my stomach, and my recovery times have decreased significantly.',
    rating: 5,
  },
  {
    id: '2',
    name: 'Dr. Evelyn Hiro',
    role: 'Wellness Clinic Director',
    location: 'Okinawa, Japan',
    text: 'Understanding biochemistry means knowing that high environmental acidity fuels inflammation. Our patients drinking the pH 9.5 molecular hydrogen-rich water report marked improvements in gastrointestinal comfort and radiant skin energy.',
    rating: 5,
  },
  {
    id: '3',
    name: 'Sarah Jenkins',
    role: 'Mother of Three & Health Coach',
    location: 'Sydney, Australia',
    text: 'The Kangen water machine pays for itself tenfold. I use the 11.5 pH Strong Water to wash oil-based pesticides off my fruits (the yellow residue that comes off is shocking!), the 6.0 pH Beauty Water for toning my skin, and the baby drinks 7.0 Clean Water. Truly versatile.',
    rating: 5,
  },
  {
    id: '4',
    name: 'Rajesh Sharma',
    role: 'Entrepreneur & Kangen Club Leader',
    location: 'Mumbai, India',
    text: 'Joining the Enagic marketing club transformed not just my health, but my financial future. Being able to refer partners globally. The 8-point commission plan is incredibly rewarding, and we hold daily Zoom calls to help teams succeed!',
    rating: 5,
  }
];

export const WATER_TYPES: WaterType[] = [
  {
    id: 'strong-kangen',
    name: 'Strong Kangen Water',
    ph: '11.5',
    color: '#1e3a8a', // Deep navy
    description: 'Highly alkaline water with strong solvent properties. It is not intended for drinking, but is a powerful, eco-friendly cleaner and emulsifier.',
    uses: [
      'Food preparation: Cleans fruits & vegetables of oil-based pesticides, herbicides, and insecticides.',
      'Eco cleaning: Dissolves grease, oil-based stains, and stubborn grime from kitchenware.',
      'Stain removal: Lifts coffee, oil, and organic stains from carpets, fabrics, and clothing.'
    ],
    imageDesc: 'Splashing fresh agricultural produce being deeply emulsified and cleansed'
  },
  {
    id: 'kangen-drinking',
    name: 'Kangen Drinking Water',
    ph: '8.5 - 9.5', // 8.5 - 9.5 range
    color: '#2563eb', // Royal blue
    description: 'Perfect for drinking, daily hydration, and restorative wellness cooking. It has an optimal negative ORP value and is packed with antioxidant molecular hydrogen.',
    uses: [
      'Optimal hydration: Extremely silky, easy to drink, absorbs instantly with micro-cluster attributes.',
      'Flavor enhancer: Draws out complete organic flavors in teas, coffees, broths, and soups.',
      'Plant nutrition: Ideal for watering acidic-sensitive household houseplants and garden vegetables.'
    ],
    imageDesc: 'Satisfying stream of crystal-clear alkaline water dropping into a clean drinking glass'
  },
  {
    id: 'clean-water',
    name: 'Clean Purified Water',
    ph: '7.0',
    color: '#10b981', // Emerald green
    description: 'Pure, neutral water fully filtered of chlorine, heavy contaminants, and organic odors. Ideal for young infants and structured medical regimens.',
    uses: [
      'Infant formula: Highly recommended for preparing baby milk formulas to prevent metabolic imbalances.',
      'Medication: Ensures rapid and safe absorption of prescription medications without altering chemistry.',
      'Daily meals: Safe, clean, and balanced pure drinking water.'
    ],
    imageDesc: 'An infant sleeping peacefully or drinking a bottle of pure, neutral formula'
  },
  {
    id: 'beauty-water',
    name: 'Beauty Water (Acidic)',
    ph: '6', // Beauty Water is pH 6
    color: '#eab308', // Warm yellow-gold
    description: 'Slightly acidic. Perfectly matches the natural pH of human skin and acts as a premium, chemical-free personal care tonic.',
    uses: [
      'Facial toning: Tightens pores, hydrates outer layers, and leaves skin remarkably soft and radiant.',
      'Hair health: Spray on hair after bathing to untangle knots, add a premium sheen, and calm the scalp.',
      'Glass cleaner: Polishes windows, mirrors, glass, and stainless steel without leaving cloudy streaks.'
    ],
    imageDesc: 'Water mist spraying onto a glowing, healthy, youthful skin texture'
  },
  {
    id: 'strong-acidic',
    name: 'Strong Acidic Water',
    ph: '2.5',
    color: '#dc2626', // Deep red
    description: 'Extremely powerful sanitary and antimicrobial agent. Not for drinking, but highly effective for sanitizing surfaces and personal hygiene without toxic bleach.',
    uses: [
      'Sanitizing: Quickly disinfects cutting boards, kitchen countertops, utensils, and bathroom fixtures.',
      'Hand hygiene: A chemical-free hand sanitizer that kills bacteria on contact.',
      'Commercial grade: Extensively used in premium Japanese hospitals and salons for skin cleansing and sterilization.'
    ],
    imageDesc: 'A sparkling clean, deeply sanitized medical environment or kitchen utensil'
  }
];

export const GLOBAL_OFFICES: EnagicOffice[] = [
  // 27 major countries and 42 locations
  { country: 'Japan', city: 'Tokyo (World Headquarters)', region: 'Asia-Pacific' },
  { country: 'Japan', city: 'Osaka Branch', region: 'Asia-Pacific' },
  { country: 'Japan', city: 'Okinawa (OEM Factory & Corporate Birthplace)', region: 'Asia-Pacific' },
  { country: 'USA', city: 'Los Angeles, California (US HQ)', region: 'Americas' },
  { country: 'USA', city: 'New York, New York', region: 'Americas' },
  { country: 'USA', city: 'Chicago, Illinois', region: 'Americas' },
  { country: 'USA', city: 'Seattle, Washington', region: 'Americas' },
  { country: 'USA', city: 'Honolulu, Hawaii', region: 'Americas' },
  { country: 'USA', city: 'Dallas, Texas', region: 'Americas' },
  { country: 'USA', city: 'Orlando, Florida', region: 'Americas' },
  { country: 'Canada', city: 'Vancouver, BC', region: 'Americas' },
  { country: 'Canada', city: 'Toronto, Ontario', region: 'Americas' },
  { country: 'Mexico', city: 'Monterrey', region: 'Americas' },
  { country: 'Brazil', city: 'São Paulo', region: 'Americas' },
  { country: 'Germany', city: 'Dusseldorf (Europe HQ)', region: 'Europe' },
  { country: 'France', city: 'Paris', region: 'Europe' },
  { country: 'Italy', city: 'Rome', region: 'Europe' },
  { country: 'UK', city: 'London', region: 'Europe' },
  { country: 'Romania', city: 'Brașov', region: 'Europe' },
  { country: 'Russia', city: 'Moscow', region: 'Europe' },
  { country: 'Australia', city: 'Sydney', region: 'Asia-Pacific' },
  { country: 'Australia', city: 'Brisbane', region: 'Asia-Pacific' },
  { country: 'Singapore', city: 'Singapore Regional Hub', region: 'Asia-Pacific' },
  { country: 'Malaysia', city: 'Kuala Lumpur', region: 'Asia-Pacific' },
  { country: 'India', city: 'Bangalore (India HQ)', region: 'Asia-Pacific' },
  { country: 'Thailand', city: 'Bangkok', region: 'Asia-Pacific' },
  { country: 'Philippines', city: 'Manila', region: 'Asia-Pacific' },
  { country: 'Hong Kong', city: 'Hong Kong Central', region: 'Asia-Pacific' },
  { country: 'Taiwan', city: 'Taipei', region: 'Asia-Pacific' },
  { country: 'South Korea', city: 'Seoul', region: 'Asia-Pacific' },
  { country: 'Indonesia', city: 'Jakarta', region: 'Asia-Pacific' },
  { country: 'Mongolia', city: 'Ulaanbaatar', region: 'Asia-Pacific' },
  { country: 'UAE', city: 'Dubai', region: 'Middle East & Africa' },
  { country: 'South Africa', city: 'Johannesburg', region: 'Middle East & Africa' }
];

export const HEALTH_BENEFITS = [
  {
    title: 'Active Molecular Hydrogen',
    icon: 'Zap',
    summary: 'A potent selective antioxidant',
    description: 'Kangen water is packed with molecular hydrogen (H2) gas. H2 acts as a powerful selective antioxidant capable of crossing cell membranes and the blood-brain barrier to reduce cellular oxidative stress and neutralize harmful free radicals.'
  },
  {
    title: 'Optimal pH Balance (Alkalization)',
    icon: 'Droplet',
    summary: 'Counteract systemic metabolic acidity',
    description: 'Diets heavy in processed foods, stress, and environmental toxins create severe chemical acidity in the human body. Alkaline water is highly alkaline, helping flush out acidic wastes and restore your natural, slightly alkaline homeostasis.'
  },
  {
    title: 'High Negative ORP',
    icon: 'ShieldAlert',
    summary: 'Superior anti-aging and anti-oxidation strength',
    description: 'Oxidation-Reduction Potential (ORP) measures anti-oxidizing power. While soda has a positive ORP of +400mV (highly aging), freshly ionized Kangen Water registers a massive negative ORP of up to -400mV to -800mV, serving as an exceptional cellular rejuvenator.'
  },
  {
    title: 'Micro-Clustered Molecule Structure',
    icon: 'Maximize',
    summary: 'Superior absorption and rapid cellular hydration',
    description: 'Standard tap and bottled waters contain large structural clusters of 15-26 molecules. Enagic machines restructure water into tiny micro-clusters of only 5-6 molecules. This allows water to absorb instantly into your tissues, maximizing nutritional intake and accelerating detox.'
  }
];
export const CHRONIC_DISEASES_INFO = {
  headline: "How pH and Hydration Intersect with Chronic Well-being",
  sub: "Restoring physiological balance directly addresses systemic biological stressors.",
  points: [
    {
      condition: "Acid Reflux & GERD",
      explanation: "Alkaline water at pH 8.8 permanently denatures pepsin (the primary stomach enzyme that drives reflux) and provides powerful acid-buffering capacities to calm esophageal issues."
    },
    {
      condition: "Inflammatory & Joint Pain",
      explanation: "Oxidative stress creates acidosis in joint cartilage, exacerbating rheumatoid concerns. Rich molecular hydrogen neutralizes free radicals, easing systemic swelling."
    },
    {
      condition: "Metabolic Challenges & Diabetes",
      explanation: "Active hydrogen-rich water helps lower lipid peroxidation, enhancing insulin sensitivity and lowering oxidative load which are primary triggers for diabetic complications."
    },
    {
      condition: "Chronic Fatigue",
      explanation: "Poor micro-cellular hydration leaves cellular mitochondria sluggish, building up lactic acid. Dynamic micro-clustered water enhances toxic disposal and boosts baseline cellular ATP."
    }
  ]
};

export interface CurrencyRate {
  code: string;
  symbol: string;
  rate: number; // rate against USD
  name: string;
}

export const SUPPORTED_CURRENCIES: CurrencyRate[] = [
  { code: 'USD', symbol: '$', rate: 1, name: 'United States Dollar' },
  { code: 'INR', symbol: '₹', rate: 83.3, name: 'Indian Rupee' },
  { code: 'EUR', symbol: '€', rate: 0.92, name: 'Euro' },
  { code: 'GBP', symbol: '£', rate: 0.79, name: 'British Pound' },
  { code: 'JPY', symbol: '¥', rate: 156.4, name: 'Japanese Yen' },
  { code: 'CAD', symbol: 'C$', rate: 1.36, name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', rate: 1.51, name: 'Australian Dollar' },
  { code: 'AED', symbol: 'AED ', rate: 3.67, name: 'UAE Dirham' },
  { code: 'SGD', symbol: 'S$', rate: 1.35, name: 'Singapore Dollar' }
];

// Official beautiful localized prices for Enagic water ionizers per currency
export const LOCALIZED_PRICES: Record<string, Record<string, { price: string; formatted: string }>> = {
  k8: {
    USD: { price: '$4,980', formatted: '$4,980' },
    INR: { price: '₹3,80,000', formatted: '₹3,80,000' },
    EUR: { price: '€4,660', formatted: '€4,660' },
    GBP: { price: '£3,980', formatted: '£3,980' },
    CAD: { price: 'C$6,780', formatted: 'C$6,780' },
    AUD: { price: 'A$7,480', formatted: 'A$7,480' },
    AED: { price: 'AED 18,280', formatted: 'AED 18,280' },
    SGD: { price: 'S$6,720', formatted: 'S$6,720' },
    JPY: { price: '¥778,000', formatted: '¥778,000' }
  },
  sd501: {
    USD: { price: '$3,980', formatted: '$3,980' },
    INR: { price: '₹3,40,000', formatted: '₹3,40,000' },
    EUR: { price: '€3,720', formatted: '€3,720' },
    GBP: { price: '£3,180', formatted: '£3,180' },
    CAD: { price: 'C$5,420', formatted: 'C$5,420' },
    AUD: { price: 'A$5,980', formatted: 'A$5,980' },
    AED: { price: 'AED 14,620', formatted: 'AED 14,620' },
    SGD: { price: 'S$5,380', formatted: 'S$5,385' },
    JPY: { price: '¥622,000', formatted: '¥622,000' }
  },
  super501: {
    USD: { price: '$5,980', formatted: '$5,980' },
    INR: { price: '₹4,40,000', formatted: '₹4,40,000' },
    EUR: { price: '€5,590', formatted: '€5,590' },
    GBP: { price: '£4,780', formatted: '£4,780' },
    CAD: { price: 'C$8,140', formatted: 'C$8,140' },
    AUD: { price: 'A$8,980', formatted: 'A$8,980' },
    AED: { price: 'AED 21,980', formatted: 'AED 21,980' },
    SGD: { price: 'S$8,080', formatted: 'S$8,080' },
    JPY: { price: '¥934,000', formatted: '¥934,000' }
  },
  jriv: {
    USD: { price: '$2,980', formatted: '$2,980' },
    INR: { price: '₹2,40,000', formatted: '₹2,40,000' },
    EUR: { price: '€2,790', formatted: '€2,790' },
    GBP: { price: '£2,380', formatted: '£2,380' },
    CAD: { price: 'C$4,060', formatted: 'C$4,060' },
    AUD: { price: 'A$4,480', formatted: 'A$4,480' },
    AED: { price: 'AED 10,950', formatted: 'AED 10,950' },
    SGD: { price: 'S$4,020', formatted: 'S$4,020' },
    JPY: { price: '¥466,000', formatted: '¥466,000' }
  },
  anespa: {
    USD: { price: '$1,980', formatted: '$1,980' },
    INR: { price: '₹2,20,000', formatted: '₹2,20,000' },
    EUR: { price: '€1,850', formatted: '€1,850' },
    GBP: { price: '£1,590', formatted: '£1,590' },
    CAD: { price: 'C$2,695', formatted: 'C$2,695' },
    AUD: { price: 'A$2,980', formatted: 'A$2,980' },
    AED: { price: 'AED 7,270', formatted: 'AED 7,270' },
    SGD: { price: 'S$2,670', formatted: 'S$2,670' },
    JPY: { price: '¥309,000', formatted: '¥309,000' }
  }
};

export function getProductPrice(productId: string, currencyCode: string): string {
  const modelPrices = LOCALIZED_PRICES[productId];
  if (modelPrices && modelPrices[currencyCode]) {
    return modelPrices[currencyCode].formatted;
  }
  const usdPriceStr = modelPrices?.['USD']?.price || '$3,000';
  const usdVal = parseInt(usdPriceStr.replace(/[^0-9]/g, ''), 10);
  const matchedCurr = SUPPORTED_CURRENCIES.find(c => c.code === currencyCode);
  if (matchedCurr) {
    const converted = Math.round(usdVal * matchedCurr.rate);
    return `${matchedCurr.symbol}${converted.toLocaleString()}`;
  }
  return usdPriceStr;
}

export function detectDefaultCurrency(): string {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "";
    const lang = (navigator.language || "").toLowerCase();

    // Check India first (IST timezone/Indian languages)
    if (
      tz.includes("Kolkata") || 
      tz.includes("Calcutta") || 
      tz.includes("Asia/Kolkata") || 
      tz.includes("Asia/Calcutta") ||
      lang.includes("in") ||
      lang.includes("hi")
    ) {
      return "INR";
    }

    // Check UK / GBP (London / Great Britain)
    if (tz.includes("London") || tz.includes("Europe/London") || lang.includes("gb")) {
      return "GBP";
    }

    // Check Japan / JPY (Tokyo)
    if (tz.includes("Tokyo") || tz.includes("Asia/Tokyo") || lang.includes("ja") || lang.includes("jp")) {
      return "JPY";
    }

    // Check Eurozone / EUR (Europe/Berlin, Europe/Paris, etc.)
    if (
      tz.includes("Paris") || 
      tz.includes("Berlin") || 
      tz.includes("Rome") || 
      tz.includes("Madrid") || 
      tz.includes("Brussels") || 
      tz.includes("Vienna") ||
      tz.includes("Europe/")
    ) {
      return "EUR";
    }

    // Check Canada / CAD (Toronto, Vancouver, Montreal)
    if (
      tz.includes("Toronto") || 
      tz.includes("Vancouver") || 
      tz.includes("Montreal") || 
      tz.includes("America/Toronto") ||
      lang.includes("ca")
    ) {
      return "CAD";
    }

    // Default to USD
    return "USD";
  } catch (e) {
    return "USD";
  }
}


