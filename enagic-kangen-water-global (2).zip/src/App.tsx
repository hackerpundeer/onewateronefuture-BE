/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navbar, { MainLogoSVG } from './components/Navbar';
import HomeView from './components/HomeView';
import ProductsView from './components/ProductsView';
import BenefitsView from './components/BenefitsView';
import AboutView from './components/AboutView';
import JoinView from './components/JoinView';
import ContactView from './components/ContactView';
import PrivacyPolicyView from './components/PrivacyPolicyView';
import TermsConditionsView from './components/TermsConditionsView';
import SourcesView from './components/SourcesView';
import { detectDefaultCurrency } from './data';
import { Droplet, Mail, Phone, Globe, ShieldCheck, Calendar, X, HeartPulse } from 'lucide-react';

const tabToPathMap: Record<string, string> = {
  'home': '/home',
  'about': '/about us',
  'benefits': '/alkaline & benifits',
  'sources': '/scients Research',
  'products': '/models & prices',
  'join': '/Business Opportunity',
  'contact': '/Contact-us',
  'privacy': '/privacy',
  'terms': '/terms'
};

const pathToTabMap: Record<string, string> = {
  '/home': 'home',
  '/about us': 'about',
  '/about%20us': 'about',
  '/alkaline & benifits': 'benefits',
  '/alkaline%20&%20benifits': 'benefits',
  '/scients Research': 'sources',
  '/scients%20Research': 'sources',
  '/models & prices': 'products',
  '/models%20&%20prices': 'products',
  '/Business Opportunity': 'join',
  '/Business%20Opportunity': 'join',
  '/Contact-us': 'contact',
  '/contact-us': 'contact',
  '/privacy': 'privacy',
  '/terms': 'terms'
};

export default function App() {
  const getTabFromUrl = (): string => {
    const rawPath = window.location.pathname;
    const decodedPath = decodeURIComponent(rawPath);
    return pathToTabMap[decodedPath] || 'home';
  };

  const [currentTab, setCurrentTab] = useState<string>(() => getTabFromUrl());
  const [isDemoModalOpen, setIsDemoModalOpen] = useState<boolean>(false);
  const [selectedCurrencyCode, setSelectedCurrencyCode] = useState<string>(() => detectDefaultCurrency());
  const [showScrollTop, setShowScrollTop] = useState<boolean>(false);

  // Sync state Changes back to the browser's address bar path
  useEffect(() => {
    const targetPath = tabToPathMap[currentTab] || '/home';
    const decodedCurrentPath = decodeURIComponent(window.location.pathname);
    if (decodedCurrentPath !== targetPath) {
      window.history.pushState(null, '', targetPath);
    }
  }, [currentTab]);

  // Scroll to top whenever the active tab changes to ensure smooth UX, especially on mobile devices
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [currentTab]);

  // Listen to browser Back/Forward (popstate) actions
  useEffect(() => {
    const handlePopState = () => {
      const tab = getTabFromUrl();
      setCurrentTab(tab);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 250) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const renderActiveView = () => {
    switch (currentTab) {
      case 'home':
        return <HomeView onNavigate={setCurrentTab} onOpenDemo={() => setIsDemoModalOpen(true)} />;
      case 'products':
        return <ProductsView selectedCurrencyCode={selectedCurrencyCode} />;
      case 'benefits':
        return <BenefitsView />;
      case 'sources':
        return <SourcesView />;
      case 'about':
        return <AboutView />;
      case 'contact':
        return <ContactView />;
      case 'privacy':
        return <PrivacyPolicyView />;
      case 'terms':
        return <TermsConditionsView />;
      case 'join':
        return <JoinView selectedCurrencyCode={selectedCurrencyCode} setSelectedCurrencyCode={setSelectedCurrencyCode} />;
      default:
        return <HomeView onNavigate={setCurrentTab} onOpenDemo={() => setIsDemoModalOpen(true)} />;
    }
  };

  return (
    <div id="enagic-app-wrapper" className="min-h-screen bg-[#f8fafc] text-slate-800 flex flex-col font-sans selection:bg-blue-600 selection:text-white relative overflow-x-hidden">
      
      {/* 1. Global Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        onOpenDemoModal={() => setIsDemoModalOpen(true)}
        selectedCurrencyCode={selectedCurrencyCode}
        setSelectedCurrencyCode={setSelectedCurrencyCode}
      />

      {/* 2. Main Content viewport */}
      <main className="flex-grow">
        {renderActiveView()}
      </main>


      {/* 3. Global Demonstration Booking Modal overlay - Fully updated to White Professional 3D style */}
      {isDemoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-905 bg-slate-900/60 backdrop-blur-md animate-fade-in overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl border border-slate-200 shadow-2xl text-slate-800">
            {/* Absolute close button */}
            <button
              id="close-modal-x-btn"
              onClick={() => setIsDemoModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-950 transition-colors cursor-pointer z-10"
            >
              <X className="h-5 w-5" />
            </button>
            <div className="max-h-[90vh] overflow-y-auto p-2">
              <ContactView isModal onClose={() => setIsDemoModalOpen(false)} />
            </div>
          </div>
        </div>
      )}

      {/* 4. Highly styled dynamic Footer - White Professional 3D style */}
      <footer id="app-footer" className="bg-white border-t border-slate-205 text-slate-500 text-xs py-12 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Col 1: Corporate Mission */}
          <div className="space-y-4 text-left">
            <div className="flex items-center space-x-2">
              <MainLogoSVG className="h-6 w-6 shrink-0" />
              <span className="font-extrabold text-slate-900 tracking-wider">ONE WATER ONE FUTURE.ORG</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-500 font-semibold">
              Delivering precise education on certified Japanese Enagic® Kangen Water® machines. We advocate for cellular hydration, active molecular hydrogen ionization, and global ecologic sustainability.
            </p>
            <p className="text-[10px] text-slate-450 font-mono">
              Empowering global communities with peer-reviewed medical and scientific research. <br />
              Independent international distributor resource hub.
            </p>
          </div>

          {/* Col 2: Navigation Shortcuts */}
          <div className="space-y-3 text-left">
            <h4 className="font-extrabold text-[#0f172a] uppercase tracking-wider text-[11px]">Quick Directory</h4>
            <ul className="space-y-2 text-[11.5px] font-bold">
              <li>
                <button onClick={() => setCurrentTab('home')} className="text-slate-500 hover:text-blue-600 transition-colors cursor-pointer text-left">
                  Home Overview
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('products')} className="text-slate-500 hover:text-blue-600 transition-colors cursor-pointer text-left">
                  Ionizer Machine Models
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('benefits')} className="text-slate-500 hover:text-blue-600 transition-colors cursor-pointer text-left">
                  Alkaline & Hydration Benefits
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('sources')} className="text-blue-600 hover:text-blue-700 transition-colors cursor-pointer text-left flex items-center space-x-1">
                  <span>🔬 Verified Scientific Sources</span>
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('join')} className="text-slate-500 hover:text-blue-600 transition-colors cursor-pointer text-left">
                  Join Patented 8-Point Club
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Referral Contact */}
          <div className="space-y-3 text-left">
            <h4 className="font-extrabold text-[#0f172a] uppercase tracking-wider text-[11px]">Global Partner Contacts</h4>
            <div className="space-y-2.5 text-[11.5px] font-bold">
              <a href="tel:+919555601611" className="flex items-center space-x-2 text-slate-500 hover:text-blue-600 transition-colors block">
                <Phone className="h-3.5 w-3.5 text-blue-600 shrink-0" />
                <span>+91 95556 01611 (Distributor)</span>
              </a>
              <a href="mailto:info@onewateronefuture.org" className="flex items-center space-x-2 text-slate-500 hover:text-blue-600 transition-colors block">
                <Mail className="h-3.5 w-3.5 text-blue-600 shrink-0" />
                <span>info@onewateronefuture.org</span>
              </a>
              <a href="https://enagic.com/" target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 text-slate-500 hover:text-blue-600 transition-colors block">
                <Globe className="h-3.5 w-3.5 text-blue-600 shrink-0" />
                <span>https://enagic.com/</span>
              </a>
            </div>
          </div>

          {/* Col 4: Consumer Privacy & Legal Agreements */}
          <div className="space-y-3 text-left">
            <h4 className="font-extrabold text-[#0f172a] uppercase tracking-wider text-[11px]">Consumer Protection & Legal</h4>
            <ul className="space-y-2 text-[11.5px] font-bold">
              <li>
                <button onClick={() => setCurrentTab('about')} className="text-slate-500 hover:text-blue-600 transition-colors cursor-pointer text-left">
                  About Us (Heritage)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('contact')} className="text-slate-500 hover:text-blue-600 transition-colors cursor-pointer text-left">
                  Contact Us (Demo Booking)
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('privacy')} className="text-slate-500 hover:text-blue-600 transition-colors cursor-pointer text-left flex items-center space-x-1">
                  <span>🛡️ Privacy Policy</span>
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('terms')} className="text-slate-500 hover:text-blue-600 transition-colors cursor-pointer text-left flex items-center space-x-1">
                  <span>⚖️ Terms & Conditions</span>
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Rights Bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10 pt-6 border-t border-slate-205 text-center flex flex-col sm:flex-row items-center justify-between text-[11px] font-semibold text-slate-450">
          <p>© 2026 Enagic® Distributors Network. All Rights Registered. Powered by One Water One Future.org.</p>
          <div className="flex items-center space-x-3 mt-3 sm:mt-0 font-bold">
            <ShieldCheck className="h-4 w-4 text-blue-600" />
            <span className="text-slate-500">ISO 9001, 14001, 13485 (Medical Device OEM) Compliant</span>
          </div>
        </div>
      </footer>

      {/* Floating Side Widgets */}

      {/* Left side Calendar booking icon - 2-hour gap slots */}
      <div className="fixed bottom-4 left-4 lg:bottom-6 lg:left-6 z-[9999] flex flex-col items-center">
        <button
          id="floating-booking-ball"
          onClick={() => setIsDemoModalOpen(true)}
          title="Schedule 2-hour Slot (11 AM to 9 PM)"
          className="h-10 w-10 sm:h-12 sm:w-12 lg:h-14 lg:w-14 rounded-full bg-blue-600 border border-blue-400 text-white flex items-center justify-center shadow-3d hover:shadow-3d-hover hover:scale-105 active:scale-95 transition-all outline-none animate-bounce cursor-pointer shrink-0"
        >
          <Calendar className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6" />
        </button>
        <span className="hidden lg:inline-block mt-1.5 px-2.5 py-1 bg-slate-900/80 text-white rounded-full text-[9px] font-mono font-black tracking-wider shadow-sm backdrop-blur-xs select-none">
          BOOK DEMO
        </span>
      </div>

      {/* Right side WhatsApp chat option */}
      <div className="fixed bottom-4 right-4 lg:bottom-6 lg:right-6 z-[9999] flex flex-col items-center">
        <a
          id="floating-whatsapp-bubble"
          href="https://wa.me/919555601611"
          target="_blank"
          rel="noopener noreferrer"
          title="Chat with Kangen expert on WhatsApp"
          className="h-10 w-10 sm:h-12 sm:w-12 lg:h-14 lg:w-14 rounded-full bg-emerald-500 border border-emerald-450 text-white flex items-center justify-center shadow-3d hover:shadow-3d-hover hover:scale-105 active:scale-95 transition-all outline-none cursor-pointer shrink-0"
        >
          <svg className="h-4 w-4 sm:h-5 sm:w-5 lg:h-6 lg:w-6 fill-current" viewBox="0 0 24 24">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.457L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.417 9.863-9.864.001-2.639-1.02-5.12-2.875-6.98C16.505 1.8 14.028 1.78 12.013 1.78c-5.43.001-9.849 4.42-9.852 9.867-.001 1.75.474 3.455 1.378 5.01L2.553 21.43l4.094-1.276z" />
          </svg>
        </a>
        <span className="hidden lg:inline-block mt-1.5 px-2.5 py-1 bg-emerald-600/90 text-white rounded-full text-[9px] font-mono font-black tracking-wider shadow-sm backdrop-blur-xs select-none">
          WHATSAPP CHAT
        </span>
      </div>

      {/* Back to Top button */}
      {showScrollTop && (
        <button
          id="floating-scroll-up-btn"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          title="Scroll to Top"
          className="fixed bottom-16 sm:bottom-20 lg:bottom-28 right-5 lg:right-8 z-[9999] h-8 w-8 sm:h-9 sm:w-9 lg:h-10 lg:w-10 rounded-full bg-slate-900 border border-slate-700 text-white flex items-center justify-center shadow-3d hover:shadow-3d-hover hover:scale-105 active:scale-95 transition-all outline-none cursor-pointer"
        >
          <svg className="h-4 w-4 sm:h-5 sm:w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" />
          </svg>
        </button>
      )}
    </div>
  );
}
