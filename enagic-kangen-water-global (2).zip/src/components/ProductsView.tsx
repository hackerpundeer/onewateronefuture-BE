import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Zap, Award, Sparkles, CheckCircle2, ChevronRight, HelpCircle, Layers, Droplet, Star, ShoppingBag, Eye, HeartPulse } from 'lucide-react';
import { getProductPrice } from '../data';

import k8Img from '../assets/images/hero_kangen_machine_1779402684165.png';
const sd501Img = k8Img;
const jrivImg = k8Img;
const super501Img = k8Img;

const PRODUCT_IMAGES: Record<string, string> = {
  k8: k8Img,
  sd501: sd501Img,
  super501: super501Img,
  jriv: jrivImg,
  anespa: 'https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&q=80&w=600'
};

interface ProductSpec {
  id: string;
  name: string;
  title: string;
  price: string;
  plates: string;
  phRange: string;
  orpMax: string;
  warranty: string;
  targetUser: string;
  description: string;
  rating: number;
  badge: string;
  color: string;
  features: string[];
}

export default function ProductsView({ selectedCurrencyCode = 'USD' }: { selectedCurrencyCode?: string }) {
  const [activeSubTab, setActiveSubTab] = useState<'catalog' | 'compare'>('catalog');
  const [selectedMainModel, setSelectedMainModel] = useState<string>('k8');

  // Realistic specifications for the complete Enagic range with dynamic pricing
  const products: ProductSpec[] = [
    {
      id: 'jriv',
      name: 'LeveLuk JRIV (Junior IV)',
      title: 'Eco-Friendly Energy Saver Compact Model',
      price: getProductPrice('jriv', selectedCurrencyCode),
      plates: '4 Solid Platinum-Plated Titanium Plates',
      phRange: '2.5 to 11.5 pH',
      orpMax: 'Up to -400 mV',
      warranty: '3 Years Full Warranty',
      targetUser: 'Singles, young couples, and eco-conscious compact apartments.',
      description: 'The JRIV is engineered with 4 solid plates to conserve energy while delivering high-quality alkaline hydration. A perfect, affordable entry-point with superb structural pH longevity.',
      rating: 4,
      badge: 'Eco Compact Choice',
      color: '#10b981', // Emerald
      features: [
        'Energy-saving design consuming significantly low baseline power',
        'Large-size liquid crystal display (LCD) with dynamic motion prompts',
        'Three-layered, high-powered water filter removing impurities & odors',
        'Generates stable, continuous strong acidic and strong Kangen water'
      ]
    },
    {
      id: 'sd501',
      name: 'LeveLuk SD501DX Advanced',
      title: 'Advanced Home Use Model with 7 Plates',
      price: getProductPrice('sd501', selectedCurrencyCode),
      plates: '7 Solid Platinum-Plated Titanium Plates',
      phRange: '2.5 to 11.5 pH',
      orpMax: 'Up to -700 mV',
      warranty: '5 Years Full Warranty',
      targetUser: 'Standard household nutrition & wellness enthusiasts.',
      description: 'The classic high-performance workhorse. The SD501DX features a massive electrolysis chamber with 7 platinum-dipped plates, generating continuous, highly stable alkaline Kangen water with clear voice guidance prompts in 8 languages.',
      rating: 5,
      badge: 'Advanced Legend',
      color: '#3b82f6', // Blue
      features: [
        'Eight-language display panels and clear spoken voice prompts',
        'Equipped with 7 electrode plates producing powerful active hydrogen',
        'Built-in expert electrolysis enhancer tank for stable strong solutions',
        'High-powered mechanical purification filter removing chlorine & rust'
      ]
    },
    {
      id: 'k8',
      name: 'LeveLuk K8 (Kangen 8)',
      title: 'The Ultimate Selective Antioxidant Powerhouse',
      price: getProductPrice('k8', selectedCurrencyCode),
      plates: '8 Solid Platinum-Plated Titanium Plates',
      phRange: '2.5 to 11.5 pH',
      orpMax: 'Up to -800 mV',
      warranty: '5 Years Full Warranty',
      targetUser: 'Health-focused families and elite athletic recovery homes.',
      description: 'The K8 is Enagic\'s flagship device. Equipped with 8 platinum-coated titanium plates, it delivers superior ionization, ultra-high antioxidant potential, and an intuitive multilingual touchscreen operating in 8 languages.',
      rating: 5,
      badge: 'Flagship Bestseller',
      color: '#06b6d4', // Cyan
      features: [
        'Large touch panel & multilingual voice prompts (8 Languages)',
        '8 Platinum-dipped Titanium plates for ultimate antioxidant power',
        'Dual automatic voltage power support (100-240V) for global travel',
        'Automatic smart self-cleaning filtration core with alarm'
      ]
    },
    {
      id: 'super501',
      name: 'LeveLuk Super 501',
      title: 'Top-of-the-Line High Volume Heavy-Duty Water System',
      price: getProductPrice('super501', selectedCurrencyCode),
      plates: '12 Solid Titanium Plates (5-Kangen, 7-Acidic)',
      phRange: '2.5 to 11.5 pH',
      orpMax: 'Up to -1200 mV',
      warranty: '5 Years Full Warranty',
      targetUser: 'Clinics, organic farms, busy restaurants, large corporate campuses.',
      description: 'This heavy-duty commercial unit features 12 solid plates divided into two separate chambers (one with 5 electrodes for drinking, one with 7 for strong acidic pH 2.5). Made of platinum-plated titanium for high-volume home and commercial duty cycles.',
      rating: 5,
      badge: 'Commercial Powerhouse',
      color: '#4f46e5', // Indigo
      features: [
        'Dual independent flexible right pipes targeting maximized simultaneous outputs',
        'Exclusive 2-chamber design (5 electrodes for drinking, 7 for strong acidic)',
        'Heavy-duty salt solution additive pump system for continuous sanitation water',
        'Excellent high-grade duty cycle prevents overheating during busy production'
      ]
    },
    {
      id: 'anespa',
      name: 'Anespa DX Home Spa',
      title: 'Mineral Ion Water Spa - Ultimate Hot Spring Experience',
      price: getProductPrice('anespa', selectedCurrencyCode),
      plates: 'Ceramic Purification Cartridge (No Plates)',
      phRange: 'Same as Tap Water (Mineral Enrichment)',
      orpMax: 'Mildly Alkaline Skin Protection',
      warranty: '3 Years Full Warranty',
      targetUser: 'Health lovers, skin/hair care enthusiasts, domestic bath and shower wellness.',
      description: 'The exclusive ANESPA DX Home Spa System transforms your ordinary bathroom into a natural hot spring resort. It produces a continuous stream of ionized mineral water using tufa, MIC, and power stones to moisturize skin and protect hair.',
      rating: 5,
      badge: 'Home Spa Resort',
      color: '#ec4899', // Pink
      features: [
        'Enriches water with therapeutic Tufa stone minerals from Radium Hot Spring',
        'MIC & Power stones generate negative-ions for radiant healthy skin and hair',
        'Larger deluxe ceramic cartridge removes almost 100% of residual chlorine',
        'Elegant redesigned base with simplified filter cartridge replacement'
      ]
    }
  ];

  const comparedModel = products.find(p => p.id === selectedMainModel) || products[0];

  return (
    <div id="products-view-root" className="pb-16 bg-gradient-to-tr from-slate-50 via-[#fafafc] to-slate-100 text-slate-800 space-y-12 relative overflow-hidden">
      
      {/* Abstract floating shapes for soft 3D visual depth */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[5%] right-[10%] w-96 h-96 bg-blue-400/5 rounded-full blur-3xl" />
        <div className="absolute bottom-[10%] left-[5%] w-80 h-80 bg-cyan-400/5 rounded-full blur-3xl" />
      </div>

      {/* 1. Introductory Title Section */}
      <section className="relative pt-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <span className="text-[10px] uppercase font-mono tracking-widest font-black text-blue-605 bg-blue-100/60 px-3.5 py-1.5 rounded-full border border-blue-200 shadow-xs">
            Certificated Enagic Water Systems
          </span>
          <h1 className="text-4xl font-extrabold tracking-tight leading-tight text-slate-900">
            Compare Original Ionizer Models <br />
            <span className="bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-600 bg-clip-text text-transparent italic font-serif text-3xl sm:text-4xl">
              Engaged in Therapeutic Longevity (Price in {selectedCurrencyCode})
            </span>
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm font-semibold max-w-2xl mx-auto leading-relaxed">
            Every Enagic device is hand-built from raw components inside our high-quality Osaka plant, certified as medical original equipment by the Japanese government.
          </p>
        </div>
      </section>

      {/* 2. Sub Navigation Tabs (Catalog Grid vs Compare Matrix) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-center">
          <div className="bg-white/80 backdrop-blur-md p-1.5 rounded-2xl border border-slate-200/80 shadow-3d flex space-x-1">
            <button
              id="product-subtab-catalog"
              onClick={() => setActiveSubTab('catalog')}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                activeSubTab === 'catalog'
                  ? 'bg-blue-600 text-white shadow-btn-3d'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <ShoppingBag className="h-4 w-4" />
              <span>Product Range</span>
            </button>
            <button
              id="product-subtab-compare"
              onClick={() => setActiveSubTab('compare')}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 cursor-pointer ${
                activeSubTab === 'compare'
                  ? 'bg-blue-600 text-white shadow-btn-3d'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Layers className="h-4 w-4" />
              <span>Interactive Compare Matrix</span>
            </button>
          </div>
        </div>
      </section>

      {/* 3. Render Catalog Range view */}
      {activeSubTab === 'catalog' && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((prod) => (
              <div
                key={prod.id}
                className="bg-white border border-slate-200/85 rounded-2xl p-6 sm:p-7 flex flex-col justify-between hover-lift hover-glow-blue relative group overflow-hidden"
              >
                {/* 3D Color Highlight Ribbon */}
                <div
                  className="absolute top-0 left-0 right-0 h-1.5 opacity-80"
                  style={{ backgroundColor: prod.color }}
                />

                <div className="space-y-5">
                  <div className="flex justify-between items-start">
                    <span className="px-2.5 py-0.5 rounded text-[9px] font-mono font-black uppercase tracking-wider text-white" style={{ backgroundColor: prod.color }}>
                      {prod.badge}
                    </span>
                    <div className="flex items-center text-yellow-500">
                      {[...Array(prod.rating)].map((_, i) => (
                        <Star key={i} className="h-3 w-3 fill-current" />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5 text-left">
                    <h3 className="text-xl font-extrabold text-slate-900">{prod.name}</h3>
                    <p className="text-xs font-semibold" style={{ color: prod.color }}>
                      {prod.title}
                    </p>
                  </div>

                  {/* Premium 3D shadow photo mockup - Made as a beautiful square box */}
                  <div className="w-full aspect-square rounded-xl relative border border-slate-200/60 overflow-hidden bg-slate-50/40 flex items-center justify-center p-4 group transition-all duration-300">
                    <img
                      referrerPolicy="no-referrer"
                      src={PRODUCT_IMAGES[prod.id] || k8Img}
                      alt={prod.name}
                      className="max-h-[75%] max-w-[75%] object-contain transform scale-100 group-hover:scale-105 transition-all duration-500 pb-2"
                    />
                    
                    {/* Glassmorphic info overlay representing 3D layer */}
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-900/10 via-transparent to-transparent p-2.5">
                      <div className="bg-white/95 backdrop-blur-md border border-slate-200/80 rounded-lg px-2.5 py-1 flex items-center justify-between w-full shadow-sm text-[10px] h-8.5 select-none font-bold">
                        <span className="font-mono text-slate-800">{prod.plates.includes('Cartridges') ? 'Organic Spa' : prod.plates.split(' ')[0] + ' Plates'}</span>
                        <span className="font-extrabold text-blue-600 uppercase font-mono">{prod.phRange}</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-slate-500 text-xs leading-relaxed text-left font-semibold">
                    {prod.description}
                  </p>

                  {/* Feature Bullets */}
                  <div className="border-t border-slate-100 pt-4 space-y-2 text-left">
                    {prod.features.map((feat, idx) => (
                      <div key={idx} className="flex items-start space-x-2">
                        <CheckCircle2 className="h-3.5 w-3.5 text-blue-500 shrink-0 mt-0.5" />
                        <span className="text-[11px] text-slate-650 font-medium leading-tight">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] text-slate-400 uppercase font-mono block">Enagic Direct Price</span>
                    <span className="text-lg font-black text-slate-900">{prod.price}</span>
                  </div>
                  <span className="inline-flex items-center space-x-1 px-3 py-1.5 bg-blue-50 hover:bg-blue-105 rounded-lg text-xs font-bold text-blue-600 transition-colors">
                    <span>{prod.warranty.split(' ')[0]} Yrs Warranty</span>
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Special Feature Comparison Note */}
          <div className="bg-white border border-slate-200/85 p-6 rounded-2xl shadow-3d grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-8 space-y-2 text-left">
              <h4 className="text-slate-900 font-extrabold text-lg flex items-center space-x-2">
                <HeartPulse className="h-5 w-5 text-blue-600 animate-pulse" />
                <span>Which machine matches your wellness requirements?</span>
              </h4>
              <p className="text-slate-500 text-xs font-semibold leading-relaxed">
                Check our side-by-side Matrix grid for accurate parameters. The elite LeveLuk K8 yields the ultimate antioxidant molecular load, whereas the classic SD501 provides robust gold standard continuous family alkalization support.
              </p>
            </div>
            <div className="lg:col-span-4 flex justify-end">
              <button
                id="cta-jump-matrix"
                onClick={() => setActiveSubTab('compare')}
                className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-btn-3d cursor-pointer"
              >
                Go to Comparison Matrix &rarr;
              </button>
            </div>
          </div>
        </section>
      )}

      {/* 4. Render Active spec comparison matrix */}
      {activeSubTab === 'compare' && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="bg-white border border-slate-200/85 rounded-2xl p-6 sm:p-8 shadow-3d text-slate-800 space-y-6">
            <div className="border-b border-slate-150 pb-5 text-left">
              <span className="text-[10px] uppercase font-mono tracking-wider text-blue-600 font-bold block mb-1">
                SIDE-BY-SIDE PLATINUM CALIBRATION SYSTEM
              </span>
              <h2 className="text-2xl font-black text-slate-900">
                Interactive Comparison Matrix
              </h2>
              <p className="text-xs text-slate-500 font-semibold mt-1">
                Compare plates, biological parameters, potential outputs, and precise target use ranges side-by-side. 
              </p>
            </div>

            {/* Desktop and Tablet Comparison Matrix Table (Fully responsive scroll wrapper) */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[700px] text-xs font-sans">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/50">
                    <th className="p-4 font-extrabold text-slate-950 uppercase tracking-widest text-[10px]">Specification</th>
                    {products.map(p => (
                      <th key={p.id} className="p-4 font-black text-slate-900 border-l border-slate-100" style={{ minWidth: '150px' }}>
                        <div className="flex flex-col">
                          <span className="font-extrabold text-slate-900 block truncate">{p.name.split(' (')[0]}</span>
                          <span className="text-[9px] text-blue-600 block leading-none font-bold mt-1">{p.badge}</span>
                          <span className="text-sm font-black text-slate-950 block mt-1">{p.price}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="p-4 font-bold text-slate-700 bg-slate-50/20">Electrolysis Plates</td>
                    {products.map(p => (
                      <td key={p.id} className="p-4 border-l border-slate-100 font-semibold text-slate-600">{p.plates}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-4 font-bold text-slate-700 bg-slate-50/20">pH Range Output</td>
                    {products.map(p => (
                      <td key={p.id} className="p-4 border-l border-slate-100 font-mono font-bold text-slate-900">{p.phRange}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-4 font-bold text-slate-700 bg-slate-50/20">Max Oxidation reduction potential (ORP)</td>
                    {products.map(p => (
                      <td key={p.id} className="p-4 border-l border-slate-100 font-semibold text-[#ef4444]" style={{ color: p.orpMax.includes('-') ? '#0891b2' : undefined }}>
                        {p.orpMax}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-4 font-bold text-slate-700 bg-slate-50/20">Certified Warranty</td>
                    {products.map(p => (
                      <td key={p.id} className="p-4 border-l border-slate-100 font-semibold text-slate-600 font-sans">{p.warranty}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-4 font-bold text-slate-700 bg-slate-50/20">Recommended Target Family use</td>
                    {products.map(p => (
                      <td key={p.id} className="p-4 border-l border-slate-100 font-semibold text-slate-500 leading-snug">{p.targetUser}</td>
                    ))}
                  </tr>
                  <tr>
                    <td className="p-4 font-bold text-slate-700 bg-slate-50/20">Exclusive Core Advantages</td>
                    {products.map(p => (
                      <td key={p.id} className="p-4 border-l border-slate-100 font-semibold text-slate-650 font-sans leading-relaxed">
                        <ul className="list-disc pl-4 space-y-1">
                          {p.features.slice(0, 2).map((f, i) => (
                            <li key={i}>{f}</li>
                          ))}
                        </ul>
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="pt-4 border-t border-slate-150 flex flex-col sm:flex-row items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>*All metrics conform fully to factory calibrated Enagic Japanese standard checks.</span>
              <span>Registered medical device compliance.</span>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
