import React, { useState, useEffect } from 'react';
import { DemoBookingInput } from '../types';
import { Calendar, Clock, Video, User, Mail, Phone, MapPin, Globe } from 'lucide-react';

interface ContactViewProps {
  onClose?: () => void;
  isModal?: boolean;
}

export default function ContactView({ onClose, isModal = false }: ContactViewProps) {
  const [inputs, setInputs] = useState<DemoBookingInput>({
    fullName: '',
    email: '',
    phone: '',
    country: '',
    demoType: 'zoom',
    preferredDate: '',
    preferredTime: '',
    message: ''
  });

  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [appliedDemoCount, setAppliedDemoCount] = useState<number>(0);

  useEffect(() => {
    const records = localStorage.getItem('kangen_scheduled_demos');
    if (records) {
      try {
        const parsed = JSON.parse(records);
        if (Array.isArray(parsed)) {
          setAppliedDemoCount(parsed.length);
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, [isSuccess]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setInputs((prev) => ({ ...prev, [name]: value }));
  };

  const handleApplyBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputs.fullName || !inputs.email || !inputs.phone || !inputs.preferredDate || !inputs.preferredTime) {
      alert('Please fill out all required fields');
      return;
    }

    const booking = {
      ...inputs,
      scheduledAt: new Date().toISOString(),
      id: Math.random().toString(36).substring(2, 11)
    };

    const existingStr = localStorage.getItem('kangen_scheduled_demos');
    let existing = [];
    if (existingStr) {
      try {
        existing = JSON.parse(existingStr);
        if (!Array.isArray(existing)) {
          existing = [];
        }
      } catch (e) {
        existing = [];
      }
    }

    existing.push(booking);
    localStorage.setItem('kangen_scheduled_demos', JSON.stringify(existing));
    setIsSuccess(true);
  };

  const contactInfoSection = (
    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4 text-left">
      <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest font-mono">
        Direct Help Desk & Sourcing
      </h3>
      <p className="text-xs text-slate-550 font-semibold leading-relaxed">
        Speak directly with a certified healthy water advisor to verify installation queries, shipping rates, and point system commissions.
      </p>
      
      <div className="space-y-3 pt-1">
        {/* Telephone */}
        <a 
          href="tel:+919555601611" 
          className="flex items-center space-x-3 p-3 bg-white border border-slate-150 rounded-xl hover:border-blue-400 hover:shadow-md hover:-translate-y-0.5 hover:scale-[1.02] transition-all block"
        >
          <div className="h-9 w-9 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Phone className="h-4.5 w-4.5" />
          </div>
          <div>
            <span className="text-[9px] text-slate-400 block uppercase tracking-wider font-extrabold font-mono">Call / WhatsApp Reservation</span>
            <span className="text-xs font-black text-slate-900">+91 95556 01611</span>
          </div>
        </a>

        {/* Email */}
        <a 
          href="mailto:info@onewateronefuture.org" 
          className="flex items-center space-x-3 p-3 bg-white border border-slate-150 rounded-xl hover:border-blue-400 hover:shadow-md hover:-translate-y-0.5 hover:scale-[1.02] transition-all block"
        >
          <div className="h-9 w-9 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <Mail className="h-4.5 w-4.5" />
          </div>
          <div>
            <span className="text-[9px] text-slate-400 block uppercase tracking-wider font-extrabold font-mono">Official Support Mail</span>
            <span className="text-xs font-black text-slate-900">info@onewateronefuture.org</span>
          </div>
        </a>

        {/* Official Reference */}
        <a 
          href="https://enagic.com/" 
          target="_blank" 
          rel="noopener noreferrer" 
          className="flex items-center space-x-3 p-3 bg-white border border-slate-150 rounded-xl hover:border-blue-400 hover:shadow-md hover:-translate-y-0.5 hover:scale-[1.02] transition-all block"
        >
          <div className="h-9 w-9 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <Globe className="h-4.5 w-4.5" />
          </div>
          <div>
            <span className="text-[9px] text-slate-400 block uppercase tracking-wider font-extrabold font-mono">Corporate Portal Reference</span>
            <span className="text-xs font-black text-slate-900">enagic.com &rarr;</span>
          </div>
        </a>
      </div>
    </div>
  );

  const corporateHeadquartersSection = (
    <div className="bg-white border border-slate-205 rounded-2xl p-6 sm:p-8 shadow-3d space-y-5 text-left font-sans">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
        <div>
          <span className="text-[10px] uppercase font-mono tracking-widest text-[#ea580c] bg-orange-50 border border-orange-200 px-3 py-1 rounded-full select-none inline-block font-black">
            Office Directories (PDF Page 3)
          </span>
          <h3 className="text-lg sm:text-xl font-black text-slate-900 mt-2">
            Corporate Headquarters Presence
          </h3>
        </div>
        <p className="text-[10px] text-slate-400 font-mono font-bold tracking-wider uppercase">Authorized Distributor Association Registry</p>
      </div>
      
      <p className="text-xs text-slate-500 font-semibold leading-relaxed">
        Direct authorized distributor orders, support tickets, and physical demonstrations are processed at these regional executive centers:
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-1">
        {/* Osaka */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 flex items-start space-x-3.5 hover:border-blue-400 transition-colors">
          <div className="h-10 w-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-xs text-lg select-none">
            🇯🇵
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-black text-slate-905 text-slate-900">
              Osaka Corporate Sales Center (Japan)
            </h4>
            <p className="text-[11px] text-slate-600 font-semibold leading-relaxed">
              Shin Osaka Yachiyo - BLDG 1F-AB 4Chome 1-45, Miyahara<br />
              Yodogawa-Ku, Osaka-City, Osaka-City, Japan
            </p>
          </div>
        </div>

        {/* India */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 flex items-start space-x-3.5 hover:border-emerald-400 transition-colors">
          <div className="h-10 w-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-xs text-lg select-none">
            🇮🇳
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-black text-slate-905 text-slate-900">
              India National Corporate Office (Bangalore)
            </h4>
            <p className="text-[11px] text-slate-605 text-slate-600 font-semibold leading-relaxed">
              The Millenia Tower B, 4th Floor, Unit 401, No, 1 and 2,<br />
              Murphy Road, Ulsoor, Bangalore 560-008 India
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const mainFormBody = (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <span className="text-[10px] uppercase font-mono tracking-widest text-blue-605 text-blue-650 font-black bg-blue-50 border border-blue-200 px-3 py-1 rounded-full select-none inline-block">
          Interactive Live Calendar Demonstration
        </span>
        <h2 className="text-2xl font-black text-slate-900">Book Machine Presentation</h2>
        <p className="text-xs text-slate-500 leading-relaxed max-w-md mx-auto font-semibold">
          Secure an executive slot with 2-hour buffer separations. We will demonstrate pH levels, oxidation status, and chemical-free oil emulsification.
        </p>
      </div>

      {isSuccess ? (
        <div className="text-center py-6 space-y-4 bg-slate-50 border border-slate-200 rounded-xl">
          <div className="h-10 w-10 rounded-full bg-emerald-100 border border-emerald-450 text-emerald-650 flex items-center justify-center mx-auto text-base font-bold animate-pulse">
            ✓
          </div>
          <div className="space-y-1">
            <h3 className="font-extrabold text-slate-950 text-base">Demonstration Scheduled!</h3>
            <p className="text-xs text-slate-500 px-5 leading-relaxed font-semibold">
              Excellent! **{inputs.fullName}**, your spot for a **{inputs.demoType === 'zoom' ? 'Virtual Zoom Presentation' : inputs.demoType === 'in-person' ? 'Home Visit Demo' : 'Office VIP Consultation'}** is successfully locked.
            </p>
          </div>
          <div className="bg-white border border-slate-200/80 mx-auto max-w-sm p-4 rounded-xl text-left text-xs text-slate-605 font-mono space-y-1 font-semibold shadow-inner">
            <p className="text-slate-500"><strong>Preferred Date:</strong> <span className="text-slate-900">{inputs.preferredDate}</span></p>
            <p className="text-slate-500"><strong>Schedule Slot:</strong> <span className="text-slate-900">{inputs.preferredTime}</span></p>
            <p className="text-slate-500"><strong>Sourcing Scope:</strong> <span className="text-slate-900 font-sans text-[11px]">Enagic 27 Countries Alliance</span></p>
            <p className="text-slate-500"><strong>Assigned Lead:</strong> <span className="text-blue-600">Local Area Distributor</span></p>
          </div>
          <p className="text-[10px] text-slate-400 italic font-bold">Check your dispatch email ({inputs.email}) for interactive Zoom coordinates.</p>

          <div className="flex justify-center space-x-3 pt-2 font-sans">
            <button
              id="reset-demo-booking-btn"
              onClick={() => {
                setIsSuccess(false);
                setInputs({
                  fullName: '',
                  email: '',
                  phone: '',
                  country: '',
                  demoType: 'zoom',
                  preferredDate: '',
                  preferredTime: '',
                  message: ''
                });
              }}
              className="px-4 py-2 bg-white border border-slate-205 text-slate-600 rounded-lg text-xs font-bold cursor-pointer hover:bg-slate-50 transition-colors shadow-xs"
            >
              Request Another
            </button>
            {onClose && (
              <button
                id="close-success-demo"
                onClick={onClose}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-extrabold cursor-pointer shadow-btn-3d"
              >
                Close Portal
              </button>
            )}
          </div>
        </div>
      ) : (
        <form onSubmit={handleApplyBooking} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Full Name */}
            <div className="space-y-1.5 font-sans">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-505 block">Your Full Name *</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <User className="h-3.5 w-3.5 text-slate-400" />
                </span>
                <input
                  type="text"
                  required
                  name="fullName"
                  value={inputs.fullName}
                  onChange={handleInputChange}
                  placeholder="e.g. Chetan Singh"
                  className="w-full text-xs font-semibold bg-white border border-slate-201 rounded-lg pl-9 pr-3 py-2.5 text-slate-800 focus:outline-none focus:border-blue-500 placeholder:text-slate-400 shadow-sm"
                />
              </div>
            </div>

            {/* Email */}
            <div className="space-y-1.5 font-sans">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-505 block">Email Address *</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <Mail className="h-3.5 w-3.5 text-slate-400" />
                </span>
                <input
                  type="email"
                  required
                  name="email"
                  value={inputs.email}
                  onChange={handleInputChange}
                  placeholder="name@domain.com"
                  className="w-full text-xs font-semibold bg-white border border-slate-201 rounded-lg pl-9 pr-3 py-2.5 text-slate-800 focus:outline-none focus:border-blue-500 placeholder:text-slate-400 shadow-sm"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Phone */}
            <div className="space-y-1.5 font-sans">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-505 block">Phone/WhatsApp *</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <Phone className="h-3.5 w-3.5 text-slate-400" />
                </span>
                <input
                  type="tel"
                  required
                  name="phone"
                  value={inputs.phone}
                  onChange={handleInputChange}
                  placeholder="+91 95556 01611"
                  className="w-full text-xs font-semibold bg-white border border-slate-201 rounded-lg pl-9 pr-3 py-2.5 text-slate-800 focus:outline-none focus:border-blue-500 placeholder:text-slate-400 shadow-sm"
                />
              </div>
            </div>

            {/* Country */}
            <div className="space-y-1.5 font-sans">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-505 block">Residence Country *</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <MapPin className="h-3.5 w-3.5 text-slate-400" />
                </span>
                <input
                  type="text"
                  required
                  name="country"
                  value={inputs.country}
                  onChange={handleInputChange}
                  placeholder="e.g. India, USA, UAE..."
                  className="w-full text-xs font-semibold bg-white border border-slate-201 rounded-lg pl-9 pr-3 py-2.5 text-slate-800 focus:outline-none focus:border-blue-500 placeholder:text-slate-400 shadow-sm"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-semibold">
            {/* Preferred Model */}
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Preferred Machine Model *</label>
              <select
                key="preferredModel"
                name="preferredModel"
                defaultValue="k8"
                className="w-full text-xs font-bold bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:outline-none focus:border-blue-500 shadow-sm"
              >
                <option value="k8">LeveLuk K8 Flagship (8 Plates)</option>
                <option value="sd501">LeveLuk SD501DX Advanced (7 Plates)</option>
                <option value="jriv">LeveLuk JRIV Eco Compact (4 Plates)</option>
                <option value="super501">LeveLuk Super 501 Commercial (12 Plates)</option>
                <option value="anespa">Anespa DX Mineral Home Spa System</option>
              </select>
            </div>

            {/* Prior Experience */}
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Prior Alkaline Water Experience? *</label>
              <select
                key="experience"
                name="experience"
                defaultValue="never"
                className="w-full text-xs font-bold bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:outline-none focus:border-blue-500 shadow-sm"
              >
                <option value="never">No, I have never tried Kangen Water</option>
                <option value="few">Yes, I have tasted it a few times</option>
                <option value="regular">Yes, I drink restructured water regularly</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-semibold">
            {/* Demo Type */}
            <div className="space-y-1.5 sm:col-span-1">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Demonstration Type *</label>
              <select
                name="demoType"
                value={inputs.demoType}
                onChange={handleInputChange}
                className="w-full text-xs font-bold bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:outline-none focus:border-blue-500 shadow-sm"
              >
                <option value="zoom">Virtual Zoom (Live)</option>
                <option value="in-person">In-Person Home Visit</option>
                <option value="office-visit">Physical Office Visit</option>
              </select>
            </div>

            {/* Date */}
            <div className="space-y-1.5 sm:col-span-1">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Preferred Date *</label>
              <input
                type="date"
                required
                name="preferredDate"
                value={inputs.preferredDate}
                onChange={handleInputChange}
                className="w-full text-xs font-bold bg-white border border-slate-200 rounded-lg p-2 text-slate-800 focus:outline-none shadow-sm animate-pulse-subtle"
              />
            </div>

            {/* Time Slot with 2-hour gaps from 11 AM to 9 PM */}
            <div className="space-y-1.5 sm:col-span-1">
              <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Time Slot (2h Gap) *</label>
              <select
                name="preferredTime"
                value={inputs.preferredTime}
                onChange={handleInputChange}
                required
                className="w-full text-xs font-bold bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 focus:outline-none focus:border-blue-500 shadow-sm"
              >
                <option value="">Select Time</option>
                <option value="11:00 AM - 01:00 PM">11:00 AM - 01:00 PM</option>
                <option value="01:00 PM - 03:00 PM">01:00 PM - 03:00 PM</option>
                <option value="03:00 PM - 05:00 PM">03:00 PM - 05:00 PM</option>
                <option value="05:00 PM - 07:00 PM">05:00 PM - 07:00 PM</option>
                <option value="07:00 PM - 09:00 PM">07:00 PM - 09:00 PM</option>
              </select>
            </div>
          </div>

          {/* Message */}
          <div className="space-y-1.5 font-sans">
            <label className="text-[10px] uppercase font-bold tracking-wider text-slate-505 block">Message or Particular Health Priorities</label>
            <textarea
              name="message"
              value={inputs.message}
              onChange={handleInputChange}
              rows={2}
              placeholder="Tell us if you want us to compare your family drinking brand to active antioxidant Kangen water."
              className="w-full text-xs font-semibold bg-white border border-slate-201 rounded-lg p-2.5 text-slate-800 focus:outline-none focus:border-blue-500 resize-none placeholder:text-slate-400 shadow-sm"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex justify-end space-x-3">
            {onClose && (
              <button
                id="close-booking-drawer"
                type="button"
                onClick={onClose}
                className="px-4.5 py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-500 rounded-lg text-xs font-bold cursor-pointer transition-colors shadow-xs"
              >
                Cancel
              </button>
            )}
            <button
              id="confirm-booking-btn"
              type="submit"
              className="px-6 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs uppercase tracking-wider shadow-btn-3d active:scale-98 transition-all cursor-pointer"
            >
              Schedule My Demonstration
            </button>
          </div>
        </form>
      )}
    </div>
  );

  if (isModal) {
    return (
      <div id="booking-system-root" className="bg-white border border-slate-200/95 max-w-2xl mx-auto rounded-2xl p-6 sm:p-8 shadow-3d text-left font-sans animate-fade-in relative">
        {onClose && (
          <button 
            type="button" 
            onClick={onClose} 
            className="absolute top-4 right-4 h-8 w-8 flex items-center justify-center rounded-full bg-slate-100 text-slate-500 hover:bg-red-50 hover:text-red-650 cursor-pointer transition-colors text-sm font-bold"
          >
            ×
          </button>
        )}
        <div className="space-y-6">
          {mainFormBody}
          <div className="border-t border-slate-150 pt-5 font-sans">
            {contactInfoSection}
          </div>
          <div className="border-t border-slate-150 pt-5">
            {corporateHeadquartersSection}
          </div>
        </div>
      </div>
    );
  }

  // Standalone full viewport page layout
  return (
    <div id="contact-us-viewport" className="py-12 bg-slate-50 min-h-screen font-sans">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Direct Info section */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-3d space-y-4">
              <h2 className="text-xl font-black text-slate-900 tracking-tight">Support Desk</h2>
              <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                Connect directly with our independent coordination body to schedule interactive sessions, verify physical inventory, or inspect water testing metrics.
              </p>
              {contactInfoSection}
            </div>
            
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-3d space-y-3">
              <h3 className="text-sm font-extrabold text-slate-950">Why attend a live demo?</h3>
              <ul className="space-y-2 mt-2 text-xs font-semibold text-slate-605">
                <li className="flex items-start space-x-2">
                  <span className="text-emerald-500 font-bold shrink-0">✓</span>
                  <span><strong>Chlorine Reagents:</strong> See standard chemical reaction comparisons of raw tap water versus active neutral purification.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-emerald-500 font-bold shrink-0">✓</span>
                  <span><strong>Emulsification:</strong> Witness how pH 11.5 water separates heavy oil layers without synthetic chemicals.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <span className="text-emerald-500 font-bold shrink-0">✓</span>
                  <span><strong>Oxidation Check:</strong> Real-time ORP meter monitoring comparison showing cellular stress scores.</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Right Column: Interactive Booking Form */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-3d">
            {mainFormBody}
          </div>

        </div>

        {/* Corporate Headquarters Area */}
        {corporateHeadquartersSection}

      </div>
    </div>
  );
}
