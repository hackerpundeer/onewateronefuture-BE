import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Droplet, Award, CheckCircle, Sparkles, Star, ChevronRight, Play, Pause,
  Quote, ShieldCheck, HeartPulse, Video, Clock, Users, Send, ExternalLink,
  RotateCcw, RotateCw, Volume2, VolumeX, User, MapPin, Phone, Lock,
  Brain, Eye, Activity, Zap, Thermometer, Layers, X
} from 'lucide-react';
import { WATER_TYPES, CELEBRITIES, TESTIMONIALS } from '../data';
import { WaterType } from '../types';
import ElectrolysisAnimation from './ElectrolysisAnimation';
import CertificationsSection from './CertificationsSection';

// Direct imports of newly generated high-fidelity assets
import k8Img from '../assets/images/hero_kangen_machine_1779402684165.png';
import microBubblesGlass from '../assets/images/micro_bubbles_glass_1779402703800.png';

const WATER_IMAGES: Record<string, string> = {
  'strong-kangen': 'https://images.unsplash.com/photo-1610832958506-ee56336191d8?auto=format&fit=crop&q=80&w=600',
  'kangen-drinking': microBubblesGlass,
  'clean-water': 'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&q=80&w=600',
  'beauty-water': 'https://images.unsplash.com/photo-1522337360788-8b13edd793be?auto=format&fit=crop&q=80&w=600',
  'strong-acidic': 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=600'
};

interface HomeViewProps {
  onNavigate: (tabId: string) => void;
  onOpenDemo: () => void;
}

interface StreamComment {
  id: string;
  user: string;
  text: string;
  time: string;
}

export default function HomeView({ onNavigate, onOpenDemo }: HomeViewProps) {
  const [selectedPhType, setSelectedPhType] = useState<string>('kangen-drinking');
  const [isStreamPlaying, setIsStreamPlaying] = useState<boolean>(true);
  const [spectators, setSpectators] = useState<number>(142);
  const [streamProgress, setStreamProgress] = useState<number>(35);
  const [activeSeoSearch, setActiveSeoSearch] = useState<string>('');
  const [videoError, setVideoError] = useState<boolean>(false);
  const [hoveredBodyPart, setHoveredBodyPart] = useState<string | null>(null);
  const [hoveredCelebIndex, setHoveredCelebIndex] = useState<number | null>(null);
  const [clickedCelebIndex, setClickedCelebIndex] = useState<number | null>(null);

  const celebrityContainerRef = useRef<HTMLDivElement | null>(null);
  const celebrityScrollRef = useRef<HTMLDivElement | null>(null);
  const isDragOrTouchRef = useRef<boolean>(false);
  const isDraggingRef = useRef<boolean>(false);
  const dragStartXRef = useRef<number>(0);
  const dragScrollLeftRef = useRef<number>(0);

  // Close zoomed/clicked celebrity testimonial when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        clickedCelebIndex !== null &&
        celebrityContainerRef.current &&
        !celebrityContainerRef.current.contains(event.target as Node)
      ) {
        setClickedCelebIndex(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside, true);
    document.addEventListener('touchstart', handleClickOutside, true);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside, true);
      document.removeEventListener('touchstart', handleClickOutside, true);
    };
  }, [clickedCelebIndex]);

  // Center initialize the scroll progress on the tripled list for infinite scroll feeling
  useEffect(() => {
    const timer = setTimeout(() => {
      const el = celebrityScrollRef.current;
      if (el) {
        el.scrollLeft = el.scrollWidth / 3.1;
      }
    }, 500);
    return () => clearTimeout(timer);
  }, []);

  // Programmatic smooth auto-sliding with loop-around wrapping
  useEffect(() => {
    const el = celebrityScrollRef.current;
    if (!el) return;

    let animationId: number;
    let lastTime = performance.now();
    const scrollSpeed = 40; // Pixels per second to slide slowly left-to-right/right-to-left

    const animate = (time: number) => {
      const delta = (time - lastTime) / 1000;
      lastTime = time;

      // Pause scroll if hovered, clicked, or actively clicked/touched
      const isPaused = 
        hoveredCelebIndex !== null || 
        clickedCelebIndex !== null || 
        isDragOrTouchRef.current || 
        isDraggingRef.current;

      if (!isPaused && el) {
        el.scrollLeft += scrollSpeed * delta;

        // Wrap around seamlessly
        const maxScroll = el.scrollWidth - el.clientWidth;
        if (el.scrollLeft >= maxScroll - 15) {
          el.scrollLeft = el.scrollWidth / 3.1;
        } else if (el.scrollLeft <= 5) {
          el.scrollLeft = el.scrollWidth / 3.1;
        }
      }

      animationId = requestAnimationFrame(animate);
    };

    animationId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [hoveredCelebIndex, clickedCelebIndex]);

  // Mouse Drag to Scroll events (Desktop)
  const handleMouseDown = (e: React.MouseEvent) => {
    const el = celebrityScrollRef.current;
    if (!el) return;
    isDraggingRef.current = true;
    isDragOrTouchRef.current = true;
    dragStartXRef.current = e.pageX - el.offsetLeft;
    dragScrollLeftRef.current = el.scrollLeft;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const el = celebrityScrollRef.current;
    if (!el) return;
    e.preventDefault();
    const x = e.pageX - el.offsetLeft;
    const walk = (x - dragStartXRef.current) * 1.5; // Drag speed multiplier
    el.scrollLeft = dragScrollLeftRef.current - walk;
  };

  const handleMouseUpOrLeave = () => {
    isDraggingRef.current = false;
    // Keep it paused momentarily then resume
    setTimeout(() => {
      if (!isDraggingRef.current) {
        isDragOrTouchRef.current = false;
      }
    }, 1500);
  };

  // Touch Drag to pause auto scrolling (Mobile/Tab native swipe)
  const handleTouchStart = () => {
    isDragOrTouchRef.current = true;
  };

  const handleTouchEnd = () => {
    setTimeout(() => {
      isDragOrTouchRef.current = false;
    }, 1500);
  };
  
  // Custom HTML5 Video Player and Observer states
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isVideoMuted, setIsVideoMuted] = useState<boolean>(true);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  // Auto-play or auto-pause when video is within the user's focus viewport
  useEffect(() => {
    const videoElem = videoRef.current;
    if (!videoElem) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            videoElem.muted = isVideoMuted;
            videoElem.play().catch((err) => {
              console.log("Autoplay blocked or interrupted:", err);
            });
            setIsPlaying(true);
          } else {
            videoElem.pause();
            setIsPlaying(false);
          }
        });
      },
      { threshold: 0.15 }
    );

    observer.observe(videoElem);
    return () => {
      if (videoElem) {
        observer.unobserve(videoElem);
      }
    };
  }, [isVideoMuted]);

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      const duration = videoRef.current.duration;
      if (duration && isFinite(duration)) {
        // Set the start time to exactly the middle of the video
        videoRef.current.currentTime = duration / 2;
      } else {
        videoRef.current.currentTime = 120; // general middle-ground fallback
      }
    }
  };

  const jumpBackward = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 10);
    }
  };

  const jumpForward = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      const duration = videoRef.current.duration;
      const limit = isFinite(duration) ? duration : 12000;
      videoRef.current.currentTime = Math.min(limit, videoRef.current.currentTime + 10);
    }
  };
  
  // Real-time Countdown States for Zoom Meeting - 8:00 PM IST Countdown
  const [countdownStr, setCountdownStr] = useState<string>('Loading schedule...');
  const [isMeetingLive, setIsMeetingLive] = useState<boolean>(false);
  const [canJoinMeeting, setCanJoinMeeting] = useState<boolean>(false);

  // Zoom Lead Collection Modal States
  const [isZoomModalOpen, setIsZoomModalOpen] = useState<boolean>(false);
  const [rsvpName, setRsvpName] = useState<string>('');
  const [rsvpCity, setRsvpCity] = useState<string>('');
  const [rsvpMobile, setRsvpMobile] = useState<string>('');
  const [rsvpError, setRsvpError] = useState<string>('');
  const [isRsvpSubmitting, setIsRsvpSubmitting] = useState<boolean>(false);
  const [rsvpSuccess, setRsvpSuccess] = useState<boolean>(false);

  // Pre-populate details from browser session
  useEffect(() => {
    try {
      const savedName = localStorage.getItem('kangen_rsvp_name');
      const savedCity = localStorage.getItem('kangen_rsvp_city');
      const savedMobile = localStorage.getItem('kangen_rsvp_mobile');
      if (savedName) setRsvpName(savedName);
      if (savedCity) setRsvpCity(savedCity);
      if (savedMobile) setRsvpMobile(savedMobile);
    } catch (e) {
      console.warn("Could not load RSVP cache from localStorage");
    }
  }, []);

  const handleRsvpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rsvpName.trim()) {
      setRsvpError('NAME_REQUIRED');
      return;
    }
    if (!rsvpCity.trim()) {
      setRsvpError('CITY_REQUIRED');
      return;
    }
    if (!rsvpMobile.trim()) {
      setRsvpError('MOBILE_REQUIRED');
      return;
    }
    const cleanMobile = rsvpMobile.trim();
    if (cleanMobile.length < 8) {
      setRsvpError('MOBILE_INVALID');
      return;
    }

    setIsRsvpSubmitting(true);
    setRsvpError('');

    // Simulate direct instant secure verification and proceed
    setTimeout(() => {
      setIsRsvpSubmitting(false);
      setRsvpSuccess(true);
      
      try {
        localStorage.setItem('kangen_rsvp_name', rsvpName.trim());
        localStorage.setItem('kangen_rsvp_city', rsvpCity.trim());
        localStorage.setItem('kangen_rsvp_mobile', cleanMobile);
      } catch (err) {
        console.warn("Could not cache user details locally.");
      }

      // Open user provided secure Zoom link
      const zoomUrl = "https://us06web.zoom.us/j/88000074852?pwd=IcsNbGCDaZMqQls3mqc1IVY6lsB5Jw.1";
      window.open(zoomUrl, '_blank');
    }, 1200);
  };

  const selectedWater = WATER_TYPES.find((w) => w.id === selectedPhType) || WATER_TYPES[1];

  // Detect and process incoming Google searches or reads
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const q = params.get('q');
    if (q) {
      const queryLower = q.toLowerCase();
      if (queryLower.includes('what is kangen')) {
        setActiveSeoSearch('what-is-kangen');
      } else if (queryLower.includes('benefits')) {
        setActiveSeoSearch('benefits-of-kangen');
      }
    }
  }, []);


  // Dynamic Zoom scheduler matching 8:00 PM IST
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      
      // Calculate current IST time (IST is UTC + 5:30)
      const utcTime = now.getTime() + (now.getTimezoneOffset() * 60 * 1000);
      const istTime = new Date(utcTime + (5.5 * 60 * 60 * 1000));
      
      // Target time today in IST is 20:00:00 (8:00 PM)
      const targetIst = new Date(istTime);
      targetIst.setHours(20, 0, 0, 0);

      const targetStartMs = targetIst.getTime();
      const currentMs = istTime.getTime();
      const liveDurationMs = 45 * 60 * 1000; // Live for 45 minutes

      // Check if we are currently in the live window today (8:00 PM to 8:45 PM IST)
      const isLiveNow = currentMs >= targetStartMs && currentMs <= targetStartMs + liveDurationMs;

      let finalIsMeetingLive = isLiveNow;
      let finalCanJoin = false;
      let finalCountdownStr = '';

      if (isLiveNow) {
        finalIsMeetingLive = true;
        finalCanJoin = true;
        finalCountdownStr = 'LIVE NOW! Session is in progress!';
      } else {
        // Resolve upcoming meeting target (might be tomorrow if past 8:45 PM IST today)
        let resolvedTarget = new Date(targetIst);
        if (currentMs > targetStartMs + liveDurationMs) {
          resolvedTarget.setDate(resolvedTarget.getDate() + 1);
        }

        const remainingMs = resolvedTarget.getTime() - currentMs;
        finalIsMeetingLive = false;
        
        // Active/clickable ONLY 30 minutes before meeting starts (e.g. 7:30 PM to 8:00 PM IST)
        finalCanJoin = remainingMs <= 30 * 60 * 1000 && remainingMs >= 0;

        const hoursLeft = Math.floor(remainingMs / (1000 * 60 * 60));
        const minsLeft = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
        const secsLeft = Math.floor((remainingMs % (1000 * 60)) / 1000);

        const hrDisplay = hoursLeft > 0 ? `${hoursLeft}h ` : '';
        finalCountdownStr = `${hrDisplay}${minsLeft}m ${secsLeft}s`;
      }

      setIsMeetingLive(finalIsMeetingLive);
      setCanJoinMeeting(finalCanJoin);
      setCountdownStr(finalCountdownStr);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Spectators dynamic flicker
  useEffect(() => {
    const specInterval = setInterval(() => {
      setSpectators(prev => {
        const delta = Math.floor(Math.random() * 5) - 2;
        return Math.max(120, prev + delta);
      });
    }, 4000);
    return () => clearInterval(specInterval);
  }, []);

  // Demo Stream timeline progress simulator
  useEffect(() => {
    if (!isStreamPlaying) return;
    const progressInterval = setInterval(() => {
      setStreamProgress(prev => (prev >= 100 ? 0 : prev + 0.15));
    }, 1000);
    return () => clearInterval(progressInterval);
  }, [isStreamPlaying]);

  // Demo Stream static initial comments with rotation
  const streamComments: StreamComment[] = [
    { id: '1', user: 'Amit Kumar (Delhi)', text: 'Wow, the chlorine test is shocking! Tap water immediately turned yellow!', time: 'Just now' },
    { id: '2', user: 'Jessica Reynolds', text: 'My Anespa DX Home Spa arrived yesterday. Bathing in this rich mineral water feels absolutely like a luxury Japanese hot spring!', time: '1 min ago' },
    { id: '3', user: 'Rajesh S. Patel', text: 'Does Enagic provide direct installations in Mumbai?', time: '3 mins ago' },
    { id: '4', user: 'Dr. Clara Thorne', text: 'We recommend alkaline hydration specifically for active muscle acid buffering.', time: '5 mins ago' }
  ];

  return (
    <div className="space-y-12 pb-16 bg-[#f8fafc] text-slate-800 relative overflow-hidden font-sans">
      
      {/* Background spotlights */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[12%] left-[3%] w-96 h-96 rounded-full bg-blue-100/40 blur-3xl" />
        <div className="absolute top-[50%] right-[3%] w-80 h-80 rounded-full bg-cyan-100/30 blur-3xl" />
      </div>

      {/* 0. GRAND FULL-WIDTH ADVENTURE: WHAT IS ONE WATER ONE FUTURE? */}
      <section className="relative w-full overflow-hidden bg-[#070b19] text-slate-100 py-16 md:py-24 border-b border-blue-900/40">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a1128] via-[#060a16] to-[#04060e]" />
        {/* Abstract design vector circles for luxury vibe */}
        <div className="absolute top-[-80px] right-[-80px] w-[500px] h-[550px] rounded-full bg-blue-650/10 blur-[130px] pointer-events-none" />
        <div className="absolute bottom-[-120px] left-[5%] w-[600px] h-[600px] rounded-full bg-cyan-500/5 blur-[160px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-16">
          
          {/* Tagline header centered */}
          <div className="space-y-4 max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center space-x-2.5 px-4 py-1.5 bg-[#121c3a] border border-[#223974] rounded-full select-none">
              <span className="flex h-2.5 w-2.5 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#60a5fa]">
                Global Education Hub & Initiative
              </span>
              <span className="text-[10px] bg-blue-600 text-white font-mono px-2 py-0.5 rounded font-black tracking-wider">
                TRANSPARENT WATER REGENERATION
              </span>
            </div>
            
            <h1 className="text-4xl sm:text-6xl font-black tracking-tight text-white leading-tight font-serif">
              What is <span className="bg-gradient-to-r from-cyan-400 via-[#60a5fa] to-indigo-400 bg-clip-text text-transparent">One Water One Future?</span>
            </h1>
            
            <p className="text-slate-300 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed font-medium">
              We are a global community raising critical curiosity about the water we consume. Because our collective future depends entirely on restoring our biology back to its pristine cellular origins.
            </p>
          </div>

          {/* MONUMENTAL CENTERPIECE PHILOSOPHY CALLOUT */}
          <div className="max-w-4xl mx-auto py-8 px-4 text-center">
            <div className="relative p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-blue-950 via-[#0e172a] to-slate-900 border-2 border-cyan-500/30 overflow-hidden shadow-2xl">
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />
              
              <span className="text-[10.5px] font-mono uppercase font-black text-cyan-400 tracking-widest block mb-3 bg-[#0d1e3d] border border-cyan-500/35 px-4 py-1.5 rounded-full w-fit mx-auto">
                THE ORIGINAL PHILOSOPHY OF ENAGIC®
              </span>
              
              <h2 className="text-5xl sm:text-7xl font-extrabold text-white tracking-tight leading-none uppercase font-sans">
                "KANGEN"
              </h2>
              
              <p className="text-2xl sm:text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-pink-400 mt-3 font-serif italic text-center">
                Means Return to Origin
              </p>
              
              <div className="h-0.5 w-24 bg-gradient-to-r from-cyan-500 via-blue-500 to-pink-500 mx-auto my-6" />
              
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-semibold max-w-2xl mx-auto">
                In Japanese, the word <strong className="text-white">Kangen (還元)</strong> translates literally to returning back to the pristine natural state. It is an invitation to purge toxic industrial pollutants, heavy acidity, and petrochemical stress from your cellular tissues—restoring your physical vessel to supreme health while healing our biosphere of single-use contamination.
              </p>
            </div>
          </div>

          {/* SEQUENCE WISE EXPLANATION: WHAT IS KANGEN WATER & ITS BENEFITS */}
          <div id="sequential-kangen-guide" className="max-w-5xl mx-auto space-y-12">
            <div className="text-center space-y-2">
              <span className="text-xs font-black uppercase text-slate-500 tracking-widest font-mono">
                THE SEQUENTIAL BLUEPRINT
              </span>
              <p className="text-lg sm:text-xl font-bold text-white font-serif">
                Explore Kangen Water Chemistry &amp; High-Value Benefits in Detail
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
              
              {/* SEQUENCE BLOCK 1: What is Kangen Water? */}
              <div className="bg-[#111936] border border-blue-900/50 p-6 sm:p-8 rounded-3xl shadow-xl flex flex-col justify-between space-y-6 hover-lift hover-glow-blue transition-all duration-300">
                <div className="space-y-4 font-sans text-left">
                  <div className="flex items-center space-x-3">
                    <span className="w-8 h-8 rounded-full bg-blue-600 text-white font-mono font-black text-sm flex items-center justify-center shrink-0">
                      1
                    </span>
                    <h4 className="text-lg sm:text-xl font-black text-white font-serif tracking-tight">
                      What is Kangen Water?
                    </h4>
                  </div>
                  
                  <div className="h-40 rounded-2xl overflow-hidden relative border border-blue-800/60 shadow-inner">
                    <img 
                      referrerPolicy="no-referrer"
                      src={microBubblesGlass} 
                      alt="Silky molecularly restructured hydrogen-rich Kangen Water glass" 
                      className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute top-2 left-2 bg-slate-900/80 px-2 py-0.5 rounded text-[8px] font-mono font-medium text-cyan-400">
                      OEM Electrolysis Chamber
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed font-semibold">
                    Kangen Water is highly structured, antioxidant-rich water generated through continuous, non-chemical medical electrolysis. Within Enagic's ISO 13485 facility in Osaka, tap water is passed through high-level antibacterial solid carbon filters before passing into an array of platinum-dipped titanium plates. 
                  </p>
                  
                  <p className="text-xs text-slate-400 leading-relaxed font-semibold">
                    The electrical current splits the H₂O molecule, concentrating powerful dissolved alkaline minerals on one side and acidic disinfection water on the other. It results in a clean, silky, therapeutic drinking water infused with active molecular hydrogen.
                  </p>
                </div>

                <div className="pt-4 border-t border-blue-900/30 grid grid-cols-2 gap-4 text-xs font-mono font-bold text-slate-400 text-left">
                  <span className="text-cyan-400">✓ Platinum-Titanium Plates</span>
                  <span className="text-cyan-400">✓ Made in Osaka, Japan</span>
                </div>
              </div>

              {/* SEQUENCE BLOCK 2: Core Biological Benefits */}
              <div className="bg-[#161334] border border-pink-900/30 p-6 sm:p-8 rounded-3xl shadow-xl flex flex-col justify-between space-y-6 hover-lift hover-glow-cyan transition-all duration-300">
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <span className="w-8 h-8 rounded-full bg-pink-600 text-white font-mono font-black text-sm flex items-center justify-center shrink-0">
                      2
                    </span>
                    <h4 className="text-lg sm:text-xl font-black text-white font-serif tracking-tight">
                      Benefits of Kangen Water
                    </h4>
                  </div>

                  <div className="grid grid-cols-1 gap-3.5 pt-1">
                    
                    <div className="p-3.5 bg-[#251842]/40 rounded-2xl border border-[#3e2570]/30 flex items-start space-x-3">
                      <div className="h-8 w-8 rounded-lg bg-pink-950 flex items-center justify-center text-pink-400 shrink-0 border border-pink-900">
                        <HeartPulse className="h-4.5 w-4.5" />
                      </div>
                      <div>
                        <h5 className="text-[12px] font-bold text-white uppercase tracking-wider font-mono">Selective Antioxidant Defense</h5>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-semibold mt-0.5">
                          Dissolved Molecular Hydrogen (H₂) selectively destroys reactive oxygen species (cytotoxic free radicals) to protect cells from somatic aging.
                        </p>
                      </div>
                    </div>

                    <div className="p-3.5 bg-[#142345]/50 rounded-2xl border border-[#1b3469]/30 flex items-start space-x-3">
                      <div className="h-8 w-8 rounded-lg bg-blue-950 flex items-center justify-center text-blue-400 shrink-0 border border-blue-900">
                        <Droplet className="h-4.5 w-4.5" />
                      </div>
                      <div>
                        <h5 className="text-[12px] font-bold text-white uppercase tracking-wider font-mono">Micro-Clustered Bio-Absorption</h5>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-semibold mt-0.5">
                          Lowers the surface tension of water, facilitating instantaneous cell hydration and supporting accelerated metabolic detox processes.
                        </p>
                      </div>
                    </div>

                    <div className="p-3.5 bg-[#152735]/50 rounded-2xl border border-cyan-800/30 flex items-start space-x-3">
                      <div className="h-8 w-8 rounded-lg bg-cyan-950 flex items-center justify-center text-cyan-400 shrink-0 border border-cyan-900">
                        <Award className="h-4.5 w-4.5" />
                      </div>
                      <div>
                        <h5 className="text-[12px] font-bold text-white uppercase tracking-wider font-mono">Systemic Alkaline Buffering</h5>
                        <p className="text-[11px] text-slate-400 leading-relaxed font-semibold mt-0.5">
                          Perfectly balanced pH 8.5 to 9.5 minerals help human tissues safely buffer cumulative industrial foods and environmental acidity.
                        </p>
                      </div>
                    </div>

                  </div>
                </div>

                <div className="pt-4 border-t border-pink-900/30 flex justify-between text-xs font-mono font-bold text-pink-400">
                  <span>✨ 1.6ppm Active Hydrogen</span>
                  <span>✨ High Negative ORP (-850mV)</span>
                </div>
              </div>

            </div>
          </div>

          {/* Pillars Grid rendered below simple text */}
          <div className="max-w-5xl mx-auto pt-4 text-center">
            <p className="text-xs uppercase tracking-widest font-mono text-slate-500 font-bold mb-6">
              The Four biological pillars of restructured cellular health
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-left">
              
              <div className="bg-[#111827]/40 border border-slate-800/80 p-5 rounded-2xl space-y-2.5 shadow-md hover:border-blue-500/50 transition-all">
                <div className="h-9 w-9 rounded-xl bg-blue-950 flex items-center justify-center text-blue-400 border border-blue-900 shrink-0">
                  <HeartPulse className="h-4.5 w-4.5" />
                </div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">1. Active Hydrogen Antioxidant</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed font-semibold">
                  Supercharges cells with therapeutic dissolved molecular hydrogen (H₂) that selectively neutralizes cell-aging reactive oxygen radicals.
                </p>
              </div>

              <div className="bg-[#111827]/40 border border-slate-800/80 p-5 rounded-2xl space-y-2.5 shadow-md hover:border-cyan-500/50 transition-all">
                <div className="h-9 w-9 rounded-xl bg-cyan-950 flex items-center justify-center text-cyan-400 border border-cyan-900 shrink-0">
                  <Droplet className="h-4.5 w-4.5" />
                </div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">2. Micro-Clustered Purity</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed font-semibold">
                  Alters physical surface tension to yield smaller molecular water matrices, supporting rapid hydration and accelerated detox absorption.
                </p>
              </div>

              <div className="bg-[#111827]/40 border border-slate-800/80 p-5 rounded-2xl space-y-2.5 shadow-md hover:border-emerald-500/50 transition-all">
                <div className="h-9 w-9 rounded-xl bg-emerald-950 flex items-center justify-center text-emerald-400 border border-emerald-900 shrink-0">
                  <Award className="h-4.5 w-4.5" />
                </div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">3. Alkaline Buffering Power</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed font-semibold">
                  Infuses healthy, high-strength alkaline minerals (pH 8.5 to 9.5) directly into tissues to neutralize cumulative body acidity levels safely.
                </p>
              </div>

              <div className="bg-[#111827]/40 border border-slate-800/80 p-5 rounded-2xl space-y-2.5 shadow-md hover:border-indigo-500/50 transition-all">
                <div className="h-9 w-9 rounded-xl bg-indigo-950 flex items-center justify-center text-indigo-400 border border-indigo-900 shrink-0">
                  <ShieldCheck className="h-4.5 w-4.5" />
                </div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">4. Eco-Conscious Integration</h4>
                <p className="text-[11px] text-slate-400 leading-relaxed font-semibold">
                  Allows users to eliminate the reliance on disposable plastics while generating zero toxic sanitation runoff, healing nature.
                </p>
              </div>

            </div>
          </div>

        </div>
      </section>

      {/* 0.5 HIGHLIGHT SECTION: OUR BODY IS 70% WATER */}
      <section className="relative w-full overflow-hidden bg-[#050814] text-slate-100 py-16 md:py-24 border-b border-blue-900/40">
        <div className="absolute inset-0 bg-gradient-to-b from-[#04060e] via-[#050814] to-[#070b19]" />
        {/* Glowing background highlights */}
        <div className="absolute top-[20%] left-[-10%] w-[450px] h-[450px] rounded-full bg-blue-500/5 blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[20%] right-[-10%] w-[450px] h-[450px] rounded-full bg-cyan-500/5 blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 space-y-12">
          
          {/* Header */}
          <div className="space-y-4 max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-cyan-950/50 border border-cyan-500/30 rounded-full select-none">
              <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
              <span className="text-[10px] uppercase font-mono font-bold tracking-widest text-[#22d3ee]">
                HUMAN BIO-REGULATION &amp; HYDRATION
              </span>
            </div>
            
            <h2 className="text-3xl sm:text-5xl font-black tracking-tight text-white leading-tight font-serif uppercase">
              OUR BODY IS <span className="bg-gradient-to-r from-[#22d3ee] via-[#60a5fa] to-indigo-400 bg-clip-text text-transparent">70% WATER</span>
            </h2>
            
            <div className="flex items-center justify-center space-x-4">
              <div className="h-0.5 w-12 bg-gradient-to-r from-transparent to-cyan-500" />
              <p className="text-sm font-semibold tracking-widest uppercase font-mono text-cyan-400 italic">
                Jal hi Jeevan hai
              </p>
              <div className="h-0.5 w-12 bg-gradient-to-l from-transparent to-cyan-500" />
            </div>

            <p className="text-slate-400 text-xs sm:text-sm max-w-2xl mx-auto leading-relaxed font-semibold">
              Every critical biological process in your physical vessel relies entirely on the quality, purity, and structure of the liquid medium that fills your cells. Since you are literally made of water, the choice of your water represents your direct state of biological origin and tomorrow's health.
            </p>
          </div>

          {/* Interactive Bento Blueprint Container */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-4">
            
            {/* COLUMN 1: ORGAN SPECIFIC COMPOSITION (4 cols) */}
            <div className="lg:col-span-4 bg-[#0a1128]/70 border border-blue-900/40 p-6 rounded-3xl shadow-xl flex flex-col justify-between space-y-6 backdrop-blur-sm">
              <div className="space-y-4">
                <div className="border-b border-blue-900/30 pb-3">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-blue-500" />
                    Organ Fluid Densities
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5 font-semibold leading-relaxed">
                    Percentage of clean structured water required by each vital organ system to function optimally.
                  </p>
                </div>

                <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1 select-none custom-scrollbar-thin">
                  {[
                    { id: 'eyes', label: 'Eyes', percent: 95, icon: <Eye className="h-3.5 w-3.5" />, color: 'from-cyan-400 to-blue-500', desc: 'Controls ocular hydration and visual light focus.' },
                    { id: 'brain', label: 'Brain', percent: 75, icon: <Brain className="h-3.5 w-3.5" />, color: 'from-indigo-400 to-purple-500', desc: 'Powers neurological signals and memory retention.' },
                    { id: 'blood', label: 'Blood', percent: 83, icon: <Activity className="h-3.5 w-3.5" />, color: 'from-red-400 to-pink-500', desc: 'Transports cellular oxygen and vital food nutrients.' },
                    { id: 'liver', label: 'Liver', percent: 86, icon: <Layers className="h-3.5 w-3.5" />, color: 'from-emerald-400 to-teal-500', desc: 'Facilitates detoxification and metabolic synthesis.' },
                    { id: 'kidney', label: 'Kidney', percent: 83, icon: <ShieldCheck className="h-3.5 w-3.5" />, color: 'from-amber-400 to-orange-500', desc: 'Filters wastes and regulates systemic fluid balances.' },
                    { id: 'heart', label: 'Heart', percent: 79, icon: <HeartPulse className="h-3.5 w-3.5" />, color: 'from-rose-500 to-red-650', desc: 'Maintains cardiovascular flow and arterial pressure.' },
                    { id: 'lungs', label: 'Lungs', percent: 80, icon: <Star className="h-3.5 w-3.5" />, color: 'from-sky-400 to-indigo-500', desc: 'Enables carbon exchange and respiratory moisture.' },
                    { id: 'joints', label: 'Joints', percent: 83, icon: <Award className="h-3.5 w-3.5" />, color: 'from-teal-400 to-emerald-500', desc: 'Provides dynamic lubrication and skeletal cushioning.' },
                    { id: 'muscles', label: 'Muscles', percent: 76, icon: <Zap className="h-3.5 w-3.5" />, color: 'from-blue-400 to-violet-500', desc: 'Maintains structural strength and energy storage.' },
                    { id: 'skin', label: 'Skin', percent: 70, icon: <User className="h-3.5 w-3.5" />, color: 'from-pink-400 to-rose-400', desc: 'Serves as physical buffer and body temperature shield.' },
                  ].map((organ) => (
                    <div
                      key={organ.id}
                      onMouseEnter={() => setHoveredBodyPart(organ.id)}
                      onMouseLeave={() => setHoveredBodyPart(null)}
                      className={`p-2.5 rounded-xl border transition-all duration-300 cursor-pointer ${
                        hoveredBodyPart === organ.id
                          ? 'bg-[#152345] border-cyan-500/60 shadow-lg scale-[1.02]'
                          : 'bg-[#0f1833]/40 border-blue-950/50 hover:bg-[#111c3a]/50'
                      }`}
                    >
                      <div className="flex items-center justify-between font-mono">
                        <div className="flex items-center space-x-2">
                          <div className={`p-1 bg-slate-900 rounded-lg text-slate-300 border border-slate-700/50 ${hoveredBodyPart === organ.id ? 'text-cyan-400 border-cyan-500/40' : ''}`}>
                            {organ.icon}
                          </div>
                          <span className="text-[12px] font-bold text-white tracking-wide">{organ.label}</span>
                        </div>
                        <span className="text-[12px] font-black text-cyan-400">{organ.percent}%</span>
                      </div>
                      
                      <div className="mt-1.5 w-full bg-[#080d1a] h-1.5 rounded-full overflow-hidden border border-slate-800">
                        <motion.div 
                          className={`h-full rounded-full bg-gradient-to-r ${organ.color}`}
                          initial={{ width: 0 }}
                          animate={{ width: `${organ.percent}%` }}
                          transition={{ duration: 0.8, ease: 'easeOut' }}
                        />
                      </div>
                      
                      {hoveredBodyPart === organ.id && (
                        <p className="mt-1.5 text-[9.5px] text-slate-300 leading-snug font-medium italic animate-fadeIn">
                          {organ.desc}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* COLUMN 2: INTERACTIVE BIOLOGICAL BODY VECTOR (4 cols) */}
            <div className="lg:col-span-4 bg-[#080f24]/90 border border-blue-900/50 p-6 rounded-3xl shadow-xl flex flex-col items-center justify-center relative backdrop-blur-sm overflow-hidden select-none">
              
              {/* Decorative liquid grid lines */}
              <div className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent" />
              <div className="absolute inset-y-0 left-0 w-0.5 bg-gradient-to-b from-transparent via-cyan-500/10 to-transparent" />
              
              {/* Dynamic Body Graphic Title */}
              <div className="text-center space-y-1 z-10 w-full mb-3">
                <span className="text-[9px] uppercase font-mono font-bold tracking-widest text-cyan-400 block">Interactive Hydration Map</span>
                <h4 className="text-xs font-bold text-slate-300">Hover elements to explore fluid distribution</h4>
              </div>

              {/* Anatomy diagram with liquid wave background mask */}
              <div className="relative w-full aspect-[3/4] max-w-[280px] flex items-center justify-center">
                
                {/* Simulated fluid levels behind body */}
                <div className="absolute inset-0 bg-[#070c1a] rounded-full border border-blue-900/20 flex items-center justify-center">
                  <div className="w-[90%] h-[90%] rounded-full bg-cyan-900/5 animate-pulse relative overflow-hidden flex items-center justify-center border border-dashed border-[#1e2e5c]/40">
                    
                    {/* Simulated wavy fluid block in lower 70% */}
                    <div className="absolute bottom-0 left-0 right-0 h-[70%] bg-gradient-to-t from-blue-900/25 via-cyan-500/15 to-transparent relative">
                      <div className="absolute inset-0 opacity-40 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-cyan-500/35 via-transparent to-transparent" />
                    </div>
                    
                    <span className="absolute text-5xl font-mono text-[#0e1c3b] font-black z-0 pointer-events-none tracking-tighter select-none">
                      70%
                    </span>
                  </div>
                </div>

                {/* SVG Human Wireframe Silhouette */}
                <svg viewBox="0 0 100 150" className="w-full h-full relative z-10 drop-shadow-[0_0_15px_rgba(6,182,212,0.15)]">
                  <defs>
                    <linearGradient id="bodyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#1e3a8a" stopOpacity="0.4" />
                      <stop offset="30%" stopColor="#0284c7" stopOpacity="0.5" />
                      <stop offset="70%" stopColor="#06b6d4" stopOpacity="0.7" />
                      <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.9" />
                    </linearGradient>
                  </defs>

                  {/* Outer glow background of the body */}
                  <path 
                    d="M50 8 C46 8, 44 11, 44 15 C44 19, 46 22, 50 22 C54 22, 56 19, 56 15 C56 11, 54 8, 50 8 Z 
                       M50 22 C44 24, 38 29, 36 34 C33 41, 30 52, 28 65 C27 70, 29 72, 31 71 C32 70, 34 60, 36 50 C37 45, 38 41, 39 41 C39 41, 39 60, 39 80 C39 85, 38 90, 36 100 C34 110, 32 120, 32 135 C32 142, 35 144, 37 143 C39 142, 42 125, 45 105 C47 98, 48 95, 50 95 C52 95, 53 98, 55 105 C58 125, 61 142, 63 143 C65 144, 68 142, 68 135 C68 120, 66 110, 64 100 C62 90, 61 85, 61 80 C61 60, 61 41, 61 41 C62 41, 63 45, 64 50 C66 60, 68 70, 69 71 C71 72, 73 70, 72 65 C70 52, 67 41, 64 34 C62 29, 56 24, 50 22 Z" 
                    fill="url(#bodyGradient)" 
                    stroke="#0891b2" 
                    strokeWidth="0.8" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                  />

                  {/* Hotspots (Interactive circles) representing the organs */}
                  {[
                    { id: 'brain', cx: 50, cy: 13, r: 3 },
                    { id: 'eyes', cx: 50, cy: 18, r: 2 },
                    { id: 'heart', cx: 47, cy: 38, r: 3.5 },
                    { id: 'lungs', cx: 53, cy: 37, r: 3.5 },
                    { id: 'liver', cx: 46, cy: 48, r: 3.5 },
                    { id: 'blood', cx: 50, cy: 62, r: 3 },
                    { id: 'kidney', cx: 48, cy: 55, r: 3 },
                    { id: 'muscles', cx: 33, cy: 75, r: 3 },
                    { id: 'joints', cx: 37, cy: 105, r: 3 },
                    { id: 'skin', cx: 29, cy: 58, r: 3 },
                  ].map((pt) => {
                    const isHovered = hoveredBodyPart === pt.id;
                    return (
                      <g 
                        key={pt.id}
                        className="cursor-pointer group/spot"
                        onMouseEnter={() => setHoveredBodyPart(pt.id)}
                        onMouseLeave={() => setHoveredBodyPart(null)}
                      >
                        {/* Interactive glow ring */}
                        <circle 
                          cx={pt.cx} 
                          cy={pt.cy} 
                          r={pt.r * (isHovered ? 2.5 : 1.8)} 
                          fill="transparent" 
                          stroke={isHovered ? '#22d3ee' : '#2563eb'} 
                          strokeWidth={isHovered ? '0.8' : '0.4'}
                          className="transition-all duration-300 stroke-dasharray-[2,_2]"
                          opacity={isHovered ? 0.9 : 0.4}
                        />
                        {/* Core localized highlight center */}
                        <circle 
                          cx={pt.cx} 
                          cy={pt.cy} 
                          r={pt.r * 0.7} 
                          fill={isHovered ? '#22d3ee' : '#38bdf8'} 
                          className="transition-all duration-300"
                        />
                      </g>
                    );
                  })}
                </svg>

                {/* Show details card when hovering inside middle */}
                <AnimatePresence>
                  {hoveredBodyPart && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute bottom-1 right-1 left-1 bg-slate-950/95 border border-cyan-500/50 p-2.5 rounded-xl text-center shadow-lg font-mono z-20 backdrop-blur-md"
                    >
                      <h5 className="text-[11px] font-black uppercase text-cyan-400 select-none">
                        {[
                          { id: 'eyes', label: 'EYES: 95% WATER' },
                          { id: 'brain', label: 'BRAIN: 75% WATER' },
                          { id: 'blood', label: 'BLOOD: 83% WATER' },
                          { id: 'liver', label: 'LIVER: 86% WATER' },
                          { id: 'kidney', label: 'KIDNEY: 83% WATER' },
                          { id: 'heart', label: 'HEART: 79% WATER' },
                          { id: 'lungs', label: 'LUNGS: 80% WATER' },
                          { id: 'joints', label: 'JOINTS: 83% WATER' },
                          { id: 'muscles', label: 'MUSCLES: 76% WATER' },
                          { id: 'skin', label: 'SKIN: 70% WATER' },
                        ].find(o => o.id === hoveredBodyPart)?.label || hoveredBodyPart.toUpperCase()}
                      </h5>
                      <p className="text-[9.5px] text-slate-300 mt-0.5 leading-tight font-sans">
                        {[
                          { id: 'eyes', desc: 'Maintains critical optic lubrication and sharp visual focus.' },
                          { id: 'brain', desc: 'Allows smooth neurological current transmission and optimal cognitive function.' },
                          { id: 'blood', desc: 'Enables smooth, high-volume transport of oxygen and vital nutrients.' },
                          { id: 'liver', desc: 'Provides the critical fluid medium needed to metabolize nutrients and filter cellular wastes.' },
                          { id: 'kidney', desc: 'Sustains continuous filtration of blood, toxin clearance, and metabolic fluid balance.' },
                          { id: 'heart', desc: 'Keeps blood volume and blood pressure balanced to minimize cardiovascular friction.' },
                          { id: 'lungs', desc: 'Safeguards delicate pulmonary membranes from desiccation during respiration.' },
                          { id: 'joints', desc: 'Supports friction-free joint movement and healthy cartilage shock absorption.' },
                          { id: 'muscles', desc: 'Powers dynamic cell hydration to optimize muscle strength and cellular ATP production.' },
                          { id: 'skin', desc: 'Maintains the elastic cellular matrix to prevent dehydration and support structural resilience.' },
                        ].find(d => d.id === hoveredBodyPart)?.desc || 'Indispensable cellular component requiring clean structured molecules.'}
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>

              </div>

              {/* Fluid indicator footnote */}
              <div className="w-full flex justify-between px-3 pt-3 mt-1 border-t border-blue-900/40 text-[9px] font-mono font-bold text-slate-400 select-none">
                <span>⚡ BIO-ELECTRICAL STATE</span>
                <span className="text-cyan-400">ACTIVE MOLECULES</span>
              </div>
            </div>

            {/* COLUMN 3: VITAL PHYSIOLOGICAL OPERATIONS (4 cols) */}
            <div className="lg:col-span-4 bg-[#0a1128]/70 border border-blue-900/40 p-6 rounded-3xl shadow-xl flex flex-col justify-between space-y-6 backdrop-blur-sm text-left">
              <div className="space-y-4">
                <div className="border-b border-blue-900/30 pb-3">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-cyan-400" />
                    Essential Physiological Roles
                  </h3>
                  <p className="text-[11px] text-slate-500 mt-0.5 font-semibold leading-relaxed">
                    Vital bodily operations governed and strictly sustained by your daily water choice:
                  </p>
                </div>

                <div className="space-y-3.5 max-h-[460px] overflow-y-auto pr-1 select-none custom-scrollbar-thin">
                  {[
                    { label: 'Aiding Digestion', desc: 'Supports digestive juices and ensures seamless nutrient breakdown.', icon: <Activity className="text-emerald-400 h-4 w-4" /> },
                    { label: 'Transporting Nutrition', desc: 'Carries precious trace minerals, proteins, and glucose through deep tissues.', icon: <Droplet className="text-cyan-400 h-4 w-4" /> },
                    { label: 'Generates Energy', desc: 'Acts as the foundation for mitochondrial ATP generation to eliminate fatigue.', icon: <Zap className="text-yellow-400 h-4 w-4" /> },
                    { label: 'Helps deliver Oxygen to the body', desc: 'Empowers cellular oxygen distribution to prevent cellular hypoxia.', icon: <ShieldCheck className="text-blue-400 h-4 w-4" /> },
                    { label: 'Lubrication of Joints', desc: 'Provides the essential fluid cushion preserving cartilage layers.', icon: <Award className="text-indigo-400 h-4 w-4" /> },
                    { label: 'Balancing Body Temperature', desc: 'Supports metabolic heat dissipation and cooling evaporation sweeps.', icon: <Thermometer className="text-rose-400 h-4 w-4" /> },
                    { label: 'Multiplication of Cells', desc: 'Maintains perfect cytoplasm integrity required for healthy mitosis.', icon: <Layers className="text-purple-400 h-4 w-4" /> },
                    { label: 'Regulating Blood Pressure', desc: 'Sustains optimal blood volume composition to defend arterial walls.', icon: <HeartPulse className="text-pink-400 h-4 w-4" /> },
                    { label: 'Waste Disposal', desc: 'Flushes metabolic purines, cell waste, and toxins from systemic networks.', icon: <Star className="text-amber-400 h-4 w-4" /> },
                  ].map((func, idx) => (
                    <div 
                      key={idx} 
                      className="p-2.5 rounded-xl bg-[#0e1631]/50 border border-blue-950/40 space-y-1 hover:border-cyan-500/30 transition-all duration-300"
                    >
                      <div className="flex items-center space-x-2.5">
                        <div className="p-1 bg-[#090d1a] border border-blue-900/50 rounded-lg shrink-0">
                          {func.icon}
                        </div>
                        <h4 className="text-[12px] font-bold text-white font-mono">{func.label}</h4>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-normal pl-8 font-semibold">
                        {func.desc}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>

          {/* Bottom Outstanding Quote Banner */}
          <div className="max-w-5xl mx-auto pt-6 text-center select-none">
            <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-950/60 via-[#102046] to-cyan-950/60 border border-cyan-500/30 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 bottom-0 left-0 w-1 bg-gradient-to-b from-cyan-400 to-blue-600" />
              <p className="text-xs sm:text-sm font-semibold text-slate-100 max-w-3xl mx-auto leading-relaxed">
                ⚖️ <strong className="text-[#22d3ee]">The Quality &amp; Structure of Water</strong> is absolutely critical for the correct operation of these vital physiological functions. Because your body is <strong className="text-white">70% Water</strong>, you must choose your water accordingly.
              </p>
              <div className="mt-3 flex items-center justify-center space-x-6 text-[10px] font-mono font-black text-cyan-400">
                <span>✓ MOLECULAR ENERGY</span>
                <span>✓ METABOLIC EFFICACY</span>
                <span>✓ CELLULAR HYDRATION</span>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 1. HERO SECTION */}
      <section id="hero-section" className="relative py-12 md:py-16 border-b border-slate-205/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column Text */}
            <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center space-x-2 px-3 py-1 bg-blue-50 border border-blue-200/60 rounded-full select-none">
                <span className="flex h-2 w-2 rounded-full bg-blue-600 animate-ping" />
                <span className="text-[10px] uppercase font-black text-blue-600 tracking-wider">
                  One Water One Future Initiative
                </span>
                <span className="text-[9px] bg-blue-600 text-white font-mono px-1.5 py-0.5 rounded font-black">
                  Public Health Mission
                </span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-none text-slate-900 font-sans">
                <span>Discover Kangen Water®</span>
                <br />
                <span className="bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-600 bg-clip-text text-transparent italic font-serif text-xl sm:text-2xl mt-2 block">
                  Change Your Water, Change Your Life!®
                </span>
              </h1>

              <blockquote className="border-l-4 border-blue-500 pl-4 py-2.5 italic text-slate-650 text-xs sm:text-sm max-w-xl mx-auto lg:mx-0 bg-blue-50/50 rounded-r-xl text-left">
                &ldquo;Return to Origin&rdquo; &mdash; Micro-clustered, chemical-free active hydrogen Kangen Water generated through certified medical titanium electrolysis plates.
              </blockquote>

              <p className="text-slate-500 text-xs leading-relaxed max-w-xl mx-auto lg:mx-0 font-semibold text-left">
                Every Enagic® device is imported directly from Osaka, Japan, incorporating OEM engineering since 1974. These medical-grade ionizers filter toxic chlorine and heavy residues while infusing your tissues with molecular therapeutic hydrogen selective antioxidants.
              </p>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  id="hero-cta-demo"
                  onClick={onOpenDemo}
                  className="w-full sm:w-auto px-6 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-btn-3d hover:scale-101 transition-all flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <Sparkles className="h-4 w-4" />
                  <span>Book Free Demonstration</span>
                </button>

                <button
                  id="hero-cta-benefits"
                  onClick={() => onNavigate('products')}
                  className="w-full sm:w-auto px-6 py-3.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-205 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all flex items-center justify-center space-x-1.5 cursor-pointer shadow-xs"
                >
                  <span>Compare Machines</span>
                  <ChevronRight className="h-4 w-4 text-blue-600" />
                </button>
              </div>

              {/* Corporate Stats Grid */}
              <div className="pt-6 grid grid-cols-3 gap-4 text-center border-t border-slate-200">
                <div>
                  <p className="text-2xl font-black text-blue-600">27</p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest font-black">Countries Hubs</p>
                </div>
                <div>
                  <p className="text-2xl font-black text-slate-900">42</p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest font-black">Global Offices</p>
                </div>
                <div>
                  <p className="text-2xl font-black text-blue-600">100%</p>
                  <p className="text-[10px] text-slate-400 uppercase tracking-widest font-black">Made in Japan</p>
                </div>
              </div>
            </div>

            {/* Right Column: 3D Image Card & Dynamic Google Meet Scheduler */}
            <div className="lg:col-span-6 flex flex-col gap-6 justify-center">
              
              {/* Premium 3D Hero Photo Frame */}
              <div className="relative group rounded-3xl overflow-hidden shadow-3d hover:shadow-3d-hover border border-slate-200 bg-white p-3 transition-all duration-500 hover:scale-[1.01] hover:border-blue-400 perspective-1000 transform hover:rotate-y-2 hover:-rotate-x-1">
                {/* Visual Ambient Spotlights */}
                <div className="absolute -top-12 -right-12 h-36 w-36 bg-sky-200/20 rounded-full blur-2xl pointer-events-none group-hover:bg-sky-200/40 transition-colors" />
                <div className="absolute -bottom-12 -left-12 h-36 w-36 bg-blue-105/20 rounded-full blur-2xl pointer-events-none group-hover:bg-blue-105/40 transition-colors" />

                <div className="h-60 sm:h-64 rounded-2xl overflow-hidden relative bg-slate-50/55 flex items-center justify-center p-4">
                  <img
                    referrerPolicy="no-referrer"
                    src={k8Img}
                    alt="Premium Kangen restructurer with molecular hydrogen water glass"
                    className="max-h-[74%] max-w-full object-contain transform scale-100 group-hover:scale-[1.03] transition-all duration-750 pb-2"
                  />
                  {/* Frosted details ribbon inside photo */}
                  <div className="absolute bottom-3 left-3 right-3 bg-white/95 backdrop-blur-md border border-slate-205/60 rounded-xl p-3 shadow-lg flex items-center justify-between">
                    <div>
                      <p className="text-[8px] font-mono tracking-widest font-extrabold text-blue-600 uppercase">Enagic Medical Grade</p>
                      <h4 className="text-xs font-black text-slate-900 mt-0.5">LeveLuk K8 Ionizer Model</h4>
                    </div>
                    <span className="text-[9px] bg-blue-600 text-white hover:bg-blue-700 px-2.5 py-1 rounded font-black font-mono select-none">
                      8 Solid Pt-Ti Plates
                    </span>
                  </div>
                </div>
              </div>

              {/* Dynamic Scheduler Panel */}
              <div className="relative w-full bg-white border border-slate-200 p-5 rounded-2xl shadow-3d hover:shadow-3d-hover transition-all text-left">
                <div className="absolute top-2 right-2 flex items-center space-x-1">
                  <span className={`h-2 w-2 rounded-full ${isMeetingLive ? 'bg-red-500 animate-ping' : 'bg-emerald-500'}`} />
                  <span className="text-[9px] text-slate-455 font-mono font-bold uppercase tracking-wider">{isMeetingLive ? 'MEET ACTIVE' : 'NEXT LIVE'}</span>
                </div>

                <div className="space-y-4 font-sans">
                  <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center space-x-3">
                    <Clock className="h-5 w-5 text-blue-600 shrink-0" />
                    <div>
                      <h4 className="text-xs font-black text-slate-900 uppercase">Live Demo VC Schedule</h4>
                      <p className="text-[10px] text-slate-500 font-semibold leading-none mt-1">Daily: 8:00 PM IST</p>
                    </div>
                  </div>

                  <div className="space-y-1.5 text-center py-3 bg-slate-50 rounded-xl border border-dashed border-slate-200 relative overflow-hidden">
                    <span className="text-[9px] text-slate-400 tracking-wider uppercase font-mono font-black block">Time left to start next meeting</span>
                    <p className={`text-2xl font-black ${isMeetingLive ? 'text-red-600 animate-pulse' : 'text-slate-900'} font-mono`}>
                      {countdownStr}
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h5 className="text-[10px] uppercase font-mono font-black text-blue-605 tracking-tight">Today's Meeting Objective</h5>
                    <p className="text-slate-500 text-[11px] leading-relaxed font-semibold">
                      We demonstrate the Enagic machine in real-time, explaining pH testing, negative ORP antioxidant properties, pesticide micro-clustering, and the detailed 8-Point commission model.
                    </p>
                    
                    <ul className="space-y-1.5 text-[10px] text-slate-700 font-bold">
                      <li className="flex items-center space-x-1.5">
                        <CheckCircle className="h-3.5 w-3.5 text-blue-600 inline" />
                        <span>Real pH & ORP scientific verification</span>
                      </li>
                      <li className="flex items-center space-x-1.5">
                        <CheckCircle className="h-3.5 w-3.5 text-blue-600 inline" />
                        <span>Patented Member Commission Plan</span>
                      </li>
                    </ul>
                  </div>

                  <div className="pt-2">
                    {canJoinMeeting ? (
                      <button
                        onClick={() => {
                          setIsZoomModalOpen(true);
                          setRsvpSuccess(false);
                          setRsvpError('');
                        }}
                        className="w-full py-3 bg-[#004BE6] hover:bg-blue-700 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl shadow-[0_4px_14px_rgba(0,75,230,0.4)] hover:shadow-lg hover:shadow-blue-500/20 hover:scale-[1.02] hover:-translate-y-0.5 active:scale-[98] transition-all duration-200 flex items-center justify-center space-x-2 cursor-pointer hover-shine"
                      >
                        <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
                        <span>Join Live Zoom Demo</span>
                        <ExternalLink className="h-3.5 w-3.5" />
                      </button>
                    ) : (
                      <div className="space-y-2">
                        <button
                          disabled
                          className="w-full py-3 bg-slate-100 border border-slate-205 text-slate-400 font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all flex items-center justify-center space-x-2 cursor-not-allowed opacity-80"
                        >
                          <Lock className="h-3.5 w-3.5 text-slate-400" />
                          <span>Link Unlocks 30 Mins Before Start</span>
                        </button>
                        <p className="text-[9px] text-slate-400 italic text-center font-mono font-medium">
                          Note: Zoom controls will activate automatically 30 minutes before 8:00 PM IST start.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* 2. DYNAMIC 24/7 VIDEO DEMONSTRATION SIMULATOR SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-200/80 rounded-2xl p-6 sm:p-8 shadow-3d hover:shadow-3d-hover transition-all">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            
            {/* Player Side */}
            <div className="lg:col-span-7 flex flex-col justify-between">
              <div className="space-y-2 text-left mb-4">
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 bg-red-650 text-white text-[9px] rounded font-black tracking-widest uppercase animate-pulse">
                    Live 24/7 Stream
                  </span>
                  <p className="text-xs text-slate-400 font-mono font-bold flex items-center space-x-1">
                    <Users className="h-3.5 w-3.5 text-blue-600" />
                    <span>{spectators} distributors watching</span>
                  </p>
                </div>
                <h3 className="text-xl font-bold text-slate-900 leading-tight">
                  Kangen Water Restructuring & pH Chemical Testing
                </h3>
                <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                  Continuous live footage showcasing active electrolysis, emulsification, and pH reagent drops. Watch how standard tap water compares visually with Kangen.
                </p>
              </div>

              {/* Video Player Display Card */}
              <div className="bg-slate-950 aspect-video rounded-xl relative overflow-hidden border border-slate-800 flex flex-col justify-between shadow-2xl">
                
                {/* Floating Top Overlays */}
                <div className="absolute top-3 left-3 right-3 z-20 flex justify-between items-center pointer-events-none">
                  <span className="text-[8.5px] font-mono font-black text-white bg-slate-950/80 px-2.5 py-1 rounded border border-white/10 backdrop-blur-xs flex items-center space-x-1.5 shadow-md">
                    <span className="h-1.5 w-1.5 bg-red-500 rounded-full animate-ping" />
                    <span>Live Demonstration of Kangen machine</span>
                  </span>
                  
                  <span className="text-[8.5px] font-mono text-white bg-red-650 px-2.5 py-1 rounded uppercase font-black tracking-widest flex items-center space-x-1.5 shadow-[0_0_12px_rgba(239,68,68,0.85)] border border-red-500 animate-pulse">
                    <span className="h-1.5 w-1.5 bg-white rounded-full" />
                    <span>Live</span>
                  </span>
                </div>

                {/* Shield layer to disable popout box clicks on fallback iframe */}
                {videoError && (
                  <div 
                    className="absolute top-0 right-0 w-20 h-20 bg-transparent z-30 pointer-events-auto cursor-default"
                    title="External download popout disabled"
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                    }}
                  />
                )}

                {/* Main Video content or iframe embed */}
                <div className="absolute inset-0 w-full h-full z-10 bg-black">
                  {videoError ? (
                    <iframe
                      src="https://drive.google.com/file/d/1S8tgYpxuGSgg7IbxxZXCEA-nYw2rizjJ/preview"
                      className="w-full h-full"
                      allow="autoplay; encrypted-media"
                      allowFullScreen
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <video
                      ref={videoRef}
                      src="https://docs.google.com/uc?export=download&id=1S8tgYpxuGSgg7IbxxZXCEA-nYw2rizjJ"
                      controls={false}
                      autoPlay
                      muted={isVideoMuted}
                      loop
                      playsInline
                      onLoadedMetadata={handleLoadedMetadata}
                      className="w-full h-full object-contain mx-auto"
                      onError={() => {
                        console.warn("Direct video stream failed/throttled. Resorting to safe preview iframe.");
                        setVideoError(true);
                      }}
                    />
                  )}
                </div>

                {/* Bottom Source Quality control overlay */}
                <div className="absolute bottom-3 left-3 bg-slate-950/80 py-1 px-2.5 rounded border border-white/10 text-[9px] font-mono text-slate-400 z-20 pointer-events-none">
                  <span>SOURCE FEED: YOUTUBE</span>
                </div>

                {/* Custom Controls Dock Overlay (HTML5 native stream only) */}
                {!videoError && (
                  <div className="absolute bottom-3 right-3 z-30 flex items-center space-x-1.5 bg-slate-900/90 border border-slate-800 rounded-lg p-1.5 shadow-lg backdrop-blur-xs">
                    {/* Backward 10s */}
                    <button
                      onClick={jumpBackward}
                      className="p-1 px-1.5 rounded text-xs font-mono font-bold text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all flex items-center space-x-0.5 cursor-pointer"
                      title="Jump Back 10s"
                    >
                      <RotateCcw className="h-3 w-3" />
                      <span className="text-[9px]">-10s</span>
                    </button>

                    {/* Play/Pause toggle */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (videoRef.current) {
                          if (isPlaying) {
                            videoRef.current.pause();
                            setIsPlaying(false);
                          } else {
                            videoRef.current.play().catch(err => console.log(err));
                            setIsPlaying(true);
                          }
                        }
                      }}
                      className="p-1 rounded text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all cursor-pointer"
                      title={isPlaying ? "Pause" : "Play"}
                    >
                      {isPlaying ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
                    </button>

                    {/* Forward 10s */}
                    <button
                      onClick={jumpForward}
                      className="p-1 px-1.5 rounded text-xs font-mono font-bold text-slate-300 hover:text-white hover:bg-slate-800/80 transition-all flex items-center space-x-0.5 cursor-pointer"
                      title="Jump Forward 10s"
                    >
                      <span className="text-[9px]">+10s</span>
                      <RotateCw className="h-3 w-3" />
                    </button>

                    <span className="w-px h-4 bg-slate-850" />

                    {/* Volume (Mute/Unmute) button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (videoRef.current) {
                          const newMuted = !isVideoMuted;
                          videoRef.current.muted = newMuted;
                          setIsVideoMuted(newMuted);
                        }
                      }}
                      className="p-1 px-2.5 rounded text-xs font-bold transition-all flex items-center space-x-1.5 bg-slate-800/60 hover:bg-slate-800 hover:text-white text-slate-200 cursor-pointer"
                      title={isVideoMuted ? "Unmute Sound" : "Mute Sound"}
                    >
                      {isVideoMuted ? (
                        <>
                          <VolumeX className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
                          <span className="text-[9px] text-amber-500 font-black uppercase tracking-tight">Click for Sound</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="h-3.5 w-3.5 text-emerald-400" />
                          <span className="text-[9px] text-emerald-400 font-black uppercase tracking-tight">Sound On</span>
                        </>
                      )}
                    </button>
                  </div>
                )}

              </div>
            </div>

            {/* Simulated Live Comments Feed Side */}
            <div className="lg:col-span-5 bg-slate-50 border border-slate-205 rounded-xl p-5 flex flex-col justify-between text-left">
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <h4 className="text-xs uppercase font-mono font-black text-slate-500 tracking-wider">Active Chat Reactions</h4>
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                </div>

                <div className="space-y-3.5 max-h-[220px] overflow-y-auto">
                  {streamComments.map((com) => (
                    <div key={com.id} className="text-xs bg-white border border-slate-150 p-2.5 rounded-xl shadow-xs">
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-bold text-slate-800">{com.user}</span>
                        <span className="text-[9px] text-slate-450 font-mono">{com.time}</span>
                      </div>
                      <p className="text-slate-600 font-medium leading-relaxed">{com.text}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200 flex items-center space-x-2">
                <input
                  type="text"
                  disabled
                  placeholder="Demo chat locks to registered club users..."
                  className="bg-white border border-slate-200 rounded-lg p-2.5 text-[10px] font-semibold text-slate-450 focus:outline-none flex-grow"
                />
                <button
                  disabled
                  className="p-2 bg-slate-200 text-slate-400 rounded-lg cursor-not-allowed"
                >
                  <Send className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 3. DYNAMIC COMPACT ELECTROLYSIS AND RESTORATION ANIMATION SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="text-center space-y-3 max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-blue-100/60 border border-blue-200 text-blue-600 rounded-full text-[10px] font-black uppercase">
            <HeartPulse className="h-4 w-4 text-blue-600 animate-pulse" />
            <span>Pure Science Visual Model</span>
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 leading-tight">
            How Kangen Generates Restructured Alkaline Water
          </h2>
          <p className="text-slate-500 text-xs font-semibold leading-relaxed">
            Witness the multi-stage purification and active ionic splitting chamber. Our animated laboratory model explains how platinum-charged titanium cells break up raw molecule groups.
          </p>
        </div>

        <ElectrolysisAnimation />
      </section>

      {/* 4. Interactive pH Water Explorer */}
      <section id="ph-explorer" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="text-center space-y-3 max-w-2xl mx-auto mb-10">
          <h2 className="text-3xl font-extrabold tracking-tight text-slate-900">
            Interactive pH Spectrum Explorer
          </h2>
          <p className="text-slate-500 text-xs font-semibold leading-relaxed">
            Enagic ionizers produce 5 distinct water types with customized pH balances. Click each block below to explore verified everyday household applications.
          </p>
        </div>

        {/* Custom selectors designed after color bands of acid/alkaline */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
          {WATER_TYPES.map((water) => {
            const isSelected = selectedPhType === water.id;
            return (
              <button
                id={`ph-selector-${water.id}`}
                key={water.id}
                onClick={() => setSelectedPhType(water.id)}
                className={`py-3.5 px-3 rounded-xl border text-center transition-all cursor-pointer relative overflow-hidden ${
                  isSelected
                    ? 'bg-white border-blue-500 ring-2 ring-blue-500/10 scale-102 shadow-lg shadow-blue-500/5'
                    : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs text-slate-700'
                }`}
              >
                <div
                  className="h-3 w-3 rounded-full mx-auto mb-2"
                  style={{ backgroundColor: water.color, boxShadow: `0 0 8px ${water.color}88` }}
                />
                <span className={`text-[11px] font-black block ${isSelected ? 'text-slate-900' : 'text-slate-500'}`}>{water.name}</span>
                <span className="text-base font-extrabold block mt-0.5" style={{ color: water.color }}>
                  pH {water.ph}
                </span>

                {isSelected && (
                  <div className="absolute top-0 right-0 p-1 bg-blue-600 rounded-bl-lg text-white">
                    <CheckCircle className="h-3 w-3 text-white" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Selected Water Type Detail Card Layout */}
        <div className="bg-white border border-slate-200/85 rounded-2xl p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start shadow-3d relative overflow-hidden text-left">
          <div className="absolute top-0 right-0 w-[200px] h-[200px] bg-blue-50/50 rounded-full blur-3xl pointer-events-none" />

          {/* Left Column: Text Details */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <span
                className="px-3 py-1 rounded text-[10px] font-extrabold text-white uppercase tracking-widest"
                style={{ backgroundColor: selectedWater.color, boxShadow: `0 0 8px ${selectedWater.color}44` }}
              >
                pH {selectedWater.ph} Spectrum
              </span>
              <span className="text-slate-400 text-xs font-mono font-bold">Enagic Certified</span>
            </div>

            <h3 className="text-2xl font-black text-slate-900">
              {selectedWater.name}
            </h3>

            <p className="text-slate-500 text-xs leading-relaxed font-semibold">
              {selectedWater.description}
            </p>

            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/60">
              <span className="text-[9px] text-slate-400 uppercase tracking-widest font-bold block mb-1 font-mono">
                Continuous Flow Mechanics
              </span>
              <p className="text-xs text-blue-600 font-semibold">
                Purely electrolyzed flow. Chemical-free restructuring of healthy alkaline minerals.
              </p>
            </div>
          </div>

          {/* Right Column: Applications Checklists - The Benefits */}
          <div className="space-y-4">
            <h4 className="text-xs uppercase tracking-widest text-blue-600 font-mono font-bold">
              Primary Everyday Applications & Benefits
            </h4>
            <div className="space-y-2.5">
              {selectedWater.uses.map((use, idx) => (
                <div
                  key={idx}
                  className="flex items-start space-x-3 bg-white border border-slate-200/60 hover:border-blue-500/20 hover:bg-blue-50/10 p-3.5 rounded-xl transition-all shadow-xs"
                >
                  <div className="h-5 w-5 rounded-full bg-blue-50 flex items-center justify-center shrink-0 border border-blue-200 mt-0.5">
                    <Droplet className="h-3 w-3 text-blue-600" />
                  </div>
                  <p className="text-xs text-slate-650 leading-relaxed font-semibold">
                    {use}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 5. HIGH PROFILE CELEBRITIES SECTION */}
      <section id="celebrities-sec" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="text-center space-y-3 max-w-2xl mx-auto mb-8">
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 bg-blue-105 border border-blue-200 rounded-full text-xs text-blue-600 font-bold">
            <Award className="h-3.5 w-3.5 text-blue-600 animate-pulse" />
            <span>High-Performing Athletes & Icons</span>
          </div>
          <h2 className="text-3xl font-extrabold tracking-tight text-slate-900">
            Top Worldwide & Indian Celebrity Advocates
          </h2>
          <p className="text-slate-500 text-xs font-semibold leading-relaxed">
            Distinguished global figures, Microsoft founders, and Indian sports icons trust Kangen or specialized electrolyzed alkaline hydration daily to safeguard their focus and cell longevity.
          </p>
        </div>

        {/* Endless Sliding Carousel Container */}
        <div ref={celebrityContainerRef} className="relative w-full overflow-hidden py-4 px-4 select-none">
          {/* Subtle Left and Right Vignette Fade Masks */}
          <div className="absolute left-0 top-0 bottom-0 w-8 sm:w-24 bg-gradient-to-r from-slate-50/90 to-transparent z-20 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-8 sm:w-24 bg-gradient-to-l from-slate-50/90 to-transparent z-20 pointer-events-none" />

          {/* Interactive touch-swipe and drag-scrollable track with hidden scrollbars */}
          <div 
            ref={celebrityScrollRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUpOrLeave}
            onMouseLeave={handleMouseUpOrLeave}
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            className="flex flex-row gap-5 sm:gap-6 overflow-x-auto scrollbar-none py-8 select-none cursor-grab active:cursor-grabbing active:scale-[0.99] transition-transform duration-100"
            style={{ WebkitOverflowScrolling: 'touch' }}
          >
            {[
              ...CELEBRITIES,
              ...CELEBRITIES,
              ...CELEBRITIES
            ].map((cel, idx) => {
              const isHovered = hoveredCelebIndex === idx;
              const isClicked = clickedCelebIndex === idx;
              const isActive = isHovered || isClicked;

              return (
                <div
                  key={`${cel.id}-${idx}`}
                  onMouseEnter={() => setHoveredCelebIndex(idx)}
                  onMouseLeave={() => setHoveredCelebIndex(null)}
                  onClick={(e) => {
                    e.stopPropagation();
                    if (clickedCelebIndex === idx) {
                      setClickedCelebIndex(null);
                    } else {
                      setClickedCelebIndex(idx);
                    }
                  }}
                  className={`bg-white border rounded-2xl flex flex-col justify-between transition-all duration-300 relative shrink-0 ${
                    isActive 
                      ? 'w-[285px] sm:w-[330px] md:w-[385px] scale-105 sm:scale-108 md:scale-110 z-30 ring-2 ring-blue-500/50 shadow-2xl bg-gradient-to-br from-slate-900 to-indigo-950 text-white border-blue-400 p-4 sm:p-5' 
                      : 'w-[185px] sm:w-[225px] md:w-[285px] z-10 border-slate-205 shadow-3d hover:border-slate-300 p-3 sm:p-4 md:p-5 text-slate-800'
                  }`}
                >
                  <div className="space-y-3 sm:space-y-4 relative">
                    {/* Explicit visual dismissal icon in highlighted state so user can clear focus instantly */}
                    {isClicked && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setClickedCelebIndex(null);
                          setHoveredCelebIndex(null);
                        }}
                        className="absolute -top-1 -right-1 p-1 rounded-full bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer z-40"
                        title="Dismiss and resume slide"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    )}

                    {/* Header containing the celebrity image */}
                    <div className="flex items-center space-x-3">
                      <div className={`relative rounded-full overflow-hidden border p-0.5 shrink-0 transition-all duration-300 ${
                        isActive 
                          ? 'h-10 w-10 sm:h-12 w-12 md:h-16 md:w-16 border-cyan-404 bg-slate-950' 
                          : 'h-8 w-8 sm:h-10 w-10 md:h-14 md:w-14 border-blue-105 bg-slate-50'
                      }`}>
                        <img
                          referrerPolicy="no-referrer"
                          src={cel.image}
                          alt={cel.name}
                          className="h-full w-full object-cover rounded-full"
                        />
                      </div>
                      <div>
                        <h3 className={`font-extrabold tracking-tight transition-colors duration-250 leading-tight ${
                          isActive 
                            ? 'text-white text-xs sm:text-sm md:text-base' 
                            : 'text-slate-900 text-[10px] sm:text-xs md:text-sm'
                        }`}>
                          {cel.name}
                        </h3>
                        <p className={`font-bold uppercase tracking-wider mt-0.5 leading-none shrink-0 ${
                          isActive 
                            ? 'text-cyan-400 text-[8px] sm:text-[9px] md:text-[10px]' 
                            : 'text-blue-600 text-[7px] sm:text-[8px] md:text-[9px]'
                        }`}>
                          {cel.role}
                        </p>
                      </div>
                    </div>

                    {/* Testimonial Quote wrapper */}
                    <div className={`relative rounded-xl border p-2.5 sm:p-3 md:p-3.5 text-left transition-all duration-300 ${
                      isActive 
                        ? 'bg-slate-950/70 border-slate-800' 
                        : 'bg-slate-50 border-slate-200'
                    }`}>
                      <Quote className={`absolute top-2 left-2 transition-colors ${
                        isActive ? 'h-3.5 w-3.5 text-cyan-400/80' : 'h-3 w-3 sm:h-3.5 sm:w-3.5 text-blue-350'
                      }`} />
                      <p className={`italic pl-4 text-left font-semibold leading-relaxed transition-all duration-300 ${
                        isActive 
                          ? 'text-[11px] sm:text-xs text-slate-100 line-clamp-none animate-fade-in' 
                          : 'text-[9px] sm:text-[10px] md:text-xs text-slate-500 line-clamp-3 sm:line-clamp-4'
                      }`}>
                        {cel.quote}
                      </p>
                    </div>
                  </div>

                  {/* Footer Advocate Tag */}
                  <div className={`pt-3 mt-3 border-t text-center transition-colors ${
                    isActive ? 'border-slate-800' : 'border-slate-100'
                  }`}>
                    <span className={`uppercase tracking-widest font-black block ${
                      isActive 
                        ? 'text-[7.5px] sm:text-[8.5px] text-[#22d3ee]' 
                        : 'text-[7px] sm:text-[7.5px] text-slate-400'
                    }`}>
                      Electrolyzed Hydration Advocate
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 6. CLIENT TESTIMONIALS SECTION */}
      <section id="testimonials-sec" className="bg-white py-16 border-y border-slate-200 text-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-4 space-y-5 text-center lg:text-left">
              <span className="text-blue-600 text-xs font-mono font-bold tracking-widest uppercase block bg-blue-55 px-3 py-1 rounded-full border border-blue-200 inline-block">
                BUILDING CREDIBILITY & TRUST
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl text-slate-900">
                What Our Customers Say
              </h2>
              <p className="text-slate-500 text-xs font-semibold leading-relaxed">
                From high-performing athletes to concerned families, Kangen Water delivers noticeable improvements in systemic health, toxic washing, and overall metabolic vitality.
              </p>
              <div className="flex items-center justify-center lg:justify-start space-x-1.5 text-yellow-500 pt-2">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-current" />
                ))}
                <span className="text-slate-900 text-sm font-extrabold pl-1.5">4.9 / 5 Overall Score</span>
              </div>
            </div>

            <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
              {TESTIMONIALS.map((test) => (
                <div
                  key={test.id}
                  className="bg-white border border-slate-200 rounded-2xl p-6 shadow-3d hover-lift hover-glow-cyan font-sans text-left"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="h-9 w-9 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 font-mono font-black text-sm">
                        {test.name[0]}
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-900 text-sm leading-tight">{test.name}</h4>
                        <p className="text-[10px] text-slate-400 font-semibold">{test.role}</p>
                      </div>
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono font-bold italic">{test.location}</span>
                  </div>

                  <p className="text-xs text-slate-500 italic leading-relaxed font-semibold">
                    &ldquo;{test.text}&rdquo;
                  </p>

                  <div className="flex items-center space-x-1 mt-4 text-yellow-500">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="h-3 w-3 fill-current" />
                    ))}
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>
      </section>

      {/* 7. Replicated Certifications Section matching attached photo */}
      <CertificationsSection />

      {/* Zoom Lead Collection Form Modal Overlay */}
      <AnimatePresence>
        {isZoomModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsZoomModalOpen(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs cursor-default"
            />

            {/* Modal Card content */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: "spring", duration: 0.4 }}
              className="relative w-full max-w-md bg-white rounded-2xl border border-slate-200 p-6 md:p-8 shadow-2xl relative z-10 pointer-events-auto text-left"
            >
              {/* Header */}
              <div className="space-y-2">
                <span className="text-[10px] text-blue-600 font-mono font-black tracking-widest uppercase block bg-blue-50 px-2.5 py-1 rounded inline-block">
                  Secure Webinar Access
                </span>
                <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center space-x-2">
                  <span>Enter Details to Join Zoom</span>
                </h3>
                <p className="text-slate-500 text-xs font-semibold leading-relaxed">
                  To complete your digital reservation and activate the live Zoom demo streaming portal, please fill in your details.
                </p>
              </div>

              {/* Form */}
              <form onSubmit={handleRsvpSubmit} className="mt-6 space-y-4 font-sans">
                {rsvpError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs font-bold text-red-650">
                    {rsvpError === 'NAME_REQUIRED' && '⚠️ Please enter your Full Name.'}
                    {rsvpError === 'CITY_REQUIRED' && '⚠️ Please specify your City.'}
                    {rsvpError === 'MOBILE_REQUIRED' && '⚠️ Please enter your Mobile Number.'}
                    {rsvpError === 'MOBILE_INVALID' && '⚠️ Mobile Number must be at least 10 digits.'}
                  </div>
                )}

                {rsvpSuccess ? (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-2 py-6">
                    <CheckCircle className="h-10 w-10 text-emerald-600 mx-auto animate-bounce" />
                    <h4 className="text-sm font-black text-slate-900">Registration Success!</h4>
                    <p className="text-xs text-slate-500 font-semibold px-2">
                      Your invite is verified. Launching Zoom webinar session in a new window...
                    </p>
                    <p className="text-[10px] text-slate-400 font-bold block pt-2">
                      If it didn't open automatically, <a href="https://us06web.zoom.us/j/88000074852?pwd=IcsNbGCDaZMqQls3mqc1IVY6lsB5Jw.1" target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">click here to bypass &rarr;</a>
                    </p>
                  </div>
                ) : (
                  <>
                    {/* Full Name */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider block">Full Name</label>
                      <div className="relative rounded-lg shadow-xs">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                          <User className="h-4 w-4" />
                        </div>
                        <input
                          type="text"
                          required
                          placeholder="E.g. Chetan Singh"
                          value={rsvpName}
                          onChange={(e) => setRsvpName(e.target.value)}
                          className="block w-full pl-10 pr-3 py-2 text-sm bg-slate-50 hover:bg-slate-50/50 focus:bg-white border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 rounded-lg outline-none font-bold text-slate-900 transition-all placeholder:text-slate-350"
                        />
                      </div>
                    </div>

                    {/* City / Town */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider block">City / Town</label>
                      <div className="relative rounded-lg shadow-xs">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                          <MapPin className="h-4 w-4" />
                        </div>
                        <input
                          type="text"
                          required
                          placeholder="E.g. Faridabad"
                          value={rsvpCity}
                          onChange={(e) => setRsvpCity(e.target.value)}
                          className="block w-full pl-10 pr-3 py-2 text-sm bg-slate-50 hover:bg-slate-50/50 focus:bg-white border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 rounded-lg outline-none font-bold text-slate-900 transition-all placeholder:text-slate-350"
                        />
                      </div>
                    </div>

                    {/* Mobile Number */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider block">Mobile Number</label>
                      <div className="relative rounded-lg shadow-xs">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                          <Phone className="h-4 w-4" />
                        </div>
                        <input
                          type="tel"
                          required
                          placeholder="E.g. +91 98765 43210"
                          value={rsvpMobile}
                          onChange={(e) => setRsvpMobile(e.target.value)}
                          className="block w-full pl-10 pr-3 py-2 text-sm bg-slate-50 hover:bg-slate-50/50 focus:bg-white border border-slate-200 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 rounded-lg outline-none font-bold text-slate-900 transition-all placeholder:text-slate-350"
                        />
                      </div>
                    </div>

                    {/* Special Invitation Note Card */}
                    <div className="p-3 bg-amber-50/75 border border-amber-200/60 rounded-xl text-left shadow-xs mt-2">
                      <p className="text-[10px] text-amber-800 font-extrabold uppercase tracking-wide font-mono mb-1">📋 Official Invitation Details</p>
                      <p className="text-slate-750 text-xs font-black italic">
                        Invitation By: Chetan Pundeer, Team faridabad.
                      </p>
                    </div>

                    {/* Submit Button */}
                    <div className="pt-2 flex space-x-3">
                      <button
                        type="button"
                        onClick={() => setIsZoomModalOpen(false)}
                        className="w-1/3 py-2.5 px-3 border border-slate-200 hover:border-slate-300 text-slate-600 hover:text-slate-800 font-extrabold text-xs uppercase tracking-wider rounded-lg transition-colors cursor-pointer text-center"
                      >
                        Go Back
                      </button>
                      <button
                        type="submit"
                        disabled={isRsvpSubmitting}
                        className="w-2/3 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-450 disabled:cursor-not-allowed text-white font-extrabold text-xs uppercase tracking-wider rounded-lg transition-all shadow-md hover:shadow-lg flex items-center justify-center space-x-2 cursor-pointer"
                      >
                        {isRsvpSubmitting ? (
                          <>
                            <span className="h-3 w-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            <span>Verifying...</span>
                          </>
                        ) : (
                          <>
                            <span>Join Webinar Room &rarr;</span>
                          </>
                        )}
                      </button>
                    </div>
                  </>
                )}
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
