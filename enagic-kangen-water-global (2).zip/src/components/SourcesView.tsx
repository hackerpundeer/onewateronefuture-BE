import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  ExternalLink, 
  CheckCircle, 
  Award, 
  FileText, 
  Droplet, 
  FlaskConical, 
  ShieldCheck, 
  Scale,
  Compass,
  Flame,
  Activity,
  Heart,
  Globe
} from 'lucide-react';

const gangotriImg = 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=600';
const hunzaImg = 'https://images.unsplash.com/photo-1549490349-8643362247b5?auto=format&fit=crop&q=80&w=600';
const tlacoteImg = 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?auto=format&fit=crop&q=80&w=600';
const nordenauImg = 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&q=80&w=600';
const lourdesImg = 'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&q=80&w=600';
const zamzamImg = 'https://images.unsplash.com/photo-1596120233897-6a4a2ea49206?auto=format&fit=crop&q=80&w=800';

export default function SourcesView() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'clinical' | 'regulatory' | 'molecular'>('all');

  const sources = [
    {
      id: 'src-1',
      title: "Japanese Ministry of Health, Labour and Welfare - Approval No. 21B-1481",
      category: "regulatory",
      description: "Official governmental authorization classifying Enagic's continuous electrolytic water generator as a certified medical device for gastrointestinal health and metabolic relief.",
      relevance: "Classifies Kangen Water devices as genuine medical apparatuses rather than simple filters.",
      year: "1987 / Revised 2005",
      type: "Official Government Decree",
      url: "https://www.mhlw.go.jp/english/"
    },
    {
      id: 'src-2',
      title: "Nature Medicine: Molecular Hydrogen acts as a Therapeutic Antioxidant (Ohno et al.)",
      category: "clinical",
      description: "Landmark publication proving that molecular hydrogen (H2) selectively neutralizes cytotoxic oxygen radicals (such as hydroxyl radicals) in cells without disturbing physiological vital pathways.",
      relevance: "Validates the primary molecular mechanism of Kangen Water's active antioxidant power.",
      year: "2007",
      type: "Peer-Reviewed Scientific Journal",
      url: "https://www.nature.com/articles/nm1577"
    },
    {
      id: 'src-3',
      title: "ISO 13485:2016 Medical Devices — Quality Management Systems",
      category: "regulatory",
      description: "International standard specifying requirements for a quality management system where an organization needs to demonstrate its ability to provide medical devices that consistently meet customer and regulatory requirements.",
      relevance: "Guarantees that Enagic's Osaka plant manufactures machines under absolute pharmaceutical grade quality audits.",
      year: "2016",
      type: "International Compliance Certificate",
      url: "https://www.iso.org/standard/59752.html"
    },
    {
      id: 'src-4',
      title: "Water Quality Association (WQA) Gold Seal Certification",
      category: "regulatory",
      description: "Enagic USA and Enagic international machines are awarded the coveted solid Gold Seal under NSF/ANSI standards for chlorine and heavy metal reduction integrity.",
      relevance: "Verifies the safety, mechanical stability, and high performance of raw carbon filter inserts.",
      year: "Annual Certification",
      type: "Independent Water Sanitation Seal",
      url: "https://www.wqa.org/"
    },
    {
      id: 'src-5',
      title: "Antioxidant Effects of Reduced Water on Oxidative Stress (Miyashita et al.)",
      category: "clinical",
      description: "Clinical study verifying that drinking electrolyzed alkaline reduced water (ERW) shields human DNA, RNA, and protein polymers from oxidative damage and prevents hydrogen peroxide-induced cell apoptosis.",
      relevance: "Clinical trials that verify cell longevity claims and oxidative resistance.",
      year: "2012",
      type: "Clinical Toxicology Bulletin",
      url: "https://pubmed.ncbi.nlm.nih.gov/"
    },
    {
      id: 'src-6',
      title: "Molecular Hydrogen Foundation — Hydrogen Gas Research & Biological Benefits",
      category: "molecular",
      description: "Comprehensive scientific database detailing over 1,000 global studies demonstrating molecular hydrogen's therapeutic potential in 170+ human disease models.",
      relevance: "Central library documenting global consensus on active thermodynamic properties of dissolved hydrogen.",
      year: "Ongoing Repository",
      type: "Global Scientific Panel",
      url: "http://www.molecularhydrogeninstitute.org/"
    },
    {
      id: 'src-7',
      title: "Effects of Drinking hydrogen-rich water on Quality of Life of patients treated with radiotherapy",
      category: "clinical",
      description: "A randomized, double-blind, placebo-controlled study showing that drinking hydrogen-rich water daily significantly reduced liver lipid peroxides and improved vital baseline indices without adverse toxicity.",
      relevance: "Clinical patient evidence for physical well-being improvement.",
      year: "2011",
      type: "Medical Oncology Journal",
      url: "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3257754/"
    }
  ];

  const filteredSources = sources.filter(src => {
    const matchesSearch = src.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          src.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          src.relevance.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'all' || src.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 pb-20 font-sans text-left">
      
      {/* Hero Header bar */}
      <section className="bg-gradient-to-b from-blue-900 to-indigo-950 text-white py-16 px-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-blue-550/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-[200px] h-[200px] bg-sky-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="max-w-6xl mx-auto space-y-4 relative z-10 text-center sm:text-left">
          <span className="text-[10px] uppercase font-mono font-black tracking-widest bg-blue-600/50 border border-blue-400 px-3 py-1 rounded-full text-blue-200">
            Transparent Science Repository
          </span>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight leading-none">
            Public Scientific & <br />
            <span className="text-cyan-400 italic font-serif text-2xl sm:text-4xl block mt-1">Regulatory Knowledge Base</span>
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm font-semibold max-w-3xl leading-relaxed">
            At One Water One Future.org, we believe in radical transparency. Every medical device claim, antioxidant property, pH level, and global wellness benefit is grounded directly in official ISO regulations and peer-reviewed biochemical studies.
          </p>
        </div>
      </section>

      {/* Main Filter & Search Content */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 space-y-8">
        
        {/* Statistics & Trust Blocks */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-3d flex items-start space-x-3.5">
            <div className="h-10 w-10 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600 shrink-0 border border-blue-200">
              <FlaskConical className="h-5 w-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-[#0f172a] text-sm">1,000+ Peer Studies</h4>
              <p className="text-[11px] text-slate-500 font-bold leading-relaxed mt-1">
                Molecular hydrogen (H₂) is subject to extensive medical research exploring its selective cellular antioxidant properties.
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-3d flex items-start space-x-3.5">
            <div className="h-10 w-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0 border border-emerald-200">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-[#0f172a] text-sm">Medical OEM Standard</h4>
              <p className="text-[11px] text-slate-500 font-bold leading-relaxed mt-1">
                Manufactured under high level ISO 13485 (Medical Equipment class) parameters inside Enagic's Osaka plant.
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-3d flex items-start space-x-3.5">
            <div className="h-10 w-10 rounded-xl bg-amber-100 flex items-center justify-center text-amber-600 shrink-0 border border-amber-200">
              <Award className="h-5 w-5" />
            </div>
            <div>
              <h4 className="font-extrabold text-[#0f172a] text-sm">WQA Gold Seals</h4>
              <p className="text-[11px] text-slate-500 font-bold leading-relaxed mt-1">
                Awarded four consecutive years by the Water Quality Association under strict ANSI purification evaluations.
              </p>
            </div>
          </div>
        </div>

        {/* Water from Natural Source - KANGEN PPT Revised-2026 */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-3d space-y-6 relative overflow-hidden">
          {/* PPT Sticker Tag */}
          <div className="absolute top-0 right-0 bg-blue-600 text-[9px] font-mono font-bold text-white px-3 py-1 rounded-bl-xl tracking-wider uppercase shadow-xs">
            KANGEN PPT Revised-2026
          </div>

          <div className="border-b border-slate-100 pb-5 text-left">
            <span className="text-[10px] uppercase font-mono font-black text-blue-650 tracking-widest block mb-1">
              Natural Healing Waters Analysis
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight flex items-center space-x-2">
              <span>Water from Natural Source</span>
            </h2>
            <div className="h-1.5 w-32 bg-blue-600 rounded-full mt-2" />
          </div>

          {/* Interactive Bento Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left Column: 5 Main Sources (7 shares of cols) */}
            <div className="lg:col-span-7 space-y-4">
              <h3 className="text-xs font-mono font-black uppercase text-slate-400 tracking-widest text-left mb-2">
                Globally Renowned Subterranean & Springs
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* 1. Gangotri at Himalayas */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden transition-all hover:bg-slate-100/70 hover:border-blue-200 group">
                  <div className="h-28 overflow-hidden relative">
                    <img 
                      src={gangotriImg} 
                      alt="Gangotri at Himalayas" 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent" />
                    <span className="absolute bottom-2 left-3 text-[10px] uppercase font-mono font-bold text-white bg-blue-600/80 px-2 py-0.5 rounded backdrop-blur-xs">Himalayan Peak Runoff</span>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-1.5">
                      <span className="h-2 w-2 rounded-full bg-blue-500 shrink-0" />
                      <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-tight">Gangotri at Himalayas</h4>
                    </div>
                    <p className="text-[11px] font-medium leading-relaxed text-slate-500">
                      High-altitude glacial meltwater springing directly from pristine Himalayan peaks, legendary for its physical structure and active molecular clustering.
                    </p>
                  </div>
                </div>

                {/* 2. Tlacote, Mexico */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden transition-all hover:bg-slate-100/70 hover:border-blue-200 group">
                  <div className="h-28 overflow-hidden relative">
                    <img 
                      src={tlacoteImg} 
                      alt="Tlacote, Mexico" 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent" />
                    <span className="absolute bottom-2 left-3 text-[10px] uppercase font-mono font-bold text-white bg-blue-600/80 px-2 py-0.5 rounded backdrop-blur-xs">Artesian Healing Spring</span>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-1.5">
                      <span className="h-2 w-2 rounded-full bg-blue-500 shrink-0" />
                      <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-tight">Tlacote, Mexico</h4>
                    </div>
                    <p className="text-[11px] font-medium leading-relaxed text-slate-500">
                      A highly celebrated artesian well source in Mexico, natural tests reveal rich mineral ionization and highly unique, therapeutic alkaline pH.
                    </p>
                  </div>
                </div>

                {/* 3. Nordenau, Germany */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden transition-all hover:bg-slate-100/70 hover:border-blue-200 group">
                  <div className="h-28 overflow-hidden relative">
                    <img 
                      src={nordenauImg} 
                      alt="Nordenau, Germany" 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent" />
                    <span className="absolute bottom-2 left-3 text-[10px] uppercase font-mono font-bold text-white bg-blue-600/80 px-2 py-0.5 rounded backdrop-blur-xs">Slate Cavern Hydration</span>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-1.5">
                      <span className="h-2 w-2 rounded-full bg-blue-500 shrink-0" />
                      <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-tight">Nordenau, Germany</h4>
                    </div>
                    <p className="text-[11px] font-medium leading-relaxed text-slate-500">
                      A pure underground slate spring. Highly certified and protected German spring water noted for rich dissolved gases and therapeutic benefits.
                    </p>
                  </div>
                </div>

                {/* 4. Lourdes, France */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden transition-all hover:bg-slate-100/70 hover:border-blue-200 group">
                  <div className="h-28 overflow-hidden relative">
                    <img 
                      src={lourdesImg} 
                      alt="Lourdes, France" 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent" />
                    <span className="absolute bottom-2 left-3 text-[10px] uppercase font-mono font-bold text-white bg-blue-600/80 px-2 py-0.5 rounded backdrop-blur-xs">Sacred Sanctuary Flow</span>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-1.5">
                      <span className="h-2 w-2 rounded-full bg-blue-500 shrink-0" />
                      <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-tight">Lourdes, France</h4>
                    </div>
                    <p className="text-[11px] font-medium leading-relaxed text-slate-500">
                      World-renowned mountain sanctuary spring, verified to possess unique structural potential and high anti-free-radical support.
                    </p>
                  </div>
                </div>

                {/* 5. Zam Zam */}
                <div className="bg-slate-50 border border-slate-200 rounded-xl overflow-hidden transition-all hover:bg-slate-100/70 hover:border-blue-200 sm:col-span-2 group">
                  <div className="sm:grid sm:grid-cols-12 h-full">
                    <div className="sm:col-span-5 h-36 sm:h-full relative overflow-hidden">
                      <img 
                        src={zamzamImg} 
                        alt="Zam Zam well" 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-slate-950/60 to-transparent" />
                      <span className="absolute bottom-2 left-3 text-[10px] uppercase font-mono font-bold text-white bg-blue-600/80 px-2 py-0.5 rounded backdrop-blur-xs">Medicinal Alkaline Well</span>
                    </div>
                    <div className="sm:col-span-7 p-4 flex flex-col justify-center">
                      <div className="flex items-center space-x-2 mb-1.5">
                        <span className="h-2 w-2 rounded-full bg-blue-500 shrink-0" />
                        <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-tight">Zam Zam</h4>
                      </div>
                      <p className="text-[11px] font-medium leading-relaxed text-slate-500">
                        The historic, naturally alkaline desert well water. Exceptionally rich in therapeutic essential trace minerals with long-documented metabolic benefits.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Key Feature - Hunza Valley (5 shares of cols) */}
            <div className="lg:col-span-5 bg-gradient-to-b from-emerald-900/10 to-teal-950/15 border border-emerald-250/30 rounded-2xl overflow-hidden flex flex-col justify-between relative group hover:border-emerald-500/40 transition-all duration-300">
              <div className="h-48 relative overflow-hidden">
                <img 
                  src={hunzaImg} 
                  alt="Hunza Valley mountains" 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                <span className="absolute top-3 right-3 text-[9px] font-mono font-black bg-emerald-600 text-white px-2.5 py-0.5 rounded tracking-wider uppercase shadow-xs">
                  Longevity Epicenter
                </span>
                <div className="absolute bottom-3 left-4 text-left">
                  <h4 className="text-lg font-black text-white">Hunza Valley</h4>
                  <p className="text-[10px] font-mono text-emerald-400 font-bold uppercase tracking-wider">Karakoram Range Peaks</p>
                </div>
              </div>
              
              <div className="p-5 flex-grow flex flex-col justify-between space-y-4">
                <p className="text-[11.5px] font-semibold leading-relaxed text-slate-650 text-left">
                  Nestled deep in the majestic Karakoram mountains, the Hunza population is globally famous for extraordinary well-being, longevity, and vitality.
                </p>

                {/* Longevity Claims Yellow/Dark Highlight card mimicking the PPT slide */}
                <div className="bg-slate-950 text-white p-4.5 rounded-xl border border-slate-800 shadow-lg text-left relative overflow-hidden">
                  <div className="absolute -top-10 -right-10 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl" />
                  <p className="text-xs font-black text-amber-400 leading-relaxed uppercase tracking-tight font-sans">
                    "The longest lived people on the Planet with 120 – 140 Years of age with virtually No Cancer, degenerative disease, dental caries or Bone Decay."
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100/50 flex items-center justify-between text-left">
                  <div className="flex items-center space-x-2">
                    <Heart className="h-4 w-4 text-emerald-600 shrink-0 animate-pulse" />
                    <span className="text-[10px] font-mono font-black text-slate-500 uppercase tracking-widest">Active Cellular Protection</span>
                  </div>
                  <Compass className="h-4 w-4 text-slate-400 shrink-0" />
                </div>
              </div>
            </div>

          </div>

          {/* Bottom Common Denominator Summary bar matching the slide keywords highlight */}
          <div className="mt-6 p-5 sm:p-6 bg-blue-50/50 border border-blue-100 rounded-2xl text-left space-y-3 relative overflow-hidden">
            <div className="absolute -top-12 -left-12 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl/20 lg:block hidden" />
            <div className="flex items-center space-x-2">
              <Globe className="h-4 w-4 text-blue-600 shrink-0" />
              <span className="text-[10px] font-mono font-black text-blue-600 tracking-widest uppercase">The Scientific Common Denominator</span>
            </div>
            
            <p className="text-xs sm:text-xs leading-relaxed text-slate-700 font-bold">
              Research has proven that the major common denominator of the healthy long-living people is their local water. <br className="hidden md:block" />
              They found Hunza Water had a <span className="text-emerald-700 font-extrabold uppercase bg-emerald-100/50 px-1.5 py-0.5 rounded">High Alkaline pH</span> and an extraordinary amount of <span className="text-blue-700 font-extrabold uppercase bg-blue-100/50 px-1.5 py-0.5 rounded">Active Hydrogen</span> with a <span className="text-red-600 font-extrabold uppercase bg-red-100/50 px-1.5 py-0.5 rounded">Negative Redox Potential</span>. 
              Water is <span className="text-blue-700 font-extrabold uppercase">LIVING</span> and provides profound Health Benefits.
            </p>
          </div>
        </div>

        {/* Search controls & Category Filters */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 shadow-3d flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          
          {/* Categories Tab selector */}
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeCategory === 'all' 
                  ? 'bg-blue-600 text-white shadow-xs' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              All Sources
            </button>
            <button
              onClick={() => setActiveCategory('clinical')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeCategory === 'clinical' 
                  ? 'bg-blue-600 text-white shadow-xs' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              Clinical Research
            </button>
            <button
              onClick={() => setActiveCategory('regulatory')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeCategory === 'regulatory' 
                  ? 'bg-blue-600 text-white shadow-xs' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              Regulatory Approvals
            </button>
            <button
              onClick={() => setActiveCategory('molecular')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeCategory === 'molecular' 
                  ? 'bg-blue-600 text-white shadow-xs' 
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              Hydrogen Science
            </button>
          </div>

          {/* Search box input */}
          <div className="relative flex-grow max-w-sm">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search studies or standard IDs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-blue-400 focus:bg-white font-semibold"
            />
          </div>
        </div>

        {/* Source List Card Container */}
        <div id="sources-results-container" className="space-y-6">
          {filteredSources.length > 0 ? (
            filteredSources.map((src) => (
              <div 
                key={src.id} 
                className="bg-white border border-slate-200 rounded-2xl p-6 shadow-3d hover:shadow-3d-hover hover:border-blue-300 transition-all text-left space-y-4 relative overflow-hidden"
              >
                {/* Decorative category stripe */}
                <span 
                  className={`absolute top-0 left-0 w-2 h-full ${
                    src.category === 'clinical' 
                      ? 'bg-emerald-500' 
                      : src.category === 'regulatory' 
                      ? 'bg-blue-600' 
                      : 'bg-indigo-500'
                  }`}
                />

                <div className="pl-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <span className="text-[9px] font-mono tracking-widest font-black uppercase text-indigo-650 bg-slate-100 px-2 py-0.5 rounded-md inline-block self-start">
                      {src.type}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono font-bold">
                      Published/Audited: {src.year}
                    </span>
                  </div>

                  <h3 className="text-base font-black text-slate-900 mt-2 leading-tight">
                    {src.title}
                  </h3>

                  <p className="text-slate-500 text-xs font-semibold leading-relaxed mt-2.5">
                    {src.description}
                  </p>

                  <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                    <div className="md:col-span-10 space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-150">
                      <span className="text-[8.5px] font-mono text-blue-600 font-black tracking-widest uppercase block">Why This Data Matters:</span>
                      <p className="text-xs text-slate-700 font-bold">
                        {src.relevance}
                      </p>
                    </div>

                    <div className="md:col-span-2 text-right">
                      <a 
                        href={src.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="py-2 px-3 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg text-[10px] font-black uppercase tracking-wider transition-colors inline-flex items-center space-x-1"
                      >
                        <span>Verify link</span>
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-16 bg-white border border-slate-200 rounded-2xl space-y-3">
              <BookOpen className="h-10 w-10 text-slate-400 mx-auto" />
              <p className="text-sm font-extrabold text-slate-800">No matching studies found.</p>
              <p className="text-xs text-slate-400 font-semibold">Try typing simple keywords like "hydrogen" or "Nature".</p>
              <button 
                onClick={() => { setSearchTerm(''); setActiveCategory('all'); }}
                className="text-xs font-black text-blue-600 hover:underline cursor-pointer"
              >
                Clear all filters
              </button>
            </div>
          )}
        </div>

        {/* Legal Disclaimer Box */}
        <div className="p-5 bg-amber-50/70 border border-amber-200 rounded-2xl flex items-start space-x-3">
          <Scale className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1.5 text-xs text-slate-700 leading-relaxed font-semibold">
            <h5 className="font-extrabold text-amber-900 uppercase">Public Information Notice & Educational Context</h5>
            <p className="text-slate-650">
              The studies linked above are compiled for historical, scientific, and educational reference only. While Enagic® high-performance medical systems are certified and regulated by the Japanese Ministry of Health, Labour and Welfare, they are intended to maintain and support cellular wellness. They are not marketed as a cure, diagnosis, or substitute for professional clinical medical therapy. All users are encouraged to reference peer-reviewed literature to enrich their physiological hydration literacy.
            </p>
          </div>
        </div>

      </section>
    </div>
  );
}
