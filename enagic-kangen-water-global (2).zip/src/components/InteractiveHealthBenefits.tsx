import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Snowflake, HeartPulse, RefreshCw, Zap, Droplets, Activity, CheckCircle2 } from 'lucide-react';

interface BenefitDetails {
  id: string;
  title: string;
  icon: React.ReactNode;
  accentColor: string;
  glowClass: string;
  tagline: string;
  summary: string;
  mechanism: string;
  comparativeStat: {
    standard: string;
    kangen: string;
    label: string;
  };
  metrics: { value: string; label: string }[];
}

export default function InteractiveHealthBenefits() {
  const [activeTab, setActiveTab] = useState<string>('hydration');
  const [hydrationSimType, setHydrationSimType] = useState<'standard' | 'kangen'>('kangen');

  const benefitsList: BenefitDetails[] = [
    {
      id: 'hydration',
      title: "1. Cellular Micro-Hydration",
      tagline: "Ultra-rapid cellular absorption from micro-clusters",
      icon: <Droplets className="h-6 w-6 text-blue-600" />,
      accentColor: "#2563eb",
      glowClass: "shadow-blue-500/5 border-blue-300",
      summary: "Normal tap or bottled water consists of large structural clumps of 15 to 26 water molecules. The electrolysis process breaks these bonds apart, restructuring them into ultra-fine micro-clusters of only 5 to 6 molecules. This allows water to easily pass through aquaporins (protein channels of cells) for rapid direct cellular replenishment.",
      mechanism: "Micro-clusters travel deep into muscle and organ tissues 3 times faster than standard water, preventing the bloating or heavy sloshing stomach feeling often felt when drinking high quantities during workout sessions.",
      comparativeStat: {
        standard: "15-20 molecules/cluster",
        kangen: "5-6 molecules/cluster",
        label: "Molecular Cluster Dimension"
      },
      metrics: [
        { value: "3.2x", label: "Absorption Speed" },
        { value: "100%", label: "Cellular Aquaporin Match" },
        { value: "Zero", label: "Bloating Index" }
      ]
    },
    {
      id: 'antioxidant',
      title: "2. Active Antioxidant Power",
      tagline: "Rich molecular hydrogen gas neutralizes free radicals",
      icon: <Zap className="h-6 w-6 text-amber-500" />,
      accentColor: "#d97706",
      glowClass: "shadow-amber-550/5 border-amber-300",
      summary: "Fresh Kangen Water is saturated with dissolved Molecular Hydrogen gas (H₂). As a selective antioxidant, H₂ donates free electrons specifically to neutralize cytotoxic reactive oxygen species (free radicals), turning them into harmless water inside the cell.",
      mechanism: "While bottled waters hold positive ORP (aging/oxidizing values of +200mV to +300mV), Kangen Water boasts a substantial negative ORP (-400mV to -800mV), delivering massive anti-inflammatory, anti-aging, and cell repairing energy with every single glass.",
      comparativeStat: {
        standard: "+250 mV (Oxidizing)",
        kangen: "-600 mV (Active Antioxidant)",
        label: "Oxidation-Reduction Potential (ORP)"
      },
      metrics: [
        { value: "-600mV", label: "Average negative ORP" },
        { value: "1.6 ppm", label: "Dissolved Hydrogen" },
        { value: "Millions", label: "Direct Free Electrons Offered" }
      ]
    },
    {
      id: 'detoxification',
      title: "3. Cellular Detoxification",
      tagline: "Deep toxic flush and metabolic waste removal",
      icon: <RefreshCw className="h-6 w-6 text-emerald-600" />,
      accentColor: "#059669",
      glowClass: "shadow-emerald-500/5 border-emerald-300",
      summary: "As water micro-clusters enter the cell and dissolve nutrients with higher solubility, they similarly clean out waste. The increased alkalinity and hydration speed up the detoxification of acidic debris structure, lactic acids, and environmental heavy toxins from individual tissue layers.",
      mechanism: "The superior dissolving and structural emulsification properties of Kangen Water help optimal renal and lymphatic flow, accelerating physical healing, clearing skin complexions, and reducing muscle fatigue build-up.",
      comparativeStat: {
        standard: "Weak organic solubility",
        kangen: "High pesticide-oil emulsification",
        label: "Waste Dissolving Strength"
      },
      metrics: [
        { value: "2.5x", label: "Greater Organic Solubility" },
        { value: "Optimal", label: "Lactic Acid Removal Rate" },
        { value: "100%", label: "Chemical-free Systemic Flush" }
      ]
    },
    {
      id: 'alkalization',
      title: "4. Systemic pH Alleviation",
      tagline: "Restoring stable, natural metabolic pH balance",
      icon: <HeartPulse className="h-6 w-6 text-purple-650" />,
      accentColor: "#7c3aed",
      glowClass: "shadow-purple-500/5 border-purple-300",
      summary: "Stress, carbonated beverages, lack of sleep, and highly processed diets overload our metabolic pathways with systemic acid. High pH alkaline minerals (Calcium, Mag, Potassium) act as a strong buffer, supporting homeostasis without draining critical calcium from bones and joint cartilage.",
      mechanism: "Provides safe bio-available minerals to flush out stored metabolic acids in the digestive linings, relieving popular symptoms of daily acid reflux and neutralizing inflammation.",
      comparativeStat: {
        standard: "Acidic pH 5.5 to Neutral 7.0",
        kangen: "Restorative pH 8.5 to 9.5",
        label: "Standard Hydration Potency"
      },
      metrics: [
        { value: "pH 9.5", label: "Consistent Active Alkalinity" },
        { value: "Alkaline", label: "Esophageal pepsin buffer" },
        { value: "Natural", label: "Acidic toxic defense" }
      ]
    }
  ];

  const currentBenefit = benefitsList.find(b => b.id === activeTab) || benefitsList[0];

  return (
    <div id="interactive-benefits-root" className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 text-slate-800 relative shadow-3d hover:shadow-3d-hover transition-all overflow-hidden font-sans text-left">
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-blue-100/20 rounded-full blur-3xl pointer-events-none" />
      
      <div className="space-y-8">
        {/* Header Title */}
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <span className="text-[10px] text-blue-600 font-mono tracking-widest font-black uppercase bg-blue-105 border border-blue-200 px-3.5 py-1.5 rounded-full select-none inline-block">
            BIO-CHEMICAL POTENCY ENGINE
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 leading-tight">
            Verify the Health Benefits of Alkaline Restoring
          </h2>
          <p className="text-xs text-slate-500 font-semibold leading-relaxed">
            Unlike static bottled liquids, electrolyzed water has enhanced bio-available features. Click the target cards below to inspect lab metrics, comparative advantages, and structural cellular mechanisms.
          </p>
        </div>

        {/* Tab Selection Grid of Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {benefitsList.map((benefit) => {
            const isSelected = activeTab === benefit.id;
            return (
              <button
                id={`benefit-tab-card-${benefit.id}`}
                key={benefit.id}
                onClick={() => setActiveTab(benefit.id)}
                className={`text-left p-5 rounded-2xl border transition-all duration-300 cursor-pointer relative overflow-hidden flex flex-col justify-between h-48 group shadow-sm hover:scale-[1.03] hover:-translate-y-1 ${
                  isSelected
                    ? `bg-slate-50 border-blue-400 shadow-inner hover:shadow-md`
                    : 'bg-white border-slate-200 hover:border-blue-400 hover:bg-slate-50 hover:shadow-md'
                }`}
                style={{
                  borderLeft: isSelected ? `4px solid ${benefit.accentColor}` : undefined
                }}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="p-2 bg-slate-100/80 rounded-xl border border-slate-150 group-hover:scale-105 transition-transform">
                      {benefit.icon}
                    </div>
                    {isSelected && (
                      <span className="h-2 w-2 rounded-full animate-ping" style={{ backgroundColor: benefit.accentColor }} />
                    )}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-sm text-slate-900">{benefit.title.split('. ')[1]}</h3>
                    <p className="text-[10px] text-slate-500 leading-snug font-bold mt-1 group-hover:text-slate-700 transition-colors">
                      {benefit.tagline}
                    </p>
                  </div>
                </div>

                <span className="text-[9px] uppercase tracking-widest font-mono font-black text-blue-600 mt-2 flex items-center gap-1">
                  <span>Explore Metrics</span>
                  <span className="group-hover:translate-x-1 transition-transform">&rarr;</span>
                </span>
              </button>
            );
          })}
        </div>

        {/* Selected Tab Deep Dive & Cellular Simulator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-6 border-t border-slate-100 items-stretch">
          {/* Left panel: Detailed write up with counters */}
          <div className="xl:col-span-7 lg:col-span-6 space-y-6 bg-slate-50 p-6 rounded-2xl border border-slate-205 flex flex-col justify-between">
            <div className="space-y-4">
              <span className="text-[10px] uppercase font-mono tracking-wider font-extrabold text-slate-400 block">
                Active Pillar Insights &bull; {currentBenefit.title.toUpperCase()}
              </span>
              <h3 className="text-xl font-black text-slate-900 leading-tight">
                {currentBenefit.title.split('. ')[1]}
              </h3>
              <p className="text-xs text-blue-600 font-sans italic font-bold">
                &ldquo;{currentBenefit.tagline}&rdquo;
              </p>
              
              <p className="text-xs text-slate-600 font-semibold leading-relaxed">
                {currentBenefit.summary}
              </p>

              <div className="border-t border-slate-200 pt-4 space-y-1">
                <span className="text-[10px] uppercase font-mono font-black text-slate-400 block">Biochemical Mechanism:</span>
                <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                  {currentBenefit.mechanism}
                </p>
              </div>
            </div>

            {/* Labs Comparative specs box */}
            <div className="bg-white border border-slate-200 p-4 rounded-xl flex items-center justify-between shadow-xs">
              <div>
                <span className="text-[9px] text-[#2563eb] uppercase font-mono font-black tracking-widest block">Comparative Lab Metric</span>
                <span className="text-xs font-black text-slate-800">{currentBenefit.comparativeStat.label}</span>
              </div>
              <div className="text-right space-y-1 font-mono">
                <span className="text-[10px] text-red-500 block line-through font-extrabold">Tap: {currentBenefit.comparativeStat.standard}</span>
                <span className="text-[11px] text-emerald-600 block font-black">Kangen: {currentBenefit.comparativeStat.kangen}</span>
              </div>
            </div>
          </div>

          {/* Right panel: THE DYNAMIC CELLULAR HYDRATION SIMULATOR OR LIVE SPEC SHEET */}
          <div className="xl:col-span-5 lg:col-span-6 bg-white border border-slate-200 p-6 rounded-2xl flex flex-col justify-between shadow-xs">
            {activeTab === 'hydration' ? (
              /* HYDRATION INTERACTIVE SIMULATOR */
              <div className="space-y-4 flex flex-col justify-between h-full">
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-slate-900">Aquaporin Hydration Laboratory</h4>
                  <p className="text-[10px] text-slate-550 font-bold leading-tight">
                    Standard big clusters bounce off aquaporins. Tiny micro-clusters slip instantly inside the core cellular structures. Click to compare!
                  </p>
                </div>

                {/* Simulated Canvas */}
                <div className="h-44 bg-slate-900 rounded-xl relative border border-slate-800 overflow-hidden flex items-center justify-center shadow-inner">
                  {/* Central human cellular core outline */}
                  <div className="absolute h-24 w-24 rounded-full border-2 border-dashed border-sky-400/30 flex items-center justify-center animate-spin duration-15000">
                    <span className="text-[8px] font-mono font-black text-sky-405">HUMAN CELL</span>
                  </div>
                  {/* Cytoplasm glow */}
                  <div className="absolute h-20 w-20 rounded-full bg-blue-500/10 filter blur-xl animate-pulse" />

                  {/* Tiny water molecules slipping inside or bouncing off */}
                  {hydrationSimType === 'kangen' ? (
                    /* KANGEN PARTICLES SLIPPING IN */
                    <div className="w-full h-full absolute inset-0">
                      {/* Cluster 1 */}
                      <div className="absolute top-10 left-12 flex space-x-1 animate-ping">
                        <span className="h-2 w-2 rounded-full bg-blue-400" />
                        <span className="h-2 w-2 rounded-full bg-cyan-400" />
                        <span className="h-2 w-2 rounded-full bg-emerald-400" />
                      </div>
                      <div className="absolute bottom-12 right-12 flex space-x-1 animate-pulse">
                        <span className="h-1.5 w-1.5 rounded-full bg-sky-300" />
                        <span className="h-1.5 w-1.5 rounded-full bg-cyan-300" />
                      </div>
                      
                      {/* Flowing streams */}
                      <span className="absolute text-[8px] font-mono text-emerald-400 font-extrabold top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/20">
                        ✓ 100% ABSORBED
                      </span>
                    </div>
                  ) : (
                    /* STANDARD PARTICLES BLOCKED OUT */
                    <div className="w-full h-full absolute inset-0">
                      {/* Big clumps of particles floating outside */}
                      <div className="absolute top-4 left-6 bg-slate-800/80 p-1.5 rounded-lg border border-white/5 space-y-1 animate-bounce">
                        <span className="text-[8px] text-red-400 block font-mono">18px Clump</span>
                        <div className="flex flex-wrap gap-1 w-8">
                          <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                          <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                          <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                          <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        </div>
                      </div>

                      <div className="absolute bottom-4 right-6 bg-slate-800/80 p-1.5 rounded-lg border border-white/5 space-y-0.5">
                        <span className="text-[8px] text-red-500 block font-mono">Block Limit</span>
                        <div className="flex flex-wrap gap-0.5 w-6">
                          <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                          <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                        </div>
                      </div>

                      <span className="absolute text-[8px] font-mono text-red-400 font-extrabold top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-red-955 bg-red-950/60 px-1.5 py-0.5 rounded border border-red-500/20 animate-pulse">
                        ⚠️ EXCLUDED (BLOATING)
                      </span>
                    </div>
                  )}
                </div>

                {/* Option Toggles */}
                <div className="grid grid-cols-2 gap-2 font-semibold">
                  <button
                    id="sim-standard-btn"
                    onClick={() => setHydrationSimType('standard')}
                    className={`py-1.5 rounded-lg border text-xs font-bold font-sans cursor-pointer ${
                      hydrationSimType === 'standard'
                        ? 'bg-red-50/70 border-red-300 text-red-650'
                        : 'bg-slate-50 border-slate-200 text-slate-500'
                    }`}
                  >
                    Tap/Bottled Water
                  </button>
                  <button
                    id="sim-kangen-btn"
                    onClick={() => setHydrationSimType('kangen')}
                    className={`py-1.5 rounded-lg border text-xs font-bold font-sans cursor-pointer ${
                      hydrationSimType === 'kangen'
                        ? 'bg-blue-50/70 border-blue-300 text-blue-650'
                        : 'bg-slate-50 border-slate-200 text-slate-500'
                    }`}
                  >
                    Kangen Micro-Water
                  </button>
                </div>
              </div>
            ) : (
              /* ACTIVE METRICS DATA SHEET FOR OTHERS */
              <div className="space-y-4 flex flex-col justify-between h-full text-left">
                <div className="space-y-1">
                  <h4 className="text-sm font-black text-slate-900 font-sans">Certified Biological Metrics</h4>
                  <p className="text-[10px] text-slate-450 font-bold leading-tight">
                    Specific quantitative benefits observed during electrolyzed Kangen Water test programs.
                  </p>
                </div>

                <div className="space-y-3 py-3">
                  {currentBenefit.metrics.map((m, i) => (
                    <div key={i} className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 flex items-center justify-between">
                      <span className="text-xs text-slate-500 font-bold font-sans">{m.label}</span>
                      <span className="text-xs font-mono font-black text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-105">{m.value}</span>
                    </div>
                  ))}
                </div>

                <div className="p-3 bg-blue-50/50 rounded-xl border border-blue-200/50">
                  <p className="text-[10px] text-slate-500 leading-normal font-sans">
                    <span className="text-blue-600 font-black uppercase block mb-0.5 font-mono">Note on baseline:</span>
                    Continuous plate electrical ionization generates high concentrations of bio-available mineral structure.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
