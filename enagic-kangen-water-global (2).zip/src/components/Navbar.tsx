import React, { useState, useEffect, useRef } from 'react';
import { Droplet, Menu, X, Coins, Phone, Calendar } from 'lucide-react';
import { SUPPORTED_CURRENCIES } from '../data';

const logoImg = 'https://drive.google.com/thumbnail?id=1B14CJYX6B_W7PteITDHJBImcrIWUCBSM&sz=w500';

export function MainLogoSVG({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <img 
      src={logoImg} 
      alt="One Water One Future Logo" 
      className={`${className} object-contain rounded-full`}
    />
  );
}

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenDemoModal: () => void;
  selectedCurrencyCode: string;
  setSelectedCurrencyCode: (code: string) => void;
}

export default function Navbar({ 
  currentTab, 
  setCurrentTab, 
  onOpenDemoModal,
  selectedCurrencyCode,
  setSelectedCurrencyCode 
}: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [logoImage, setLogoImage] = useState<string>('https://drive.google.com/thumbnail?id=1B14CJYX6B_W7PteITDHJBImcrIWUCBSM&sz=w500');

  const navbarRef = useRef<HTMLElement | null>(null);

  // Close mobile menu when clicking or touching outside the menu area
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        isOpen &&
        navbarRef.current &&
        !navbarRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    const handleTouchOutside = (event: TouchEvent) => {
      if (
        isOpen &&
        navbarRef.current &&
        !navbarRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside, true);
    document.addEventListener('touchstart', handleTouchOutside, true);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside, true);
      document.removeEventListener('touchstart', handleTouchOutside, true);
    };
  }, [isOpen]);

  useEffect(() => {
    const handleScroll = () => {
      const isMobile = window.innerWidth < 1024;
      const threshold = isMobile ? 140 : 70;
      if (window.scrollY > threshold) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigationItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'benefits', label: 'Alkaline & Benefits' },
    { id: 'sources', label: 'Scientist Research' },
    { id: 'products', label: 'Models & Prices' },
    { id: 'join', label: 'Business Opportunity' },
    { id: 'contact', label: 'Contact Us' }
  ];

  const handleTabChange = (tabId: string) => {
    setCurrentTab(tabId);
    setIsOpen(false);
    // Smooth scroll back to top on navigation for pristine user experience
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="w-full flex flex-col relative z-50">
      {/* HEADER 1: BRAND UTILITIES & ACCESS (Scrolls away automatically) */}
      <div id="header-top-bar" className="w-full bg-white border-b border-slate-100 py-2.5 md:py-3.5 px-3 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4">
          
          {/* Leftside: Brand Logo & Mobile Currency Selector row (flex container keeping them side-by-side on mobile) */}
          <div className="flex items-center justify-between w-full sm:w-auto gap-3">
            <div 
              id="brand-logo-container"
              className="flex items-center space-x-2 md:space-x-3 cursor-pointer select-none shrink-0" 
              onClick={() => handleTabChange('home')}
            >
              <div className="h-9 w-9 md:h-11 md:w-11 flex items-center justify-center rounded-full bg-slate-50 border border-slate-100 shadow-sm relative overflow-hidden transition-all duration-350 hover:rotate-12 shrink-0 p-0.5">
                <MainLogoSVG className="h-full w-full" />
              </div>
              <div>
                <span className="font-black text-xs md:text-base tracking-tight text-slate-900 block leading-none font-sans">
                  One Water One Future.org
                </span>
                <span className="text-[8px] md:text-[11px] text-blue-600 font-extrabold uppercase tracking-widest block mt-0.5 md:mt-1 font-mono">
                  Pure Water Long Life
                </span>
              </div>
            </div>

            {/* Currency Selector - Visible ONLY on mobile & tablet (< md) right next to logo */}
            <div id="mobile-top-bar-currency" className="flex md:hidden items-center space-x-1.5 bg-slate-50 border border-slate-200 hover:border-blue-300 rounded-lg px-2.5 py-1.5 transition-colors shrink-0">
              <Coins className="h-3.5 w-3.5 text-blue-600 shrink-0" />
              <select
                id="top-bar-mobile-currency-select"
                value={selectedCurrencyCode}
                onChange={(e) => setSelectedCurrencyCode(e.target.value)}
                className="bg-transparent border-none text-[11px] font-black text-slate-750 focus:outline-none cursor-pointer pr-1"
                title="Select Currency"
              >
                {SUPPORTED_CURRENCIES.map((curr) => (
                  <option key={curr.code} value={curr.code} className="font-bold text-slate-800">
                    {curr.code} ({curr.symbol.trim()})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Rightside: Currency Selector, Clickable Direct Contact (+919555601611) & Free Demo CTA */}
          <div id="header-actions-group" className="flex items-center justify-between sm:justify-end gap-2 w-full sm:w-auto shrink-0">
            
            {/* Currency Selector - Hidden on mobile/tablets as it is in the sticky nav right next to logo */}
            <div className="hidden md:flex items-center space-x-1 bg-slate-50 border border-slate-200 rounded-lg md:rounded-xl px-1.5 py-1 md:px-2.5 md:py-1.5 hover:border-blue-300 transition-colors shrink-0">
              <Coins className="h-3 w-3 md:h-3.5 md:w-3.5 text-blue-600 shrink-0" />
              <select
                id="global-currency-select"
                value={selectedCurrencyCode}
                onChange={(e) => setSelectedCurrencyCode(e.target.value)}
                className="bg-transparent border-none text-[10px] md:text-xs font-black text-slate-750 focus:outline-none cursor-pointer pr-0.5"
                title="Select Currency"
              >
                {SUPPORTED_CURRENCIES.map((curr) => (
                  <option key={curr.code} value={curr.code} className="font-bold text-slate-800">
                    {curr.code} ({curr.symbol.trim()})
                  </option>
                ))}
              </select>
            </div>

            {/* Clickable Distributor Phone Number */}
            <a 
              id="header-phone-link"
              href="tel:+919555601611" 
              className="flex items-center space-x-1 md:space-x-2 text-slate-705 hover:text-blue-600 font-extrabold text-[10px] md:text-xs bg-slate-50 border border-slate-205 hover:border-blue-300 rounded-lg md:rounded-xl px-2 py-1 md:px-3 md:py-1.5 hover:scale-[1.03] hover:-translate-y-0.5 active:scale-98 transition-all duration-200 shadow-xs shrink-0"
            >
              <Phone className="h-3 w-3 md:h-3.5 md:w-3.5 text-blue-600 fill-blue-100/50" />
              <span className="hidden xs:inline">+91 95556 01611</span>
              <span className="xs:hidden">Call</span>
            </a>

            {/* Schedule Free Demo CTA */}
            <button
              id="header-cta-button"
              onClick={onOpenDemoModal}
              className="flex items-center space-x-1 md:space-x-1.5 px-2.5 py-1.5 md:px-4 md:py-2 text-[10px] md:text-xs font-black uppercase tracking-wider text-white bg-blue-600 hover:bg-blue-700 rounded-lg md:rounded-xl shadow-btn-3d hover:shadow-lg hover:shadow-blue-500/10 hover:scale-[1.03] hover:-translate-y-0.5 active:scale-95 transition-all duration-200 cursor-pointer shrink-0"
            >
              <Calendar className="h-3 w-3 md:h-3.5 md:w-3.5" />
              <span className="hidden md:inline">Schedule Free Demo</span>
              <span className="md:hidden">Free Demo</span>
            </button>
          </div>
        </div>
      </div>

      {/* HEADER 2 PLACEHOLDER (h-12 wrapper keeps flow spacing perfect & avoids layout shifts) */}
      <div className="w-full h-12 relative z-40">
        <nav 
          ref={navbarRef}
          id="app-navbar-sticky" 
          className={`w-full bg-slate-900 border-b border-slate-800 text-white transition-all duration-300 ${
            isScrolled 
              ? 'fixed top-0 left-0 right-0 z-50 shadow-2xl bg-slate-950/95 backdrop-blur-md border-b border-cyan-500/10' 
              : 'relative'
          }`}
        >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-12">
            
            {/* Desktop Navigation Links */}
            <div id="desktop-menu-links" className="hidden lg:flex items-center space-x-1 mx-auto">
              {navigationItems.map((item) => {
                const isActive = currentTab === item.id;
                return (
                  <button
                    id={`nav-tab-${item.id}`}
                    key={item.id}
                    onClick={() => handleTabChange(item.id)}
                    className={`px-4 py-1.5 text-xs font-black uppercase tracking-wider rounded-lg transition-all duration-200 hover:scale-[1.05] active:scale-95 relative ${
                      isActive
                        ? 'text-cyan-400 bg-slate-800/80 border border-cyan-500/20 shadow-xs'
                        : 'text-slate-300 hover:text-cyan-400 hover:bg-slate-800/40'
                    }`}
                  >
                    {item.label}
                    {isActive && (
                      <span className="absolute bottom-[-6px] left-0 right-0 h-0.5 bg-cyan-400 rounded-full mx-5 shadow-[0_0_10px_rgba(34,211,238,0.7)] animate-pulse" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Desktop Quick Right Label */}
            <div className="hidden lg:flex items-center space-x-1 text-[10px] font-mono font-bold text-slate-400">
              <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-ping" />
              <span className="tracking-widest uppercase text-slate-500">Live Demonstrations Active</span>
            </div>

            {/* MOBILE & TABLET LAYOUT (lg:hidden) */}
            <div className="flex lg:hidden items-center justify-between w-full h-12">
              
              {/* 1. Hamburger menu toggle on left */}
              <button
                id="mobile-sticky-menu-toggle"
                onClick={() => setIsOpen(!isOpen)}
                className="inline-flex items-center justify-center p-1.5 rounded-md text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none transition-colors"
                title="Toggle Menu"
              >
                {isOpen ? <X className="block h-5 w-5" /> : <Menu className="block h-5 w-5" />}
              </button>

              {/* 2. Current Page Segment Indicator in the Middle */}
              <div className="flex items-center justify-center">
                <span className="text-xs font-black uppercase tracking-widest text-[#94a3b8] font-sans">
                  {navigationItems.find(t => t.id === currentTab)?.label || 'Menu'}
                </span>
              </div>

              {/* 3. Invisible dummy placeholder so Middle text stays perfectly centered */}
              <div className="w-8 h-8 pointer-events-none" />

            </div>

          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        {isOpen && (
          <div id="mobile-menu-dropdown" className="lg:hidden bg-slate-950 border-t border-slate-850 py-3 px-2 space-y-1 shadow-inner max-h-[80vh] overflow-y-auto animate-fade-in">
            {navigationItems.map((item) => {
              const isActive = currentTab === item.id;
              return (
                <button
                  id={`mobile-nav-${item.id}`}
                  key={item.id}
                  onClick={() => handleTabChange(item.id)}
                  className={`block w-full text-left px-4 py-2.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all ${
                    isActive
                      ? 'bg-slate-900 text-cyan-400 border-l-4 border-cyan-400 font-extrabold'
                      : 'text-slate-300 hover:bg-slate-900 hover:text-cyan-300'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
            
            {/* Quick Contacts inside mobile menu */}
            <div className="pt-3 mt-3 border-t border-slate-800 px-3 space-y-2.5">
              <a 
                href="tel:+919555601611" 
                className="flex items-center space-x-2 text-[11px] font-bold text-slate-350 hover:text-cyan-400 transition-colors"
                onClick={() => setIsOpen(false)}
              >
                <Phone className="h-3.5 w-3.5 text-cyan-400" />
                <span>Call +91 95556 01611</span>
              </a>
              <button
                onClick={() => {
                  onOpenDemoModal();
                  setIsOpen(false);
                }}
                className="w-full text-center py-2.5 px-4 rounded-xl font-black text-xs uppercase tracking-wider bg-blue-600 text-white shadow-md active:scale-95 transition-all"
              >
                Schedule Free Demo Now
              </button>
            </div>
          </div>
        )}
      </nav>
      </div>
    </div>
  );
}
