import React, { useEffect } from 'react';
import { ShieldCheck, Lock, Eye, CheckCircle, FileText } from 'lucide-react';

export default function PrivacyPolicyView() {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <div id="privacy-policy-viewport" className="py-12 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Hero Card */}
        <div className="bg-white border border-slate-205 rounded-2xl p-8 shadow-3d hover:shadow-3d-hover transition-all text-center space-y-4 mb-8">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-blue-50 border border-blue-200 text-blue-600 mb-2">
            <ShieldCheck className="h-6 w-6" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Privacy Policy</h1>
          <p className="text-xs text-slate-500 font-mono font-bold tracking-wider uppercase">
            Effective Date: June 15, 2026 | Last Updated: June 15, 2026
          </p>
          <p className="text-slate-500 text-xs font-semibold max-w-xl mx-auto leading-relaxed">
            Your trust is our absolute priority. This Privacy Policy details how we protect your personal credentials, contact parameters, and custom schedule options.
          </p>
        </div>

        {/* Polished Sectioned Card Layout */}
        <div className="bg-white border border-slate-205 rounded-2xl p-8 sm:p-10 shadow-3d text-left space-y-8">
          {/* Introduction */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">01.</span>
              <span>Introduction & Purpose</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              This document outlines the privacy practices of the Enagic® Independent Distributor team ("we", "us", or "our"). We are committed to maintaining the confidentiality, safety, and security of any and all client information submitted through our healthy hydration portal.
            </p>
          </div>

          {/* Core Data Collected */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">02.</span>
              <span>Information We Collect</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              We collect information that you explicitly submit on this website to request products descriptions, register for our global membership network, or book demo presentations:
            </p>
            <ul className="list-none space-y-2 mt-2 pl-2">
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>Identity Credentials:</strong> Full name, electronic email addresses, and active telephone parameters.</span>
              </li>
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>Socio-Geographic Markers:</strong> IP addresses and geolocation-based timezone indicators to automatically identify default regional currencies.</span>
              </li>
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span><strong>Schedule Calendars:</strong> Preferred dates, selected hours, and custom queries for physical or virtual water demonstrations.</span>
              </li>
            </ul>
          </div>

          {/* Purpose of Collection */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">03.</span>
              <span>How We Process Your Details</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              Your registered details are solely implemented to deliver our public health mission. We process your data to:
            </p>
            <ul className="list-none space-y-2 mt-2 pl-2">
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>Integrate live virtual water demonstrations via video streaming (Google Meet or Zoom).</span>
              </li>
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>Dispatch official price estimations matching your local detected regional currency.</span>
              </li>
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>Fulfill registration support requests into the registered Enagic® global distributor hierarchy.</span>
              </li>
            </ul>
          </div>

          {/* Third-Party Safety */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">04.</span>
              <span>Third-Party APIs & Calendars</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              This platform interacts with Google Workspace APIs (Google Calendar) for live time slot checking and calendar booking. Scheduling is protected under Google Secure Credentials. We DO NOT trade, sell, lease, or distribute your email addresses or phone parameters to secondary advertising companies or marketing registries.
            </p>
          </div>

          {/* Local Storage & Cookies */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">05.</span>
              <span>Client-Side Local Storage</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              We utilize secure client-side browser storage (Local Storage) only to save your physical demonstration records locally. This prevents double bookings and lets you track your pending consultation tickets effortlessly.
            </p>
          </div>

          {/* Protection Measures */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">06.</span>
              <span>Information Security</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold flex items-start space-x-2">
              <Lock className="h-4 w-4 text-blue-600 shrink-0 mt-0.5" />
              <span>We utilize highly robust SSL encryption. Your connection remains completely private. In addition, our physical server configurations are monitored 24/7 with zero exposure to open digital search leaks.</span>
            </p>
          </div>
        </div>

        {/* Footer Support Notice */}
        <div className="mt-8 text-center text-[11px] font-bold text-slate-400">
          Have queries about your private data? Contact us directly at <span className="text-blue-600 font-sans">info@onewateronefuture.org</span>
        </div>

      </div>
    </div>
  );
}
