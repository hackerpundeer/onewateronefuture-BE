import React, { useState } from 'react';
import { HEALTH_BENEFITS, CHRONIC_DISEASES_INFO } from '../data';
import { Zap, Droplet, Sparkles, ShieldCheck, Activity, BrainCircuit, AlertTriangle } from 'lucide-react';
import InteractiveHealthBenefits from './InteractiveHealthBenefits';

import microBubblesGlass from '../assets/images/micro_bubbles_glass_1779402703800.png';

export default function BenefitsView() {
  const [beverageCompareId, setBeverageCompareId] = useState<string>('kangen');

  // Beverage comparisons for the interactive ORP meter
  const beverageComparisons = [
    { id: 'soda', name: 'Carbonated Soda', orp: '+400 mV', type: 'Highly Oxidizing (Speeds Aging)', color: '#dc2626', text: 'Highly acidic and rich in oxidizing free radicals. Speeds up cellular decay and depletes important healthy calcium and mineral reserves.' },
    { id: 'tap', name: 'Regular Tap Water', orp: '+200 mV', type: 'Mildly Oxidizing (Acidic Scale)', color: '#f97316', text: 'Treated with chlorine, copper, and chemicals. High positive ORP mean it cannot actively serve as an antioxidant.' },
    { id: 'greentea', name: 'Fresh Green Tea', orp: '-100 mV', type: 'Anti-Oxidizing (Good Health)', color: '#16a34a', text: 'Contains healthy organic catechins capable of donating electrons to neutralize local cellular free radical damage.' },
    { id: 'kangen', name: 'Kangen Water® (Ionized)', orp: '-400 to -800 mV', type: 'Highly Anti-Oxidizing (Premium Cell Rejuvenation)', color: '#2563eb', text: 'Supersaturated with active molecular hydrogen and millions of free electrons. Serves as a massive scavenger of dangerous active oxygen species.' }
  ];

  const selectedBev = beverageComparisons.find(b => b.id === beverageCompareId) || beverageComparisons[3];

  return (
    <div id="benefits-view-root" className="pb-16 bg-[#f8fafc] text-slate-800 space-y-12 relative overflow-hidden font-sans">
      
      {/* Background blurs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[8%] left-[2%] w-80 h-80 rounded-full bg-blue-105/30 blur-3xl" />
        <div className="absolute bottom-[20%] right-[5%] w-96 h-96 rounded-full bg-cyan-105/30 blur-3xl animate-pulse" />
      </div>

      {/* 1. Introductory Title Section */}
      <section className="relative pt-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <span className="text-[10px] uppercase font-mono tracking-widest font-black text-blue-600 bg-blue-100/60 px-3.5 py-1.5 rounded-full border border-blue-200">
            Biochemical Wellness Deep-Dive
          </span>
          <h1 className="text-4xl font-extrabold tracking-tight leading-tight text-slate-900">
            The Unique Properties & Benefits <br />
            <span className="bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-650 bg-clip-text text-transparent italic font-serif">
              of Ionized Alkaline Water
            </span>
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm font-semibold max-w-2xl mx-auto leading-relaxed">
            Kangen Water is restructured water created through continuous titanium-cell electrolysis. This generates highly unique biochemical metrics (negative ORP, active micro-clustering) that support long-term metabolic homeostasis.
          </p>
        </div>
      </section>

      {/* 2. LABS ORP COMPARATOR PANEL SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 text-left">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch shadow-3d hover:shadow-3d-hover transition-all">
          
          <div className="lg:col-span-12 xl:col-span-5 space-y-5 col-span-1">
            <div className="inline-flex items-center space-x-1.5 text-xs text-blue-600 font-bold">
              <Activity className="h-4 w-4 text-blue-600 animate-pulse" />
              <span>Bio-Electrical Energy Range</span>
            </div>
            <h2 className="text-2xl font-black text-slate-900 leading-tight">Oxidation Reduction Potential (ORP)</h2>
            <p className="text-xs text-slate-500 leading-relaxed font-semibold">
              Every fluid has an ORP score measuring its capacity to oxidize or anti-oxidize organic tissues. Positive values trigger cellular erosion (aging). High negative values donate millions of active electrons to protect cells and neutralize systemic inflammation.
            </p>

            {/* Selector buttons */}
            <div className="space-y-2 pt-2">
              {beverageComparisons.map((bev) => (
                <button
                  id={`orp-bev-${bev.id}`}
                  key={bev.id}
                  onClick={() => setBeverageCompareId(bev.id)}
                  className={`w-full text-left p-3.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                    beverageCompareId === bev.id
                      ? 'bg-blue-50/60 border-blue-400 ring-1 ring-blue-500/10 shadow-sm'
                      : 'bg-white border-slate-200 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="h-3 w-3 rounded-full shrink-0" style={{ backgroundColor: bev.color, boxShadow: `0 0 6px ${bev.color}` }} />
                    <span className={`text-xs font-black ${beverageCompareId === bev.id ? 'text-blue-700' : 'text-slate-605'}`}>{bev.name}</span>
                  </div>
                  <span className="text-xs font-mono font-extrabold" style={{ color: bev.color }}>{bev.orp}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-12 xl:col-span-7 bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col justify-between h-full min-h-[380px]">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch h-full">
              
              {/* Slider Left hand column */}
              <div className="md:col-span-7 flex flex-col justify-between space-y-4 text-left">
                {/* Visual Dial representation */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-[9px] text-slate-400 font-black font-mono">
                    <span>Oxidizing (+400mV)</span>
                    <span>Antioxidant (-800mV)</span>
                  </div>
                  
                  {/* Custom interactive slider representation */}
                  <div className="h-4 bg-gradient-to-r from-red-500 via-amber-450 via-emerald-450 to-blue-500 rounded-full relative shadow-inner">
                    <div
                      className="absolute top-1/2 -translate-y-1/2 h-7 w-7 bg-white rounded-full border-4 border-slate-900 shadow-xl flex items-center justify-center transition-all duration-300"
                      style={{
                        left: beverageCompareId === 'soda' ? '5%' :
                              beverageCompareId === 'tap' ? '30%' :
                              beverageCompareId === 'greentea' ? '65%' : '90%'
                      }}
                    >
                      <Droplet className="h-3.5 w-3.5 text-blue-600" />
                    </div>
                  </div>

                  <div className="pt-2 space-y-2">
                    <div className="flex items-center justify-between flex-wrap gap-1">
                      <h4 className="font-extrabold text-slate-900 text-sm">{selectedBev.name}</h4>
                      <span className="px-2 py-0.5 rounded text-[9px] font-bold text-white uppercase tracking-wider font-mono shrink-0" style={{ backgroundColor: selectedBev.color, boxShadow: `0 0 6px ${selectedBev.color}44` }}>
                        ORP: {selectedBev.orp}
                      </span>
                    </div>
                    <p className="text-[9px] font-mono uppercase font-black tracking-wider" style={{ color: selectedBev.color }}>
                      {selectedBev.type}
                    </p>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                      {selectedBev.text}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-250 flex justify-between items-center text-[9px] text-slate-400 font-mono font-bold">
                  <span>Enagic Reduction Test</span>
                  <span>Osaka specs</span>
                </div>
              </div>

              {/* Hydrogen microbubbles visual card on the Right */}
              <div className="md:col-span-5 flex flex-col justify-between space-y-3">
                <div className="relative group rounded-xl overflow-hidden shadow-3d hover:shadow-3d-hover bg-slate-900 border border-slate-200 p-1.5 h-full min-h-[180px] flex flex-col justify-end">
                  <img
                    referrerPolicy="no-referrer"
                    src={microBubblesGlass}
                    alt="Active molecular hydrogen micro bubbles in a glass of water"
                    className="absolute inset-0 h-full w-full object-cover transform scale-100 group-hover:scale-[1.04] transition-all duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
                  
                  {/* Caption badge */}
                  <div className="relative z-10 p-2.5 text-left space-y-1.5">
                    <span className="text-[8px] bg-blue-600 text-white font-mono font-black uppercase tracking-wider px-2 py-0.5 rounded">
                      Hydrogen Micro-Bubbles
                    </span>
                    <p className="text-[10px] text-blue-200 leading-tight font-black font-sans">
                      Active scavenger of dangerous free-radical decay.
                    </p>
                  </div>
                </div>

                {/* Micro bubbles secondary stats */}
                <div className="p-2.5 bg-blue-50/60 rounded-xl border border-blue-200/80 text-left font-sans">
                  <span className="text-[9px] font-bold text-blue-805 block uppercase tracking-wider">Molecular Hydrogen Status</span>
                  <p className="text-[10.5px] text-blue-700 font-black mt-0.5">High Saturation (&gt; 1.6 ppm)</p>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* 3. CORE INTERACTIVE HEALTH BENEFITS GRID SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <InteractiveHealthBenefits />
      </section>

      {/* 4. Diseases and pH Biological Balance */}
      <section className="bg-white py-16 border-y border-slate-200 text-slate-800 text-left">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left side disclaiming compliant disease description */}
            <div className="lg:col-span-5 space-y-6">
              <span className="text-[10px] font-mono tracking-widest uppercase text-blue-600 font-black bg-blue-50 px-3 py-1.5 rounded-full border border-blue-200 inline-block">
                PATHOLOGY CLINICAL CONTEXT & METABOLIC pH
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 leading-tight">
                {CHRONIC_DISEASES_INFO.headline}
              </h2>
              <p className="text-blue-800 italic text-sm font-semibold">
                &ldquo;{CHRONIC_DISEASES_INFO.sub}&rdquo;
              </p>
              <p className="text-slate-500 text-xs leading-relaxed font-semibold font-sans">
                Physiological research implies that pathogenic strains, metabolic stressors, and localized inflammation thrive heavily in acidic, oxygen-depleted bodily environments. Maintaining cell-level mineral alkalinity helps restore balance.
              </p>
              
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-start space-x-3 shadow-inner">
                <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-amber-805 uppercase tracking-widest font-mono">
                    Official Distributor Disclaimer
                  </h4>
                  <p className="text-[10.5px] text-amber-700 leading-relaxed font-sans font-semibold">
                    While electrolyzed Kangen Water is trusted in thousands of Japanese clinical settings and physical therapy hubs for its selective antioxidant properties, it should be consumed as part of a balanced daily hydration cycle. Consult medically certified professionals for serious chronic syndromes.
                  </p>
                </div>
              </div>
            </div>

            {/* Right side pathology listings mapping active uses */}
            <div className="lg:col-span-7 space-y-4">
              {CHRONIC_DISEASES_INFO.points.map((point, index) => (
                <div
                  key={index}
                  className="bg-[#f8fafc] border border-slate-200/80 p-5 rounded-2xl hover:border-blue-400 transition-all flex items-start space-x-4 shadow-3d hover:shadow-3d-hover"
                >
                  <div className="h-6 w-6 rounded-full bg-blue-550 bg-blue-600 text-white shrink-0 flex items-center justify-center text-xs font-mono font-black mt-1">
                    {index + 1}
                  </div>
                  <div className="space-y-1.5 font-medium">
                    <h4 className="font-extrabold text-slate-900 text-sm">{point.condition}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                      {point.explanation}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
