import React, { useState, useEffect } from 'react';
import { ClubSignupInput } from '../types';
import { 
  Calculator, 
  UserPlus, 
  Landmark, 
  Award, 
  ShieldCheck, 
  TrendingUp, 
  Layers, 
  Target, 
  Building2, 
  MapPin, 
  Handshake, 
  FileCheck, 
  Zap, 
  Sparkles, 
  CheckCircle2, 
  HelpCircle,
  TrendingDown,
  ExternalLink
} from 'lucide-react';

interface CurrencyRate {
  code: string;
  symbol: string;
  rate: number; // rate against USD
  name: string;
}

const DEFAULT_RATES: CurrencyRate[] = [
  { code: 'USD', symbol: '$', rate: 1, name: 'United States Dollar' },
  { code: 'INR', symbol: '₹', rate: 83.3, name: 'Indian Rupee' },
  { code: 'EUR', symbol: '€', rate: 0.92, name: 'Euro' },
  { code: 'GBP', symbol: '£', rate: 0.79, name: 'British Pound' },
  { code: 'JPY', symbol: '¥', rate: 156.4, name: 'Japanese Yen' },
  { code: 'CAD', symbol: 'C$', rate: 1.36, name: 'Canadian Dollar' },
  { code: 'AUD', symbol: 'A$', rate: 1.51, name: 'Australian Dollar' },
  { code: 'AED', symbol: 'AED ', rate: 3.67, name: 'UAE Dirham' },
  { code: 'SGD', symbol: 'S$', rate: 1.35, name: 'Singapore Dollar' }
];

// PDF Page 11 Product definitions with official INR prices and commissions
interface GlobalProductCom {
  id: string;
  name: string;
  basePriceINR: number;
  pointValueINR: number;
  description: string;
}

const OFFICIAL_PDF_PRODUCTS: GlobalProductCom[] = [
  { 
    id: 'jriv', 
    name: 'LeveLuk JRIV (Junior IV)', 
    basePriceINR: 240000, 
    pointValueINR: 10000, 
    description: 'Energy-saving model with 4 platinum-plated titanium electrode plates.' 
  },
  { 
    id: 'sd501', 
    name: 'LeveLuk SD501DX Advanced', 
    basePriceINR: 340000, 
    pointValueINR: 15750, 
    description: 'Advanced family use model with 7 platinum-coated plates.' 
  },
  { 
    id: 'k8', 
    name: 'LeveLuk K8 Flagship', 
    basePriceINR: 380000, 
    pointValueINR: 17750, 
    description: 'Enagics flagship model containing 8 high-performance electrolysis plates.' 
  },
  { 
    id: 'super501', 
    name: 'LeveLuk SUPER 501 Heavy Duty', 
    basePriceINR: 440000, 
    pointValueINR: 20500, 
    description: 'High-volume commercial machine with two powerful exclusive electrolysis chambers.' 
  },
  { 
    id: 'anespa', 
    name: 'Anespa DX Home Spa System', 
    basePriceINR: 220000, 
    pointValueINR: 8000, 
    description: 'Exclusive mineral hot spring spa model with premium ceramic cartridges.' 
  }
];

export default function JoinView({
  selectedCurrencyCode: propCurrencyCode,
  setSelectedCurrencyCode: setPropCurrencyCode
}: {
  selectedCurrencyCode?: string;
  setSelectedCurrencyCode?: (code: string) => void;
}) {
  const [inputs, setInputs] = useState<ClubSignupInput>({
    fullName: '',
    email: '',
    phone: '',
    country: '',
    sponsorName: '',
    interestType: 'both'
  });

  const [hasSubmitted, setHasSubmitted] = useState<boolean>(false);
  const [storedClubCount, setStoredClubCount] = useState<number>(0);

  // Currency states
  const [currencies, setCurrencies] = useState<CurrencyRate[]>(DEFAULT_RATES);
  const [localCurrencyCode, setLocalCurrencyCode] = useState<string>('USD');
  const [isRatesLive, setIsRatesLive] = useState<boolean>(false);
  const [isLoadingRates, setIsLoadingRates] = useState<boolean>(false);

  const selectedCurrencyCode = propCurrencyCode || localCurrencyCode;
  const setSelectedCurrencyCode = setPropCurrencyCode || setLocalCurrencyCode;

  // Selected dynamic calculator model
  const [chosenProductId, setChosenProductId] = useState<string>('sd501');
  const [selectedRank, setSelectedRank] = useState<string>('1A'); // 1A, 2A, 3A, 4A, 5A, 6A
  const [directSalesCount, setDirectSalesCount] = useState<number>(2);
  const [indirectSalesCount, setIndirectSalesCount] = useState<number>(5);

  // Fetch live exchange rates
  useEffect(() => {
    async function fetchRates() {
      setIsLoadingRates(true);
      try {
        const response = await fetch('https://open.er-api.com/v6/latest/USD');
        if (!response.ok) {
          throw new Error('Failed to fetch from open exchange rate API');
        }
        const data = await response.json();
        if (data && data.rates) {
          const updated = DEFAULT_RATES.map(curr => {
            if (curr.code === 'USD') return curr;
            const liveRate = data.rates[curr.code];
            return liveRate ? { ...curr, rate: liveRate } : curr;
          });
          setCurrencies(updated);
          setIsRatesLive(true);
        }
      } catch (err) {
        console.warn('Currency fetching fell back to reliable local baseline indices:', err);
        setIsRatesLive(false);
      } finally {
        setIsLoadingRates(false);
      }
    }
    fetchRates();
  }, []);

  const activeCurrency = currencies.find(c => c.code === selectedCurrencyCode) || currencies[0];
  const inrRate = currencies.find(c => c.code === 'INR')?.rate || 83.3;

  // Robust function converting original PDF Indian Rupee values to the current active currency
  const convertToActiveCurrency = (inrValue: number): number => {
    const usdEquivalent = inrValue / inrRate;
    return usdEquivalent * activeCurrency.rate;
  };

  const formatWithActiveSymbol = (value: number) => {
    return activeCurrency.symbol + Math.round(value).toLocaleString();
  };

  // Find active product
  const activeProduct = OFFICIAL_PDF_PRODUCTS.find(p => p.id === chosenProductId) || OFFICIAL_PDF_PRODUCTS[1];

  // Calculated metrics
  const activePointValue = convertToActiveCurrency(activeProduct.pointValueINR);
  const activeProductPrice = convertToActiveCurrency(activeProduct.basePriceINR);

  const getRankMultiplier = (rank: string): number => {
    switch (rank) {
      case '1A': return 1;
      case '2A': return 2;
      case '3A': return 3;
      case '4A': return 4;
      case '5A': return 5;
      case '6A': return 6;
      default: return 1;
    }
  };

  const getRankValueInINR = (rank: string, productId: string): number => {
    const product = OFFICIAL_PDF_PRODUCTS.find(p => p.id === productId) || OFFICIAL_PDF_PRODUCTS[1];
    const basePoint = product.pointValueINR;
    const multiplier = getRankMultiplier(rank);
    return basePoint * multiplier;
  };

  const activeRankSinglePayoutInINR = getRankValueInINR(selectedRank, chosenProductId);
  const activeRankSinglePayout = convertToActiveCurrency(activeRankSinglePayoutInINR);
  const rankMultiplier = getRankMultiplier(selectedRank);

  const directCommissionSum = directSalesCount * activeRankSinglePayout;
  const indirectCommissionSum = indirectSalesCount * (selectedRank === '1A' ? activePointValue : (activeRankSinglePayout / rankMultiplier));
  const grandPredictedTotal = directCommissionSum + indirectCommissionSum;

  useEffect(() => {
    const records = localStorage.getItem('kangen_club_applications');
    if (records) {
      try {
        const parsed = JSON.parse(records);
        if (Array.isArray(parsed)) {
          setStoredClubCount(parsed.length);
        }
      } catch (e) {
        console.error(e);
      }
    }
  }, [hasSubmitted]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setInputs((prev) => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputs.fullName || !inputs.email || !inputs.phone) {
      alert('Please fill out all required fields');
      return;
    }

    const application = {
      ...inputs,
      appliedAt: new Date().toISOString(),
      id: Math.random().toString(36).substring(2, 11)
    };

    const existingRecordsStr = localStorage.getItem('kangen_club_applications');
    let existingRecords = [];
    if (existingRecordsStr) {
      try {
        existingRecords = JSON.parse(existingRecordsStr);
        if (!Array.isArray(existingRecords)) {
          existingRecords = [];
        }
      } catch (e) {
        existingRecords = [];
      }
    }

    existingRecords.push(application);
    localStorage.setItem('kangen_club_applications', JSON.stringify(existingRecords));
    setHasSubmitted(true);
  };

  const resetForm = () => {
    setInputs({
      fullName: '',
      email: '',
      phone: '',
      country: '',
      sponsorName: '',
      interestType: 'both'
    });
    setHasSubmitted(false);
  };

  return (
    <div id="join-view-root" className="pb-20 bg-[#f8fafc] text-slate-800 space-y-16 relative overflow-hidden font-sans">
      
      {/* Dynamic Background Design Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[8%] left-[2%] w-96 h-96 rounded-full bg-blue-100/40 blur-3xl" />
        <div className="absolute bottom-[20%] right-[2%] w-[450px] h-[450px] rounded-full bg-cyan-100/35 blur-3xl animate-pulse" />
      </div>

      {/* 1. Header Hero Title Section */}
      <section className="relative pt-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 max-w-4xl mx-auto">
          <span className="text-[10px] uppercase font-mono tracking-widest font-black text-blue-600 bg-blue-100/60 px-4 py-1.5 rounded-full border border-blue-200 inline-block shadow-xs">
            Official Enagic® Distributor Portal & Earnings Desk
          </span>
          <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-slate-900 leading-tight">
            Enagic® Business Opportunity <br />
            <span className="bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-600 bg-clip-text text-transparent italic font-serif text-3xl sm:text-4xl mt-1 block">
              Patented 8-Point Compensation Plan & Global Growth
            </span>
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm font-semibold max-w-3xl mx-auto leading-relaxed">
            Since 1974, Enagic® has pioneered the global movement of True Health. By eliminating traditional retail intermediaries, Enagic’s patented compensation plan rewards direct consumer relationship-building, allowing independent distributors to share in unparalleled commercial stability and financial liberty.
          </p>

          {/* New Polished Reference Card for https://www.enagic.com/en_US/business-opportunity */}
          <div className="mt-8 max-w-2xl mx-auto bg-gradient-to-r from-blue-50 to-cyan-50/50 border border-blue-200 rounded-2xl p-4 sm:p-5 text-left flex flex-col sm:flex-row items-center sm:items-start gap-4 shadow-sm hover:shadow-md transition-shadow">
            <div className="p-3 bg-blue-600 rounded-xl text-white shrink-0 shadow-md">
              <Award className="h-6 w-6" />
            </div>
            <div className="space-y-1.5 text-center sm:text-left">
              <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider font-sans">
                Official Enagic® Business Resource Hub
              </h4>
              <p className="text-[11.5px] text-slate-600 leading-relaxed font-semibold">
                Explore official registration details, legal guidelines, and distributor materials on Enagic's authorized corporate page:
              </p>
              <div className="pt-1">
                <a 
                  href="https://www.enagic.com/en_US/business-opportunity" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-extrabold tracking-wide uppercase px-4 py-2 rounded-lg transition-all shadow-sm cursor-pointer"
                >
                  <span>Visit Enagic.com Opportunity</span>
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
                <span className="block text-[9.5px] text-slate-400 font-mono mt-1.5">
                  Verified URL: https://www.enagic.com/en_US/business-opportunity
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Core Drivers Section (Page 1: Why a Person works) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-3d space-y-6">
          <div className="text-left max-w-2xl">
            <span className="text-[9px] font-mono uppercase font-black text-blue-600 tracking-wider">FOUNDATIONAL PHILOSOPHY</span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">The Three True Healths of the Enagic® Way</h2>
            <p className="text-xs text-slate-500 mt-1 font-semibold">
              Enagic's global movement is anchored in the robust philosophy of our founder, Hironari Ohshiro, targeting complete physiological, socio-economic, and internal peace:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-50/50 hover:bg-slate-50 border border-slate-200 rounded-2xl p-5 text-left transition-all duration-300">
              <span className="h-10 w-10 flex items-center justify-center bg-blue-105 text-blue-600 rounded-xl text-lg font-black font-mono shadow-xs mb-4">
                01
              </span>
              <h3 className="text-base font-extrabold text-slate-900">True Physical Health</h3>
              <p className="text-xs text-slate-650 mt-2 font-semibold leading-relaxed">
                Nourishing the biological vessel with pristine, antioxidant-rich, ionized Kangen Water®. By eliminating chlorine, harmful micro-contaminants, and acidic properties, we restore our cells back to their absolute origin.
              </p>
            </div>

            <div className="bg-slate-50/50 hover:bg-slate-50 border border-slate-200 rounded-2xl p-5 text-left transition-all duration-300">
              <span className="h-10 w-10 flex items-center justify-center bg-amber-100 text-amber-650 rounded-xl text-lg font-black font-mono shadow-xs mb-4">
                02
              </span>
              <h3 className="text-base font-extrabold text-slate-900">True Financial Health</h3>
              <p className="text-xs text-slate-650 mt-2 font-semibold leading-relaxed">
                Achieving economic independence through Enagic's highly rewarded patented compensation structure. Avoid binary pitfalls and monthly quotas, allowing yourself to accumulate direct sales earnings and reliable downline overrides safely.
              </p>
            </div>

            <div className="bg-slate-50/50 hover:bg-slate-50 border border-slate-200 rounded-2xl p-5 text-left transition-all duration-300">
              <span className="h-10 w-10 flex items-center justify-center bg-emerald-100 text-emerald-650 rounded-xl text-lg font-black font-mono shadow-xs mb-4">
                03
              </span>
              <h3 className="text-base font-extrabold text-slate-900">True Mental & Spiritual Health</h3>
              <p className="text-xs text-slate-650 mt-2 font-semibold leading-relaxed">
                Finding deep, unshakeable internal peace of mind when your physical body thrives and your family is fully protected economically. We foster social growth, lifelong community associations, and shared well-being globally.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Direct Selling Trends & India's Headroom Section (Page 2 & 7) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Market Size & Saturation (Page 7) */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-3d text-left space-y-6">
            <div>
              <span className="text-[9px] font-mono uppercase font-black text-amber-600 tracking-wider">MARKET OVERVIEW (PDF PAGE 7)</span>
              <h3 className="text-xl font-black text-slate-900 mt-0.5">India's Unsaturated Marketplace</h3>
              <p className="text-xs text-slate-500 mt-1 font-semibold">
                Look at the massive mathematical headroom pointing to why Enagic's electrolyzer is a historic megatrend inside the subcontinent:
              </p>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-[10px] text-slate-400 font-mono font-black uppercase">TOTAL FAMILIES IN INDIA</span>
                <p className="text-2xl font-black text-slate-900 mt-1">35-40 Crores approx</p>
              </div>

              <div className="p-4 bg-blue-50/60 rounded-2xl border border-blue-200/50">
                <span className="text-[10px] text-blue-500 font-mono font-black uppercase">TOTAL ENAGIC SALES TO DATE</span>
                <p className="text-2xl font-black text-blue-700 mt-1">Over 5 Lakh Units Sold (till 31 May 2026)</p>
              </div>

              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200">
                <span className="text-[10px] text-emerald-600 font-mono font-black uppercase">MARKET PENETRATION RATE</span>
                <p className="text-2xl font-black text-emerald-600 mt-1">Only ~0.13%</p>
                <p className="text-[10px] text-slate-500 mt-1 font-bold">
                  Over 99.87% of families still rely on basic chemical filters or acidic plastic RO water. The expansion potential is virtually infinite!
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[10px] font-mono text-slate-400 font-bold">Source: Osaka Sales Database</span>
              <span className="text-[10px] text-emerald-600 font-bold uppercase tracking-wider bg-emerald-100/50 px-2.5 py-0.5 rounded">Massive Headroom</span>
            </div>
          </div>

          {/* India Growth Chart (Page 2) */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-3d flex flex-col justify-between text-left space-y-6">
            <div>
              <span className="text-[9px] font-mono uppercase font-black text-blue-600 tracking-wider">DIRECT SELLING GROWTH (PDF PAGE 2)</span>
              <h3 className="text-xl font-black text-slate-900 mt-0.5">Industry Value Growth in India</h3>
              <p className="text-xs text-slate-500 mt-1 font-semibold">
                Direct sales constitute a $210 Billion global market with 125M+ active builders. Inside India, the compounded trajectory is stunning (expressed in Crore Rupees):
              </p>
            </div>

            {/* Custom high-performance responsive bar chart using Tailwind */}
            <div className="space-y-4">
              <div className="grid grid-cols-7 gap-1 sm:gap-3 items-end h-48 pt-6 border-b border-slate-250">
                {[
                  { year: '19-20', val: 16776, percent: '56%' },
                  { year: '20-21', val: 18067, percent: '60%' },
                  { year: '21-22', val: 19020, percent: '63%' },
                  { year: '22-23', val: 21282, percent: '71%' },
                  { year: '23-24', val: 22142, percent: '74%' },
                  { year: '24-25', val: 22150, percent: '74%' },
                  { year: '25-26*', val: 29950, percent: '100%' }
                ].map((item, id) => (
                  <div key={id} className="flex flex-col items-center group relative h-full justify-end">
                    {/* Tooltip */}
                    <div className="absolute -top-7 opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-slate-900 text-white rounded text-[10px] py-0.5 px-2 font-mono font-bold z-10 whitespace-nowrap shadow-md">
                      ₹{item.val.toLocaleString()} Cr
                    </div>
                    
                    {/* Visual Bar */}
                    <div 
                      className={`w-full rounded-t-lg transition-all duration-1000 origin-bottom flex items-end justify-center ${
                        item.year.includes('*') 
                          ? 'bg-gradient-to-t from-blue-700 to-cyan-500' 
                          : 'bg-indigo-100 group-hover:bg-indigo-200 border-t-2 border-indigo-300'
                      }`}
                      style={{ height: item.percent }}
                    >
                      <span className="text-[8px] sm:text-[9px] font-mono font-black text-slate-700 block mb-1">
                        {Math.round(item.val / 1000)}k
                      </span>
                    </div>
                    
                    <span className="text-[10px] font-mono font-extrabold text-slate-500 mt-2 block shrink-0">
                      {item.year}
                    </span>
                  </div>
                ))}
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-[10px] text-slate-500 leading-normal font-semibold">
                <strong>Key Trend:</strong> The market size is expanding rapidly, with immediate projection aiming for <strong>₹29,950 Crore</strong> in India. Partnering as an authorized distributor now aligns your career with a booming structural trend!
              </div>
            </div>

            <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
              <span>* Projected target numbers</span>
              <span className="font-bold text-indigo-600 flex items-center gap-1">
                <TrendingUp className="h-3.5 w-3.5" />
                <span>CAGR ~12.4%</span>
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 4. The Megatrend Transition (Page 6) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-950 text-white border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-3d text-center relative overflow-hidden">
          {/* Overlay glow */}
          <div className="absolute -top-1/2 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="max-w-2xl mx-auto space-y-2 mb-8">
            <span className="text-[10px] uppercase font-mono font-black text-cyan-400 tracking-wider bg-cyan-950/60 border border-cyan-800 px-3 py-1 rounded-full">
              THE STRUCTURAL CONSUMER TRANSITION (PDF PAGE 6)
            </span>
            <h3 className="text-2xl font-black">The Next Massive Household Megatrend</h3>
            <p className="text-xs text-slate-400 font-semibold">
              History shows that water purification technologies evolve in clean generational milestones. See where consumer choice is shifting fast:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch relative z-10">
            {/* Step 1 */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 text-left flex flex-col justify-between">
              <div className="space-y-2">
                <span className="text-[9px] font-mono text-slate-400 block uppercase">STAGE 1 — CLASSIC</span>
                <h4 className="text-base font-extrabold text-cyan-300">1. Basic Filter</h4>
                <p className="text-xs text-slate-400 font-medium leading-relaxed mt-2">
                  Standard gravity carbon pots. Filters mud and coarse grit but fails to block microscopic viral spores or pesticide residue.
                </p>
              </div>
              <span className="text-[10px] text-slate-500 font-mono block mt-4 border-t border-white/5 pt-2">Obsolete tech standard</span>
            </div>

            {/* Step 2 */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-5 text-left flex flex-col justify-between">
              <div className="space-y-2">
                <span className="text-[9px] font-mono text-slate-400 block uppercase">STAGE 2 — PRESENT</span>
                <h4 className="text-base font-extrabold text-amber-300">2. Reverse Osmosis (RO)</h4>
                <p className="text-xs text-slate-400 font-medium leading-relaxed mt-2">
                  Chemical membrane processing. Removes hard salts but strips calcium/magnesium, resulting in highly acidic, dead drinking water.
                </p>
              </div>
              <span className="text-[10px] text-red-400 font-mono block mt-4 border-t border-white/5 pt-2">Highly acidic - De-mineralized</span>
            </div>

            {/* Step 3 */}
            <div className="bg-cyan-950/40 border-2 border-cyan-500/50 rounded-2xl p-5 text-left flex flex-col justify-between shadow-2d">
              <div className="space-y-2">
                <span className="text-[9px] font-mono text-cyan-400 block uppercase tracking-widest font-black">STAGE 3 — FUTURE MEGATREND</span>
                <h4 className="text-base font-extrabold text-white flex items-center justify-between">
                  <span>3. Enagic Electrolyzed</span>
                  <Sparkles className="h-4.5 w-4.5 text-cyan-400" />
                </h4>
                <p className="text-xs text-slate-300 font-semibold leading-relaxed mt-2">
                  Direct electrical conversion. Micro-clusters the water molecule structure while loading massive selective H₂ antioxidants and organic minerals.
                </p>
              </div>
              <span className="text-[10px] text-cyan-400 font-mono block mt-4 border-t border-cyan-800 pt-2 font-black">✓ Medical Device OEM grade</span>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Indian Quality Certifications Grid Section (Page 4) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-3d text-center space-y-6">
          <div className="max-w-2xl mx-auto text-center space-y-2">
            <span className="text-[9px] font-mono uppercase font-black text-blue-600 tracking-wider">CERTIFICATION PROFILE (PDF PAGE 4)</span>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900">Official Indian Quality Compliance</h3>
            <p className="text-xs text-slate-500 font-semibold">
              Enagic devices hold premium credentials recognized by official corporate regulatory agencies and laboratories across the Indian Union:
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center space-y-2">
              <span className="text-xs font-black text-slate-900 block font-sans">FICCI</span>
              <p className="text-[9px] text-slate-500 leading-tight font-semibold">Federation of Indian Chambers of Commerce & Industry</p>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center space-y-2">
              <span className="text-xs font-black text-slate-900 block font-sans">IDSA</span>
              <p className="text-[9px] text-slate-500 leading-tight font-semibold">Indian Direct Selling Association Member Registry</p>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center space-y-2">
              <span className="text-xs font-black text-slate-900 block font-sans">DSA</span>
              <p className="text-[9px] text-slate-500 leading-tight font-semibold">Global Federation of Direct Selling Associations Compliance</p>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center space-y-2">
              <span className="text-xs font-black text-emerald-600 block font-sans">ISO 14001</span>
              <p className="text-[9px] text-slate-500 leading-tight font-semibold">Certified Environmental Management System Factory Standard</p>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center space-y-2">
              <span className="text-xs font-black text-blue-600 block font-sans">ISO 9001</span>
              <p className="text-[9px] text-slate-500 leading-tight font-semibold">Global Quality Control OEM Operations Certification</p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Patented 8-Point Compensation Blueprint Section (Page 8, 9, 10, 11) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-3d space-y-8">
          
          {/* Patent Header */}
          <div className="border-b border-slate-100 pb-5 text-left flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center space-x-2">
                <span className="bg-amber-100 text-amber-800 text-[9px] font-mono font-black uppercase tracking-widest px-2.5 py-1 rounded border border-amber-300">
                  US PATENT NO. 4747092
                </span>
                <span className="text-[10px] text-slate-450 font-mono font-bold">Registration: May 20, 2011</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1 flex items-center gap-2">
                <FileCheck className="h-6 w-6 text-blue-600 shrink-0" />
                <span>Patented 8-Point Compensation Blueprint</span>
              </h2>
              <p className="text-xs text-slate-500 font-semibold mt-1">
                Enagics "Distributor Management System" is patented globally to guarantee peerless revenue integrity. No binary traps, no infinite multi-level chains.
              </p>
            </div>

            {/* Currency Select block */}
            <div className="flex items-center space-x-2 bg-slate-50 border border-slate-200 p-2.5 rounded-2xl self-start md:self-center">
              <Landmark className="h-4.5 w-4.5 text-blue-600 shrink-0" />
              <select
                id="join-currency-config"
                value={selectedCurrencyCode}
                onChange={(e) => setSelectedCurrencyCode(e.target.value)}
                className="bg-transparent text-xs font-black text-slate-800 focus:outline-none cursor-pointer pr-1"
                title="Select Valuation Currency"
              >
                {currencies.map(c => (
                  <option key={c.code} value={c.code}>
                    {c.code} ({c.symbol}) &mdash; {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-2">
            
            {/* The 9 Exciting Rules (Page 8) */}
            <div className="lg:col-span-4 bg-slate-50 border border-slate-200 rounded-2xl p-5 text-left flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-450 font-mono mb-4">9 EXCITING AGENT ADVANTAGES</h4>
                <div className="space-y-2.5">
                  {[
                    'No Sign-up Fee / Entry Cost',
                    'No Monthly Sales Qualifications',
                    'No Stocking of Inventory Required',
                    'No Annual Renewal Penalties',
                    'No Fixed Client Time Limits',
                    'Fully Accumulative Personal Sales',
                    'Universal International Sponsoring',
                    'Pays Commission Daily',
                    'Direct & Override Commission Options'
                  ].map((rule, idx) => (
                    <div key={idx} className="flex items-start space-x-2 text-xs text-slate-705 font-bold">
                      <CheckCircle2 className="h-4 w-4 text-blue-600 shrink-0 mt-0.5" />
                      <span>{rule}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-5 border-t border-slate-200 mt-5 text-[10px] text-slate-450 leading-relaxed font-semibold">
                *The compensation pipeline operates authorized daily ledger updates direct from Osaka. Truly dynamic.
              </div>
            </div>

            {/* Original commissions table of Page 11 & Point Configurator */}
            <div className="lg:col-span-8 bg-slate-50/50 border border-slate-205 rounded-2xl p-5 text-left flex flex-col justify-between space-y-6">
              <div>
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-450 font-mono mb-3">OFFICIAL COMMISSION VALUES (PDF PAGE 11)</h4>
                <p className="text-xs text-slate-500 font-semibold mb-4 leading-relaxed">
                  Every machine sale generates exactly **8 commission points**. The table below shows the baseline values in Indian Rupees (INR) and converted equivalent per model:
                </p>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-semibold text-slate-700">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-400 font-mono text-[9px] uppercase tracking-wider">
                        <th className="pb-2 text-left font-black">Machine Model</th>
                        <th className="pb-2 text-right font-black">Base Price (INR)</th>
                        <th className="pb-2 text-right font-black">1 Point (INR)</th>
                        <th className="pb-2 text-right font-black">Total 8 Pts (INR)</th>
                        <th className="pb-2 text-right font-black">{selectedCurrencyCode} Converted Pt</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-mono">
                      {OFFICIAL_PDF_PRODUCTS.map((prod) => (
                        <tr 
                          key={prod.id} 
                          className={`cursor-pointer transition-colors duration-150 ${
                            chosenProductId === prod.id ? 'bg-blue-50 text-blue-900 font-black' : 'hover:bg-slate-50'
                          }`}
                          onClick={() => setChosenProductId(prod.id)}
                        >
                          <td className="py-2.5 px-1 font-sans text-[11px] font-extrabold flex items-center gap-1">
                            <span className={`h-2 w-2 rounded-full ${chosenProductId === prod.id ? 'bg-blue-600 animate-ping' : 'bg-slate-300'}`} />
                            {prod.name}
                          </td>
                          <td className="py-2.5 text-right font-bold text-slate-800">
                            ₹{prod.basePriceINR.toLocaleString()}
                          </td>
                          <td className="py-2.5 text-right font-bold text-slate-800">
                            ₹{prod.pointValueINR.toLocaleString()}
                          </td>
                          <td className="py-2.5 text-right font-extrabold text-slate-900">
                            ₹{(prod.pointValueINR * 8).toLocaleString()}
                          </td>
                          <td className="py-2.5 text-right text-blue-600 font-extrabold">
                            {formatWithActiveSymbol(convertToActiveCurrency(prod.pointValueINR))}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200 grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                <div className="text-left space-y-0.5">
                  <span className="text-[9px] text-slate-400 font-mono uppercase block">Active Product Filter</span>
                  <span className="text-xs font-black text-slate-905 block">{activeProduct.name}</span>
                </div>
                <div className="text-left space-y-0.5">
                  <span className="text-[9px] text-slate-400 font-mono uppercase block">Unit Price in {selectedCurrencyCode}</span>
                  <span className="text-xs font-extrabold text-blue-700 block">{formatWithActiveSymbol(activeProductPrice)}</span>
                </div>
                <div className="text-left space-y-0.5">
                  <span className="text-[9px] text-slate-400 font-mono uppercase block">Value of 1 Point in {selectedCurrencyCode}</span>
                  <span className="text-xs font-extrabold text-emerald-600 block">{formatWithActiveSymbol(activePointValue)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* 1A to 6A Interactive Rank Timeline Simulator (Page 12 & 13) */}
          <div className="border-t border-slate-100 pt-6 space-y-6">
            <div className="text-left max-w-2xl">
              <span className="text-[9px] font-mono uppercase font-black text-indigo-600 tracking-wider">RANK-MILESTONES PIPELINE (PDF PAGE 12 & 13)</span>
              <h3 className="text-lg font-black text-slate-900 mt-0.5 animate-pulse">Distributor Rank Ladder & Group Sales Gateways</h3>
              <p className="text-xs text-slate-500 mt-1 font-semibold">
                Tap on each rank below to simulate your point share configuration for the selected machine (**{activeProduct.name}**):
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 items-stretch">
              {[
                { 
                  rank: '1A', 
                  points: 1, 
                  limit: '1st & 2nd Direct Sales', 
                  getDesc: (p: number) => `Earn ₹${p.toLocaleString()} per direct sale. Downline, up to 8 points/levels below you, if anyone places a machine, you receive a ₹${p.toLocaleString()} override.` 
                },
                { 
                  rank: '2A', 
                  points: 2, 
                  limit: '3rd Direct Sale', 
                  getDesc: (p: number) => `Once you place your 3rd direct machine sale, you earn ₹${p.toLocaleString()} per machine sale, including downline overrides within your 8-point tree.` 
                },
                { 
                  rank: '3A', 
                  points: 3, 
                  limit: '11th Direct (10 Group Sales)', 
                  getDesc: (p: number) => `When total group sales reach 10, move to 3A on your next direct sale. Earn ₹${p.toLocaleString()} per machine up to 8 points deep.` 
                },
                { 
                  rank: '4A', 
                  points: 4, 
                  limit: '21st Direct (20 Group Sales)', 
                  getDesc: (p: number) => `Once your total team sales reach 20, move to 4A on your 21st direct sale. Earn ₹${p.toLocaleString()} per machine up to 8 points.` 
                },
                { 
                  rank: '5A', 
                  points: 5, 
                  limit: '51st Direct (50 Group Sales)', 
                  getDesc: (p: number) => `Between 21 and 50 group sales, once you hit 50, on your 51st direct sale you earn ₹${p.toLocaleString()} per unit up to 8 points.` 
                },
                { 
                  rank: '6A', 
                  points: 6, 
                  limit: '101st Direct (100 Group Sales)', 
                  getDesc: (p: number) => `Once your total team sales hit 100, on your 101st sale you become a 6A Leader and earn ₹${p.toLocaleString()} per machine.` 
                }
              ].map((item) => {
                const isActive = selectedRank === item.rank;
                const pointPayout = getRankValueInINR(item.rank, chosenProductId);
                const pointPayoutConverted = convertToActiveCurrency(pointPayout);
                return (
                  <button
                    id={`matrix-rank-${item.rank}`}
                    key={item.rank}
                    onClick={() => setSelectedRank(item.rank)}
                    className={`p-5 rounded-2xl text-left border-2 flex flex-col justify-between transition-all duration-300 relative overflow-hidden group cursor-pointer ${
                      isActive 
                        ? 'bg-gradient-to-tr from-blue-50 to-sky-50 border-blue-600 shadow-md ring-2 ring-blue-600/10' 
                        : 'bg-white hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    {isActive && (
                      <span className="absolute top-0 right-0 h-8 w-8 bg-blue-600 text-white flex items-center justify-center text-xs font-black rounded-bl-xl font-mono">
                        ★
                      </span>
                    )}

                    <div className="space-y-2">
                       <div className="flex items-center space-x-2">
                        <span className={`text-lg font-black ${isActive ? 'text-blue-750' : 'text-slate-805'}`}>{item.rank} Rank</span>
                        <span className="bg-blue-100 text-blue-800 text-[9px] font-mono font-black uppercase tracking-wider px-2 py-0.5 rounded">
                          {item.points} Point{item.points > 1 ? 's' : ''}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono text-indigo-600 font-extrabold block uppercase tracking-wider">{item.limit}</span>
                      <p className="text-slate-500 text-[11px] font-semibold leading-relaxed mt-1">{item.getDesc(pointPayout)}</p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 w-full">
                      <span className="text-[9px] text-slate-400 block font-bold font-mono">PAYOUT PER SALE:</span>
                      <div className="flex items-baseline justify-between">
                        <span className={`text-base font-black font-mono ${isActive ? 'text-blue-650' : 'text-slate-900'}`}>
                          {formatWithActiveSymbol(pointPayoutConverted)}
                        </span>
                        {selectedCurrencyCode !== 'INR' && (
                          <span className="text-[9px] text-slate-450 font-bold font-mono">
                            (~₹{pointPayout.toLocaleString()})
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* 6A Super bonus presentation card (Page 13) */}
            <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-3xl p-5 sm:p-6 text-left flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-sm">
              <div className="space-y-1">
                <span className="text-[8px] bg-amber-600 text-white font-mono font-black uppercase tracking-wider px-2 py-0.5 rounded-md">
                  6A ELITE EXECUTIVE BONUS (PDF PAGE 13)
                </span>
                <h4 className="text-base font-black text-amber-950">Unlock Non-Expiring Unlimited Depth Overrides & Awards</h4>
                <p className="text-xs text-amber-900 leading-relaxed font-semibold">
                  Once your global team reaches **100 accumulative sales** and you register your **101st Direct Sale**, you advance to **6A status**:
                </p>
                <ul className="text-[11px] text-amber-905 font-bold space-y-1 list-disc list-inside mt-2 leading-relaxed">
                  <li>Direct Business Achievement Award: **$3,000 USD** cash bonus instantly paid.</li>
                  <li>Unlimited level-up override commission: **₹11,125 INR** ({formatWithActiveSymbol(convertToActiveCurrency(11125))}) on every indirect sale below active 8-points depth!</li>
                </ul>
              </div>
              <div className="bg-white border border-amber-200/80 p-4 rounded-2xl text-center shadow-inner self-start md:self-center shrink-0">
                <span className="text-[9px] text-amber-500 font-mono font-bold block uppercase">6A TARGET BONUS</span>
                <p className="text-3xl font-black text-amber-600 font-mono mt-1">{formatWithActiveSymbol(convertToActiveCurrency(11125))}</p>
                <span className="text-[9px] text-slate-400 font-mono font-bold mt-1 block">Daily Unlimited Override</span>
              </div>
            </div>

            {/* Simulated Live Predicted commission output box */}
            <div className="bg-slate-50 border border-slate-200 p-6 rounded-3xl grid grid-cols-1 lg:grid-cols-12 gap-6 items-center text-left">
              <div className="lg:col-span-4 space-y-2">
                <span className="text-[9px] font-mono text-slate-400 uppercase tracking-widest font-black block">Interactive Commission Prediction</span>
                <h4 className="text-lg font-black text-slate-900">Configure Personal & Group Sales</h4>
                
                <div className="space-y-3 pt-2">
                  <div>
                    <div className="flex justify-between text-[11px] font-bold text-slate-650">
                      <span>Direct referred:</span>
                      <span className="font-mono text-slate-900">{directSalesCount} units</span>
                    </div>
                    <input 
                      type="range" 
                      min="1" 
                      max="15" 
                      value={directSalesCount}
                      onChange={(e) => setDirectSalesCount(parseInt(e.target.value, 10))}
                      className="w-full accent-blue-600"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-[11px] font-bold text-slate-650">
                      <span>Indirect referred:</span>
                      <span className="font-mono text-slate-900">{indirectSalesCount} units</span>
                    </div>
                    <input 
                      type="range" 
                      min="0" 
                      max="30" 
                      value={indirectSalesCount}
                      onChange={(e) => setIndirectSalesCount(parseInt(e.target.value, 10))}
                      className="w-full accent-blue-600"
                    />
                  </div>
                </div>
              </div>

              <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl p-4 grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-[9px] text-slate-400 font-mono uppercase block">Direct Payout</span>
                  <p className="text-xl font-black text-slate-850 mt-1">{formatWithActiveSymbol(directCommissionSum)}</p>
                  <span className="text-[9px] text-slate-500 font-bold block mt-1">({directSalesCount} units x {rankMultiplier} pt)</span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl">
                  <span className="text-[9px] text-slate-400 font-mono uppercase block">Indirect Payout</span>
                  <p className="text-xl font-black text-slate-850 mt-1">{formatWithActiveSymbol(indirectCommissionSum)}</p>
                  <span className="text-[9px] text-slate-500 font-bold block mt-1">({indirectSalesCount} units x 1 pt)</span>
                </div>

                <div className="p-3 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-250">
                  <span className="text-[9px] text-emerald-600 font-mono uppercase block font-black">Predicted Total Rewards</span>
                  <p className="text-2xl font-black text-emerald-600 font-mono mt-1">{formatWithActiveSymbol(grandPredictedTotal)}</p>
                  <span className="text-[8px] text-slate-550 block font-bold mt-1">Converted to {selectedCurrencyCode}</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 7. Worldwide Presence & Sales Offices Block (Page 3) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch font-sans">
          
          {/* Global statistics */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-3d text-left space-y-6">
            <div>
              <span className="text-[9px] font-mono uppercase font-black text-blue-600 tracking-wider">UNIVERSAL LOGISTICS (PDF PAGE 3)</span>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">Enagic Worldwide Footprint</h3>
              <p className="text-xs text-slate-500 mt-1 font-semibold leading-relaxed">
                Operating high-speed corporate logistical networks to handle physical customs clearances, localized electrical voltage standards, and service warranties across borders.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-3xl font-black text-slate-900 font-sans block">29</span>
                <span className="text-[9px] font-mono font-black text-slate-400 uppercase tracking-widest block mt-1">Countries</span>
              </div>
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-3xl font-black text-blue-600 font-sans block">44</span>
                <span className="text-[9px] font-mono font-black text-slate-400 uppercase tracking-widest block mt-1">Locations</span>
              </div>
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-3xl font-black text-emerald-600 font-sans block">152+</span>
                <span className="text-[9px] font-mono font-black text-slate-400 uppercase tracking-widest block mt-1">Countries Sales</span>
              </div>
            </div>

            <p className="text-xs text-slate-500 font-medium leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200">
              Unlike local reseller companies, Enagic maintains physical corporate office nodes containing support technicians, client viewing galleries, and local distribution yards.
            </p>
          </div>

          {/* Office addresses details */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-3d text-left space-y-6">
            <div>
              <span className="text-[9px] font-mono uppercase font-black text-orange-600 tracking-wider">OFFICE DIRECTORIES (PDF PAGE 3)</span>
              <h3 className="text-xl font-black text-slate-900 mt-0.5">Corporate Headquarters Presence</h3>
              <p className="text-xs text-slate-500 mt-1 font-semibold">
                Direct authorized distributor orders, support tickets, and physical demonstrations are processed at these regional executive centers:
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <Building2 className="h-5 w-5 text-blue-601 mt-1 shrink-0" />
                <div className="space-y-0.5 text-xs text-slate-700">
                  <p className="font-extrabold text-slate-900">Osaka Corporate Sales Center (Japan)</p>
                  <p className="text-slate-500 font-medium font-mono leading-tight">
                    Shin Osaka Yachiyo - BLDG 1F-AB 4Chome 1-45, Miyahara Yodogawa-Ku, Osaka-City, Osaka-City, Japan
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                <Building2 className="h-5 w-5 text-emerald-600 mt-1 shrink-0" />
                <div className="space-y-0.5 text-xs text-slate-700">
                  <p className="font-extrabold text-slate-900">India National Corporate Office (Bangalore)</p>
                  <p className="text-slate-500 font-medium font-mono leading-tight">
                    The Millenia Tower B, 4th Floor, Unit 401, No, 1 and 2, Murphy Road, Ulsoor, Bangalore 560-008 India
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-2 text-center">
              <span className="text-[10px] text-slate-450 font-mono font-bold">Authorized Distributor Association Registry Direct Line</span>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Partner Interest Signup Form */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-3d space-y-8">
          <div className="max-w-2xl mx-auto text-center space-y-2">
            <UserPlus className="h-8 w-8 text-blue-600 mx-auto animate-pulse" />
            <h2 className="text-2xl font-black text-slate-900">Enagic® Business Opportunity Interest Registry</h2>
            <p className="text-xs text-slate-500 font-semibold leading-relaxed">
              If you want to purchase a device or check business distribution rights in your local country, register below to connect with an authorized distributor group near you.
            </p>
          </div>

          <div className="max-w-3xl mx-auto">
            {hasSubmitted ? (
              <div className="text-center py-10 space-y-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <div className="h-12 w-12 rounded-full bg-emerald-100 border border-emerald-450 text-emerald-650 flex items-center justify-center mx-auto text-xl font-bold animate-pulse">
                  ✓
                </div>
                <div className="px-6">
                  <h3 className="font-black text-slate-900 text-lg">Interest Application Received!</h3>
                  <p className="text-xs text-slate-500 mt-2 font-semibold leading-relaxed">
                    Congratulations! Your distributor request has been logged. One of our regional group leads will contact you via email with login links for product demonstrations.
                  </p>
                </div>
                <div className="bg-white border border-slate-200 p-4 max-w-md mx-auto rounded-xl text-left text-xs text-slate-605 font-mono space-y-2 font-semibold shadow-inner">
                  <p id="club-member-id"><strong>Member Ref:</strong> MAGICAL-REF-{Math.floor(Math.random() * 900000 + 100000)}</p>
                  <p><strong>Status:</strong> Pending Credentials Assignment</p>
                  <p><strong>Support Assigned:</strong> {inputs.sponsorName || 'Direct Tokyo Regional Hub'}</p>
                  <p><strong>Participation Objective:</strong> {inputs.interestType === 'both' ? 'Both - Household Option & Business' : inputs.interestType.toUpperCase()}</p>
                </div>
                <button
                  id="reset-join-btn"
                  onClick={resetForm}
                  className="px-5 py-2.5 bg-white border border-slate-200 hover:bg-slate-105 text-blue-600 rounded-lg text-xs font-bold font-sans cursor-pointer transition-colors shadow-xs"
                >
                  Register Another Option
                </button>
              </div>
            ) : (
              <form onSubmit={handleFormSubmit} className="space-y-4 pt-2 font-sans text-left">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Full Name *</label>
                    <input
                      type="text"
                      required
                      name="fullName"
                      value={inputs.fullName}
                      onChange={handleInputChange}
                      placeholder="Enter full name"
                      className="w-full text-xs font-semibold bg-white border border-slate-200 rounded-lg p-3 text-slate-800 focus:outline-[#3b82f6] placeholder:text-slate-400 shadow-sm"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Email Address *</label>
                    <input
                      type="email"
                      required
                      name="email"
                      value={inputs.email}
                      onChange={handleInputChange}
                      placeholder="name@domain.com"
                      className="w-full text-xs font-semibold bg-white border border-slate-200 rounded-lg p-3 text-slate-800 focus:outline-[#3b82f6] placeholder:text-slate-400 shadow-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Phone / WhatsApp Number *</label>
                    <input
                      type="tel"
                      required
                      name="phone"
                      value={inputs.phone}
                      onChange={handleInputChange}
                      placeholder="+91 98765 43210"
                      className="w-full text-xs font-semibold bg-white border border-slate-200 rounded-lg p-3 text-slate-800 focus:outline-[#3b82f6] placeholder:text-slate-400 shadow-sm"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Country of Residence *</label>
                    <input
                      type="text"
                      required
                      name="country"
                      value={inputs.country}
                      onChange={handleInputChange}
                      placeholder="e.g. India, United States, Canada..."
                      className="w-full text-xs font-semibold bg-white border border-slate-200 rounded-lg p-3 text-slate-800 focus:outline-[#3b82f6] placeholder:text-slate-400 shadow-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-semibold">
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Referrer or Sponsor Name (If Any)</label>
                    <input
                      type="text"
                      name="sponsorName"
                      value={inputs.sponsorName}
                      onChange={handleInputChange}
                      placeholder="e.g. independent distributor ID"
                      className="w-full text-xs font-semibold bg-white border border-slate-200 rounded-lg p-3 text-slate-800 focus:outline-[#3b82f6] placeholder:text-slate-400 shadow-sm"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-slate-500 block">Primary Intent *</label>
                    <select
                      name="interestType"
                      value={inputs.interestType}
                      onChange={handleInputChange}
                      className="w-full text-xs font-extrabold bg-white border border-slate-200 rounded-lg p-3 text-slate-800 focus:outline-[#3b82f6] shadow-sm"
                    >
                      <option value="both">Both &mdash; Product User & Business Partner</option>
                      <option value="customer">Customer &mdash; Focus on Drinking Water Only</option>
                      <option value="distributor">Distributor &mdash; Build Passive Referral Network</option>
                    </select>
                  </div>
                </div>

                <div className="pt-4 text-center">
                  <button
                    id="submit-join-form-btn font-black text-center"
                    type="submit"
                    className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs uppercase tracking-wider shadow-btn-3d active:scale-95 transition-all cursor-pointer text-center"
                  >
                    Register Enagic® Business Opportunity Interest
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
