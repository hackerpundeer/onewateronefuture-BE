import React, { useState } from 'react';
import { Award, ShieldCheck, CheckCircle, ChevronDown, ChevronUp } from 'lucide-react';

export default function CertificationsSection() {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <section id="official-certifications-section" className="bg-white py-14 border-t border-b border-slate-200 text-center font-sans relative overflow-hidden">
      {/* Visual top border accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-[3px] bg-blue-500 rounded-b" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Main Title heading matching the image style */}
        <h2 className="text-3xl sm:text-4.5xl font-light text-[#1e40af] tracking-[0.2em] uppercase font-sans">
          CERTIFICATIONS
        </h2>

        {/* Text paragraph matching the image source */}
        <p className="text-slate-600 text-xs sm:text-sm font-medium leading-relaxed max-w-4xl mx-auto px-2">
          Enagic International is certified to <strong className="text-slate-900 font-bold">ISO 9001</strong>, <strong className="text-slate-900 font-bold">ISO 14001</strong>, and <strong className="text-slate-900 font-bold">ISO 13485</strong> for quality control and environmental management, and a member in good standing of the prestigious <strong className="text-slate-900 font-bold">Direct Selling Association</strong>.
        </p>

        {/* Learn More Interactive Link */}
        <div className="pt-1">
          <button
            id="toggle-certifications-details-btn"
            onClick={() => setIsExpanded(!isExpanded)}
            className="inline-flex items-center space-x-1.5 text-blue-600 hover:text-blue-800 text-xs font-bold transition-all hover:underline cursor-pointer focus:outline-none"
          >
            <span>Learn More about our Prestigious Certifications</span>
            {isExpanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          </button>
        </div>

        {/* Interactive expandable information panel */}
        {isExpanded && (
          <div className="max-w-4xl mx-auto bg-slate-50 border border-slate-200 rounded-2xl p-6 text-left space-y-4 animate-fade-in shadow-inner">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 rounded-full bg-amber-500 shrink-0" />
                  <h4 className="font-extrabold text-[#1e40af] text-xs uppercase tracking-wider">ISO 9001 Quality Standard</h4>
                </div>
                <p className="text-[11px] text-slate-500 font-semibold leading-relaxed">
                  Defines stringent operational processes for product design, software integration, development, assembly, and rigorous physical testing of medical hydration devices on-site.
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0" />
                  <h4 className="font-extrabold text-[#10b981] text-xs uppercase tracking-wider">ISO 14001 Green Initiative</h4>
                </div>
                <p className="text-[11px] text-slate-500 font-semibold leading-relaxed">
                  Ensures all manufacturing procedures inside Osaka factories follow safe scrap recovery, environment filters, greenhouse abatement, and sustainable material designs.
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 rounded-full bg-[#3b82f6] shrink-0" />
                  <h4 className="font-extrabold text-blue-650 text-xs uppercase tracking-wider">ISO 13485 Medical Device</h4>
                </div>
                <p className="text-[11px] text-slate-500 font-semibold leading-relaxed">
                  The gold clinical standard authorizing water devices as recognized Medical Equipment, covering sterile parts assembly, clinical biological safety, and electrical stability.
                </p>
              </div>

            </div>

            <div className="border-t border-slate-200/80 pt-3 text-center">
              <span className="inline-block text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
                Official Registered Certificate No: 15309-A (Osaka Factory Division)
              </span>
            </div>
          </div>
        )}

        {/* Gold Medallions Grid */}
        <div id="gold-medallions-container" className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto pt-6">
          
          {/* Medal 1: DSA */}
          <div className="flex flex-col items-center group cursor-pointer">
            <div className="relative transform group-hover:scale-105 group-hover:rotate-2 transition-all duration-300">
              {/* Outer Golden Medallion SVG */}
              <svg className="w-32 h-32 sm:w-36 sm:h-36 drop-shadow-md select-none" viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="goldGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#fef08a" />
                    <stop offset="50%" stopColor="#ca8a04" />
                    <stop offset="100%" stopColor="#854d0e" />
                  </linearGradient>
                  <linearGradient id="goldInner1" x1="100%" y1="100%" x2="0%" y2="0%">
                    <stop offset="0%" stopColor="#fef08a" />
                    <stop offset="40%" stopColor="#eab308" />
                    <stop offset="100%" stopColor="#a16207" />
                  </linearGradient>
                </defs>
                {/* Ribbon back elements */}
                <path d="M40,75 L30,95 L50,85 L70,95 L60,75 Z" fill="#991b1b" stroke="#ca8a04" strokeWidth="1" />
                <path d="M30,95 L35,98 L50,88 L65,98 L70,95 Z" fill="#7f1d1d" opacity="0.6" />
                
                {/* Outermost ruffled circle */}
                <circle cx="50" cy="50" r="41" fill="url(#goldGrad1)" stroke="#854d0e" strokeWidth="1" />
                {/* Inner smooth concentric rings */}
                <circle cx="50" cy="50" r="37" fill="#1e1b4b" stroke="url(#goldGrad1)" strokeWidth="1.5" />
                <circle cx="50" cy="50" r="34" fill="url(#goldInner1)" />
                <circle cx="50" cy="50" r="30" fill="url(#goldGrad1)" />
                <circle cx="50" cy="50" r="28" fill="#ffffff" stroke="#a16207" strokeWidth="0.5" />
                
                {/* DSA Logo shape draft (Home icon inside) */}
                <path d="M50,32 L36,44 L39,44 L39,58 L61,58 L61,44 L64,44 Z" fill="#854d0e" />
                <path d="M47,58 L47,50 L53,50 L53,58 Z" fill="#ffffff" />
                <polygon points="50,28 32,41 35,44 50,33 65,44 68,41" fill="#ca8a04" />
                
                {/* Badge typography text */}
                <text x="50" y="65" textAnchor="middle" fill="#854d0e" fontSize="7" fontWeight="bold" fontFamily="sans-serif" letterSpacing="0.5">DSA</text>
                <text x="50" y="71" textAnchor="middle" fill="#1e293b" fontSize="4.5" fontWeight="black" fontFamily="sans-serif">MEMBER</text>
              </svg>
            </div>
            <h5 className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wider mt-3">DSA APPROVED</h5>
            <p className="text-[9px] text-slate-400 font-bold font-mono">DIRECT SELLING ASSOC.</p>
          </div>

          {/* Medal 2: ISO 9001 */}
          <div className="flex flex-col items-center group cursor-pointer">
            <div className="relative transform group-hover:scale-105 group-hover:rotate-2 transition-all duration-300">
              <svg className="w-32 h-32 sm:w-36 sm:h-36 drop-shadow-md select-none" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="41" fill="url(#goldGrad1)" stroke="#854d0e" strokeWidth="1" />
                <circle cx="50" cy="50" r="37" fill="#ffffff" stroke="url(#goldGrad1)" strokeWidth="1.5" />
                <circle cx="50" cy="50" r="34" fill="url(#goldInner1)" />
                <circle cx="50" cy="50" r="30" fill="#1e3a8a" stroke="#ca8a04" strokeWidth="1" />
                <circle cx="50" cy="50" r="26" fill="url(#goldGrad1)" />
                
                {/* Text elements inside */}
                <text x="50" y="44" textAnchor="middle" fill="#1e293b" fontSize="6.5" fontWeight="extrabold" fontFamily="sans-serif">QUALITY</text>
                <text x="50" y="55" textAnchor="middle" fill="#854d0e" fontSize="10" fontWeight="900" fontFamily="sans-serif" letterSpacing="-0.5">ISO 9001</text>
                <text x="50" y="67" textAnchor="middle" fill="#1e3a8a" fontSize="4.5" fontWeight="bold" fontFamily="sans-serif">CERTIFICATION</text>
                
                {/* Shiny stars */}
                <path d="M50,16 L51.5,20 L55,20 L52,22 L53,26 L50,23 L47,26 L48,22 L45,20 L48.5,20 Z" fill="#ffffff" />
              </svg>
            </div>
            <h5 className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wider mt-3">ISO 9001 QUALITY</h5>
            <p className="text-[9px] text-slate-400 font-bold font-mono">ASSEMBLY STANDARDS</p>
          </div>

          {/* Medal 3: ISO 14001 */}
          <div className="flex flex-col items-center group cursor-pointer">
            <div className="relative transform group-hover:scale-105 group-hover:rotate-2 transition-all duration-300">
              <svg className="w-32 h-32 sm:w-36 sm:h-36 drop-shadow-md select-none" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="41" fill="url(#goldGrad1)" stroke="#854d0e" strokeWidth="1" />
                <circle cx="50" cy="50" r="37" fill="#064e3b" stroke="url(#goldGrad1)" strokeWidth="1.5" />
                <circle cx="50" cy="50" r="34" fill="url(#goldInner1)" />
                <circle cx="50" cy="50" r="30" fill="#065f46" stroke="#ca8a04" strokeWidth="1" />
                <circle cx="50" cy="50" r="26" fill="url(#goldGrad1)" />
                
                <text x="50" y="44" textAnchor="middle" fill="#1e293b" fontSize="6" fontWeight="extrabold" fontFamily="sans-serif">ENVIRONMENT</text>
                <text x="50" y="55" textAnchor="middle" fill="#064e3b" fontSize="9" fontWeight="900" fontFamily="sans-serif" letterSpacing="-0.5">ISO 14001</text>
                <text x="50" y="67" textAnchor="middle" fill="#15803d" fontSize="4.5" fontWeight="bold" fontFamily="sans-serif">GREEN ALLIANCE</text>
                
                {/* Green Leaf outline shape draft */}
                <path d="M50,15 C52,19 55,21 54,24 C53,27 50,28 50,29 C50,28 47,27 46,24 C45,21 48,19 50,15 Z" fill="#ffffff" />
              </svg>
            </div>
            <h5 className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wider mt-3">ISO 14001 ECO</h5>
            <p className="text-[9px] text-slate-400 font-bold font-mono">SUSTAINABLE LOGISTICS</p>
          </div>

          {/* Medal 4: ISO 13485 */}
          <div className="flex flex-col items-center group cursor-pointer">
            <div className="relative transform group-hover:scale-105 group-hover:rotate-2 transition-all duration-300">
              <svg className="w-32 h-32 sm:w-36 sm:h-36 drop-shadow-md select-none" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="41" fill="url(#goldGrad1)" stroke="#854d0e" strokeWidth="1" />
                <circle cx="50" cy="50" r="37" fill="#451a03" stroke="url(#goldGrad1)" strokeWidth="1.5" />
                <circle cx="50" cy="50" r="34" fill="url(#goldInner1)" />
                <circle cx="50" cy="50" r="30" fill="url(#goldGrad1)" />
                <circle cx="50" cy="50" r="26" fill="#1e1b4b" stroke="#ca8a04" strokeWidth="0.5" />
                
                {/* Medical symbol cross inside */}
                <path d="M47,17 H53 V21 H57 V27 H53 V31 H47 V27 H43 V21 H47 Z" fill="url(#goldGrad1)" />
                
                <text x="50" y="47" textAnchor="middle" fill="#ffffff" fontSize="5.5" fontWeight="extrabold" fontFamily="sans-serif">MEDICAL DEVICE</text>
                <text x="50" y="58" textAnchor="middle" fill="url(#goldGrad1)" fontSize="9" fontWeight="950" fontFamily="sans-serif">ISO 13485</text>
                <text x="50" y="68" textAnchor="middle" fill="#94a3b8" fontSize="4.5" fontWeight="medium" fontFamily="sans-serif">FACTORY RATED</text>
              </svg>
            </div>
            <h5 className="font-extrabold text-slate-800 text-[11px] uppercase tracking-wider mt-3">ISO 13485 MEDICAL</h5>
            <p className="text-[9px] text-slate-400 font-bold font-mono">CLINICAL REGISTRY NO.</p>
          </div>

        </div>

      </div>
    </section>
  );
}
