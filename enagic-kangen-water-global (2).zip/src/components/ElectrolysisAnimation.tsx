import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Beaker, Check, Cpu, Filter, Layers, Play, RefreshCw, Sparkles, AlertCircle } from 'lucide-react';

interface ConceptStep {
  title: string;
  subtitle: string;
  bullets: string[];
  color: string;
  icon: React.ReactNode;
}

export default function ElectrolysisAnimation() {
  const [activeStep, setActiveStep] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  // Auto-play iteration helper
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % 4);
    }, 5500);

    return () => clearInterval(interval);
  }, [isPlaying]);

  const stepsData: ConceptStep[] = [
    {
      title: "1. Advanced Bio-Carbon Filtration",
      subtitle: "Purification without removing natural minerals",
      bullets: [
        "Removes heavy metals, chlorine, fluoride, rust, and organic residues.",
        "Crucial: Preserves healthy alkaline minerals (Calcium, Magnesium, Potassium).",
        "Result: Clean, mineral-rich source water ready for electrical restructuring."
      ],
      color: "from-blue-500 to-sky-500",
      icon: <Filter className="h-5 w-5 text-blue-600" />
    },
    {
      title: "2. The Solid Platinum-Titanium Plates",
      subtitle: "Medical-grade titanium with baked platinum plating",
      bullets: [
        "Source water passes over 8 solid, laser-tempered plates.",
        "Medical-grade Platinum and Titanium prevent leaching or biological contamination.",
        "Applies a high-power bio-electrical charge (up to 230 Watts) to initiate ionization."
      ],
      color: "from-blue-600 to-indigo-600",
      icon: <Layers className="h-5 w-5 text-indigo-600" />
    },
    {
      title: "3. Molecular Restructuring (Electrolysis)",
      subtitle: "Splitting H₂O into active species",
      bullets: [
        "Electric currents split water molecules into H⁺ (acidic) and OH⁻ (alkaline) ions.",
        "The negative electrode attracts minerals and releases molecular hydrogen (H₂).",
        "Water molecules cluster bonds are broken and reshaped from large (15-20) to micro (5-6) sizes."
      ],
      color: "from-indigo-600 to-violet-600",
      icon: <Cpu className="h-5 w-5 text-purple-600" />
    },
    {
      title: "4. The Perfect pH Alkaline Outflow",
      subtitle: "Active hydrogen-rich drinking replenishment",
      bullets: [
        "Top nozzle releases alkaline Kangen Drinking Water (high negative-ORP, rich H₂).",
        "Bottom grey hose discharge channels acidic/oxidizing water for antiseptic use.",
        "Instant delivery: Dynamic glass of absolute cell-rejuvenating antioxidant hydration."
      ],
      color: "from-violet-650 to-emerald-600",
      icon: <Sparkles className="h-5 w-5 text-emerald-600" />
    }
  ];

  return (
    <div id="electrolysis-demo-panel" className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 text-slate-800 relative overflow-hidden shadow-3d hover:shadow-3d-hover transition-all">
      {/* Absolute subtle background lights */}
      <div className="absolute top-1/4 left-1/3 h-[250px] w-[250px] bg-blue-100/30 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-12 right-12 h-[200px] w-[200px] bg-purple-100/20 rounded-full blur-3xl pointer-events-none animate-pulse" />

      <div className="flex flex-col lg:flex-row gap-8 items-center relative z-10 text-left">
        {/* LEFT COMPONENT - STUNNING INTERACTIVE VISUAL CANVAS */}
        <div className="w-full lg:w-1/2 flex flex-col items-center">
          <div className="relative w-full aspect-square max-w-[400px] bg-slate-950 rounded-2xl border border-slate-800 p-4 shadow-3xl overflow-hidden">
            
            {/* Visual Glass Header with dynamic statuses */}
            <div className="flex justify-between items-center bg-white/5 border border-white/5 rounded-lg px-3 py-1.5 mb-4 text-[10px] font-mono leading-none">
              <div className="flex items-center space-x-1.5">
                <span className={`h-2 w-2 rounded-full ${isPlaying ? 'bg-emerald-400 animate-ping' : 'bg-amber-450 animate-pulse'}`} />
                <span className="text-slate-400">STATUS: {isPlaying ? "ACTIVE electrolysis" : "SIMULATION PAUSED"}</span>
              </div>
              <span className="text-blue-400 font-bold">CELL SPECTRUM</span>
            </div>

            {/* THE ANIMATION FRAME (PURE SVG WITH GRADIENTS & FLOATING GROUPS) */}
            <div className="relative w-full h-56 flex items-center justify-center">
              <svg viewBox="0 0 400 240" className="w-full h-full">
                <defs>
                  <linearGradient id="waterFlowGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.85" />
                    <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.85" />
                    <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.85" />
                  </linearGradient>
                  
                  <linearGradient id="acidicGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#ef4444" stopOpacity="0.9" />
                    <stop offset="100%" stopColor="#b91c1c" stopOpacity="0.9" />
                  </linearGradient>

                  <linearGradient id="alkalineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#10b981" stopOpacity="0.9" />
                    <stop offset="100%" stopColor="#1e3a8a" stopOpacity="0.9" />
                  </linearGradient>
                </defs>

                {/* 1. INPUT TAP WATER PIPELINE (Left Entrance) */}
                <path d="M 10 120 L 70 120 L 70 80" stroke="url(#waterFlowGrad)" strokeWidth="8" fill="none" strokeLinecap="round" />
                <text x="14" y="105" fill="#38bdf8" fontSize="8" fontWeight="bold" fontFamily="monospace">TAP H₂O</text>

                {/* Moving droplet inside entrance pipeline */}
                {isPlaying && (
                  <circle r="4" fill="#67e8f9">
                    <animateMotion dur="2.5s" repeatCount="indefinite" path="M 10 120 L 70 120 L 70 80" />
                  </circle>
                )}

                {/* 2. DUAL CARBON FILTRATION CHAMBER */}
                <rect x="50" y="40" width="40" height="40" rx="6" fill="#1e293b" stroke="#0891b2" strokeWidth="2" />
                <path d="M 58 52 H 82 M 58 60 H 82 M 58 68 H 82" stroke="#475569" strokeWidth="1" />
                {activeStep === 0 && (
                  <rect x="50" y="40" width="40" height="40" rx="6" fill="none" stroke="#67e8f9" strokeWidth="3" className="animate-pulse" />
                )}
                <text x="70" y="32" textAnchor="middle" fill="#67e8f9" fontSize="8" fontWeight="black" fontFamily="sans-serif">FILTER</text>

                {/* Flow from filter to electrolysis chamber */}
                <path d="M 80 80 L 120 80 L 120 110" stroke="#0ea5e9" strokeWidth="4" fill="none" />
                {isPlaying && (
                  <circle r="2.5" fill="#38bdf8">
                    <animateMotion dur="2s" repeatCount="indefinite" path="M 80 80 L 120 80 L 120 110" />
                  </circle>
                )}

                {/* 3. ELECTROLYSIS CHAMBER (Dual Titanium plates grid) */}
                <rect x="110" y="110" width="160" height="90" rx="8" fill="#111827" stroke="#3b82f6" strokeWidth="1.5" />
                <text x="190" y="102" textAnchor="middle" fill="#38bdf8" fontSize="8" fontWeight="black" fontFamily="sans-serif">ELECTROLYSIS CHAMBER</text>

                {/* Platinum-Titanium plates */}
                {/* Plate A - Positive Cathode Charging Red */}
                <g transform="translate(130, 125)">
                  <rect x="0" y="0" width="8" height="60" rx="2" fill={activeStep >= 2 ? "#ef4444" : "#475569"} className="transition-colors duration-500" />
                  <text x="-4" y="32" fill="#ef4444" fontSize="6" fontWeight="bold" fontFamily="monospace">+</text>
                </g>

                {/* Plate B - Membrane Filter Centre */}
                <line x1="190" y1="115" x2="190" y2="195" stroke="#4b5563" strokeWidth="2" strokeDasharray="3,3" />

                {/* Plate C - Negative Anode Charging Blue */}
                <g transform="translate(240, 125)">
                  <rect x="0" y="0" width="8" height="60" rx="2" fill={activeStep >= 2 ? "#3b82f6" : "#475569"} className="transition-colors duration-500" />
                  <text x="11" y="32" fill="#38bdf8" fontSize="6" fontWeight="bold" fontFamily="monospace">-</text>
                </g>

                {/* Spark / Electric lines animation under chamber */}
                {activeStep >= 2 && isPlaying && (
                  <g>
                    <path d="M 130 115 H 250" stroke="#abf" strokeWidth="1" strokeDasharray="6,4" className="animate-pulse" />
                    <text x="190" y="155" textAnchor="middle" fill="#a855f7" fontSize="16" fontWeight="bold" opacity="0.35" className="animate-pulse">⚡</text>
                  </g>
                )}

                {/* Floating Ionic particles inside electrolysis chamber */}
                {isPlaying && activeStep === 2 && (
                  <g>
                    {/* H+ heading left (acidic) */}
                    <circle cx="160" cy="140" r="3" fill="#ef4444">
                      <animate attributeName="cx" values="180;140;180" dur="2.4s" repeatCount="indefinite" />
                    </circle>
                    <text x="156" y="135" fill="#f87171" fontSize="5" fontWeight="bold">H⁺</text>

                    {/* OH- heading right (alkaline) */}
                    <circle cx="210" cy="165" r="3" fill="#10b981">
                      <animate attributeName="cx" values="190;235;190" dur="2s" repeatCount="indefinite" />
                    </circle>
                    <text x="212" y="160" fill="#a7f3d0" fontSize="5" fontWeight="bold">OH⁻</text>

                    {/* Active Hydrogens bubbles H2 */}
                    <circle cx="225" cy="135" r="2.5" fill="#67e8f9" opacity="0.8">
                      <animate attributeName="cy" values="180;125" dur="1.5s" repeatCount="indefinite" />
                    </circle>
                    <text x="226" y="130" fill="#38bdf8" fontSize="5" fontWeight="bold">H₂</text>
                  </g>
                )}

                {/* 4. DUAL OUTFLOW PIPES */}
                {/* Alkaline Water Top spout curved upwards */}
                <path d="M 250 145 C 290 145, 300 70, 350 70" stroke="url(#alkalineGrad)" strokeWidth="6" fill="none" strokeLinecap="round" />
                {isPlaying && activeStep >= 3 && (
                  <circle r="3.5" fill="#34d399">
                    <animateMotion dur="2.2s" repeatCount="indefinite" path="M 250 145 C 290 145, 300 70, 350 70" />
                  </circle>
                )}
                <text x="360" y="65" textAnchor="end" fill="#34d399" fontSize="8" fontWeight="black" fontFamily="sans-serif">ALKALINE pH 9.5</text>

                {/* Acidic Discharge Bottom Tube */}
                <path d="M 140 185 C 140 220, 290 220, 340 220" stroke="url(#acidicGrad)" strokeWidth="4" fill="none" strokeLinecap="round" />
                {isPlaying && activeStep >= 3 && (
                  <circle r="2.5" fill="#f87171">
                    <animateMotion dur="2.8s" repeatCount="indefinite" path="M 140 185 C 140 220, 290 220, 340 220" />
                  </circle>
                )}
                <text x="360" y="213" textAnchor="end" fill="#f87171" fontSize="7" fontWeight="bold" fontFamily="sans-serif">ACIDIC pH 2.5</text>
              </svg>
            </div>

            {/* Simulated molecular hydrogen H2 indicator */}
            <div className="mt-2 text-center bg-blue-900/60 p-2 rounded-xl border border-blue-800/80">
              <span className="text-[9px] uppercase tracking-wider text-slate-400 block font-mono font-bold">Real-time Ionization Stream</span>
              <p className="text-xs font-bold text-cyan-400 font-sans flex items-center justify-center gap-1">
                <span className="animate-pulse text-cyan-400 text-[10px]">✨</span>
                <span>Active Dissolved H₂: 1.6ppm (Supersaturated Antioxidant)</span>
              </p>
            </div>
          </div>

          {/* PLAY / PAUSE SIMULATION BAR */}
          <div className="flex items-center space-x-3 mt-4">
            <button
              id="pause-simulation-btn"
              onClick={() => setIsPlaying(!isPlaying)}
              className="py-1.5 px-3 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center space-x-1 border border-slate-250 cursor-pointer shadow-xs transition-colors"
            >
              <Play className={`h-3 w-3 ${isPlaying ? 'rotate-90 text-amber-500' : 'text-emerald-600'}`} />
              <span>{isPlaying ? "Pause Stream" : "Resume Stream"}</span>
            </button>
            <button
              id="reset-simulation-btn"
              onClick={() => {
                setActiveStep(0);
                setIsPlaying(true);
              }}
              className="py-1.5 px-3 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-bold flex items-center space-x-1 border border-blue-200 cursor-pointer shadow-xs transition-colors"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Reset Flow</span>
            </button>
          </div>
        </div>

        {/* RIGHT COMPONENT - DETAILED EXPLAINER CONTENT BAR */}
        <div className="w-full lg:w-1/2 flex flex-col justify-between self-stretch font-sans">
          <div className="space-y-4">
            <div className="space-y-1">
              <span className="text-[10px] text-blue-600 font-mono font-black tracking-widest uppercase block">ENAGIC PRECISION PRINCIPLES</span>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                How Kangen Ionization Restores Water Vitality
              </h3>
              <p className="text-xs text-slate-500 font-semibold leading-relaxed">
                Click a stage below to study the step-by-step technological mechanism. Learn how pristine Japanese engineering changes tap water into molecular medicine.
              </p>
            </div>

            {/* Quick stages clickable bar */}
            <div className="grid grid-cols-4 gap-2 pt-1 font-bold">
              {stepsData.map((step, idx) => {
                const isActive = activeStep === idx;
                return (
                  <button
                    id={`ionizer-step-btn-${idx}`}
                    key={idx}
                    onClick={() => {
                      setActiveStep(idx);
                      setIsPlaying(false); // Pause auto iteration on manual select
                    }}
                    className={`py-2 px-2 rounded-xl text-center border capitalize font-black text-[10px] transition-all cursor-pointer ${
                      isActive
                        ? 'bg-blue-50 border-blue-400 text-blue-700 shadow-xs scale-102'
                        : 'bg-white border-slate-200 text-slate-405 hover:text-slate-800 hover:bg-slate-50'
                    }`}
                  >
                    Stage {idx + 1}
                  </button>
                );
              })}
            </div>

            {/* Active explanation content viewport */}
            <div className="min-h-[175px] bg-slate-50 border border-slate-205 p-5 rounded-2xl relative overflow-hidden flex flex-col justify-between shadow-inner">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeStep}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <span className="p-1.5 bg-white rounded-lg border border-slate-200 shrink-0 shadow-xs">
                      {stepsData[activeStep].icon}
                    </span>
                    <div>
                      <h4 className="text-sm font-black text-slate-900 leading-tight">{stepsData[activeStep].title}</h4>
                      <p className="text-[10px] text-slate-450 uppercase font-mono tracking-wider font-extrabold">{stepsData[activeStep].subtitle}</p>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-2.5 border-t border-slate-200">
                    {stepsData[activeStep].bullets.map((bullet, idx) => (
                      <p key={idx} className="text-xs text-slate-600 flex items-start space-x-2 font-semibold leading-relaxed">
                        <span className="text-blue-600 shrink-0 mt-0.5 font-bold">✓</span>
                        <span>{bullet}</span>
                      </p>
                    ))}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 mt-4 flex items-center justify-between text-[10px] text-slate-400 font-mono font-black uppercase">
            <span className="flex items-center space-x-1">
              <Beaker className="h-3.5 w-3.5 text-indigo-550 text-indigo-600" />
              <span>TiO₂/Pt Dual Chamber Standard</span>
            </span>
            <span>Japan OEM Spec Certified</span>
          </div>
        </div>
      </div>
    </div>
  );
}
