import React, { useEffect } from 'react';
import { FileText, Scale, CheckCircle, AlertTriangle, AlertCircle } from 'lucide-react';

export default function TermsConditionsView() {
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <div id="terms-conditions-viewport" className="py-12 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Hero Card */}
        <div className="bg-white border border-slate-205 rounded-2xl p-8 shadow-3d hover:shadow-3d-hover transition-all text-center space-y-4 mb-8">
          <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-blue-50 border border-blue-200 text-blue-600 mb-2">
            <Scale className="h-6 w-6" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Terms & Conditions</h1>
          <p className="text-xs text-slate-500 font-mono font-bold tracking-wider uppercase">
            Effective Date: June 15, 2026 | Last Updated: June 15, 2026
          </p>
          <p className="text-slate-500 text-xs font-semibold max-w-xl mx-auto leading-relaxed">
            By utilizing our digital platform, you agree to comply with and be bound by the following comprehensive terms. Please read these parameters carefully.
          </p>
        </div>

        {/* Polished Sectioned Card Layout */}
        <div className="bg-white border border-slate-205 rounded-2xl p-8 sm:p-10 shadow-3d text-left space-y-8">
          
          {/* Agreement to Terms */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">01.</span>
              <span>Acceptance of Agreement</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              By accessing, browsing, or entering inputs into the One Water One Future digital platform, you acknowledge that you have read, understood, and agreed to be legally bound to these guidelines. If you do not accept these criteria, you are kindly advised to stop utilizing this platform immediately.
            </p>
          </div>

          {/* Independent Distributor Disclaimer */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2 flex-wrap">
              <span className="text-blue-600 font-mono mr-2">02.</span>
              <span>Independent Distributor Statement</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              This website is published and managed by independent registered distributors of Enagic® USA / Japan under official authorized IDs.
            </p>
            <div className="bg-amber-50 border border-amber-250 p-4 rounded-xl text-xs text-amber-900 flex items-start space-x-2.5 font-semibold">
              <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
              <span>
                <strong>Official Clarification:</strong> We provide educational material regarding pH science, alkaline properties, and the patented 8-point compensation system. The content here is not directly authored by Enagic® Corporate, but is strictly in compliance with distributor communication regulations and guidelines.
              </span>
            </div>
          </div>

          {/* No Medical Claims Disclaimer */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">03.</span>
              <span>Proprietary Medical Disclaimer</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              The water restructuring equipment listed on this website is classified as a Medical Device inside Japan by the Japanese Ministry of Health, Labour and Welfare (Registry No: 21500BZZ00261000). However:
            </p>
            <ul className="list-none space-y-2 mt-2 pl-2">
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>We do not diagnose, treat, prevent, or cure any clinical diseases.</span>
              </li>
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>Therapeutic water ionization provides high molecular hydrogen antioxidants and metabolic pH-buffering supporting homeostasis, but should never override direct directions from registered medical practitioner doctors.</span>
              </li>
            </ul>
          </div>

          {/* Demo Booking Policies */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">04.</span>
              <span>Google Calendar Demo Booking</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              When scheduling a physical or virtual live demonstration (with automatic Google Calendar integration slots and 2 hours separation margins):
            </p>
            <ul className="list-none space-y-2 mt-1 pl-2">
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>You agree to offer authentic, accurate identity parameter fields (Name, Phone number, Email address).</span>
              </li>
              <li className="flex items-start space-x-2 text-xs font-semibold text-slate-650">
                <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0" />
                <span>We retain the full authority to reschedule or deny requests originating from false or empty input fields.</span>
              </li>
            </ul>
          </div>

          {/* Intellectual Propriety */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">05.</span>
              <span>Intellectual Intellectual Rights</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              Enagic®, Kangen Water®, LeveLuk®, and Anespa® are legally registered trademarks of Enagic® Co., Ltd. All other assets, custom electrolysis animations, layouts, and biochemical materials are copyrighted by our design team. Re-transmitting or capturing assets for third-party commercial sales is prohibited without pre-authorization.
            </p>
          </div>

          {/* Liability Limits */}
          <div className="space-y-3">
            <h2 className="text-lg font-extrabold text-slate-900 flex items-center space-x-2 border-b border-slate-100 pb-2">
              <span className="text-blue-600 font-mono">06.</span>
              <span>Limitation of Liability</span>
            </h2>
            <p className="text-xs text-slate-650 leading-relaxed font-semibold">
              Under no circumstances shall we be held responsible for direct, indirect, random, or secondary damages resulting from machine configurations, filter replacements, or water type misapplications done without reading official operator user manuals.
            </p>
          </div>
        </div>

        {/* Footer Support Notice */}
        <div className="mt-8 text-center text-[11px] font-bold text-slate-400">
          Have queries regarding legal terms? Contact our administrative body at <span className="text-blue-600 font-sans">legal@onewateronefuture.org</span>
        </div>

      </div>
    </div>
  );
}
