import React, { useState } from 'react';
import { GLOBAL_OFFICES } from '../data';
import { MapPin, Globe, Video, Calendar, ShieldCheck, Cpu, Star, HeartPulse, Sparkles, Coins, HelpCircle, Play } from 'lucide-react';
import CertificationsSection from './CertificationsSection';

import japaneseManufacturing from '../assets/images/japanese_manufacturing_1779402725808.png';

export default function AboutView() {
  const [selectedRegion, setSelectedRegion] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeVisionTab, setActiveVisionTab] = useState<string>('physical');
  const [ceoImage, setCeoImage] = useState<string>('https://drive.google.com/thumbnail?id=1vZ_s1ZKrg6DPacHN2NO1itm_cnzq1fBJ&sz=w1000');
  const [isSymposiumPlaying, setIsSymposiumPlaying] = useState<boolean>(false);

  const regions = ['All', 'Americas', 'Europe', 'Asia-Pacific', 'Middle East & Africa'];

  // Filter based on region and search query
  const filteredOffices = GLOBAL_OFFICES.filter((office) => {
    const matchesRegion = selectedRegion === 'All' || office.region === selectedRegion;
    const matchesSearch = office.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          office.city.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesRegion && matchesSearch;
  });

  return (
    <div id="about-us-view" className="pb-16 bg-[#f8fafc] text-slate-800 space-y-12 relative overflow-hidden font-sans">
      
      {/* Background blurs for elevated theme */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[10%] right-[5%] w-80 h-80 rounded-full bg-blue-105/30 blur-3xl" />
        <div className="absolute bottom-[30%] left-[2%] w-96 h-96 rounded-full bg-cyan-100/30 blur-3xl" />
      </div>

      {/* 1. Header Section */}
      <section className="relative pt-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 max-w-3xl mx-auto">
          <span className="text-[10px] uppercase tracking-widest font-black text-blue-600 bg-blue-100/60 px-3.5 py-1.5 rounded-full border border-blue-200">
            JAPANESE HERITAGE & WORLDWIDE REACH
          </span>
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 leading-tight">
            About Enagic® & <br />
            <span className="bg-gradient-to-r from-blue-600 via-sky-600 to-indigo-650 bg-clip-text text-transparent italic font-serif">
              Our Hardworking Kangen Team
            </span>
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm font-semibold leading-relaxed max-w-xl mx-auto">
            Harnessing the rigorous medical-grade standards of original equipment manufacturing inside our Osaka facilities, we power global health networks in over 27 countries.
          </p>
        </div>
      </section>

      {/* 2. Classy CEO Vision Hero Section (Hironari Ohshiro) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2 text-left">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0b1329] via-[#0f172a] to-[#020617] border border-slate-800 p-8 sm:p-12 shadow-2xl text-slate-100 mb-12">
          
          {/* Subtle gold decoration ring */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
            
            {/* Visual Column: Portrait and Badge */}
            <div className="lg:col-span-12 xl:col-span-5 flex flex-col items-center">
              <div className="relative group max-w-[340px] w-full">
                {/* Glowing border effect */}
                <div className="absolute -inset-1.5 rounded-2xl bg-gradient-to-r from-amber-400 via-blue-500 to-indigo-500 opacity-60 blur-lg group-hover:opacity-85 transition-opacity" />
                
                <div className="relative bg-[#0d1527] border border-slate-700/80 p-4 rounded-2xl shadow-2xl text-center">
                  <div className="h-68 rounded-xl overflow-hidden bg-slate-950 relative border border-slate-800">
                    <img
                      referrerPolicy="no-referrer"
                      src={ceoImage}
                      alt="Hironari Ohshiro, Founder & CEO of Enagic"
                      className="h-full w-full object-cover object-top transform scale-100 group-hover:scale-105 transition-transform duration-700 opacity-95"
                      onError={() => {
                        console.warn("Direct image load failed for CEO portrait. Falling back to default manufacturing rendering.");
                        setCeoImage(japaneseManufacturing);
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/30 to-slate-950/20" />
                    
                    {/* Floating gold crest */}
                    <div className="absolute top-3 left-3 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 text-[8px] font-black tracking-widest px-2 py-0.5 rounded uppercase">
                      Est. Okinawa 1974
                    </div>

                    <div className="absolute bottom-4 left-4 right-4 text-left space-y-1">
                      <span className="text-[9px] font-mono font-black text-amber-400 uppercase tracking-widest block">FOUNDER & CEO</span>
                      <h4 className="font-serif font-black text-white text-lg tracking-wide leading-tight">Hironari Ohshiro</h4>
                      <p className="text-[10px] text-slate-400 font-bold leading-none">Okinawa & Osaka Global Leadership</p>
                    </div>
                  </div>

                  {/* Classy gold trim quote */}
                  <div className="mt-4 pt-1 border-t border-slate-800">
                    <p className="text-[10.5px] italic text-amber-200/90 leading-relaxed font-medium">
                      &ldquo;Return to Origin: Restoring our cells is the root of physiological liberty.&rdquo;
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Editorial / Message Column */}
            <div className="lg:col-span-12 xl:col-span-7 space-y-6">
              
              <div className="inline-flex items-center space-x-2 bg-amber-500/10 border border-amber-500/30 rounded-full px-3 py-1">
                <Sparkles className="h-3.5 w-3.5 text-amber-400 shrink-0" />
                <span className="text-[10px] font-mono tracking-widest font-black uppercase text-amber-300">
                  THE REALIZATION OF TRUE HEALTH
                </span>
              </div>

              <h2 className="text-3xl sm:text-4.5xl font-extrabold tracking-tight text-white font-sans leading-tight">
                Change Your Water, <br />
                <span className="bg-gradient-to-r from-amber-300 via-amber-200 to-yellow-400 bg-clip-text text-transparent italic font-serif">
                  Change Your Life!®
                </span>
              </h2>

              <p className="text-slate-350 text-xs sm:text-sm leading-relaxed font-semibold">
                Our vision at Enagic International is founded on three simple yet absolute physiological and socioeconomic milestones. By uniting physical optimization, premium commission safeguards, and spiritual community ties, we represent a lifelong home for holistic well-being.
              </p>

              {/* Three True Healths Interactive Tab Showcase */}
              <div className="grid grid-cols-3 gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveVisionTab('physical')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    activeVisionTab === 'physical'
                      ? 'bg-amber-500/15 border-amber-400 text-white shadow-lg'
                      : 'bg-slate-900/45 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <HeartPulse className="h-4.5 w-4.5 text-amber-400 mb-1.5" />
                  <span className="text-[10.5px] font-black uppercase tracking-wider block">01. Physical</span>
                  <span className="text-[9px] text-slate-500 font-bold block mt-0.5">Cellular Body</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveVisionTab('financial')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    activeVisionTab === 'financial'
                      ? 'bg-amber-500/15 border-amber-400 text-white shadow-lg'
                      : 'bg-slate-900/45 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Coins className="h-4.5 w-4.5 text-amber-400 mb-1.5" />
                  <span className="text-[10.5px] font-black uppercase tracking-wider block">02. Financial</span>
                  <span className="text-[9px] text-slate-500 font-bold block mt-0.5">8-Point Plan</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveVisionTab('spiritual')}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    activeVisionTab === 'spiritual'
                      ? 'bg-amber-500/15 border-amber-400 text-white shadow-lg'
                      : 'bg-slate-900/45 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <Sparkles className="h-4.5 w-4.5 text-amber-400 mb-1.5" />
                  <span className="text-[10.5px] font-black uppercase tracking-wider block">03. Spiritual</span>
                  <span className="text-[9px] text-slate-500 font-bold block mt-0.5">Peace of Mind</span>
                </button>
              </div>

              {/* Dynamic message content card */}
              <div className="bg-[#111c36]/90 border border-[#233355]/60 p-4.5 rounded-xl text-left text-xs sm:text-[13px] leading-relaxed font-medium text-slate-300 animate-fade-in shadow-inner min-h-[90px]">
                {activeVisionTab === 'physical' && (
                  <p>
                    <strong className="text-white">True Physical Health:</strong> We eliminate chlorine and harmful chemical additives, delivering pristine, antioxidant-rich active hydrogen properties that counteract biological aging trends. Kangen Water is more than just filtered water—it is structured cellular optimization.
                  </p>
                )}
                {activeVisionTab === 'financial' && (
                  <p>
                    <strong className="text-white">True Financial Health:</strong> Enagic rewards proactive advocacy. Our patented, multi-tier <strong className="text-amber-300 font-bold">8-Point Compensation Structure</strong> bypasses advertising conglomerates, placing maximum payouts directly in the pockets of independent working distributors.
                  </p>
                )}
                {activeVisionTab === 'spiritual' && (
                  <p>
                    <strong className="text-white">True Mental & Spiritual Peace:</strong> Inner stillness is realized when our health is fully secured and our families are prosperous. Enagic fosters a global family environment in over 23 global centers, building circles of confidence and shared well-being.
                  </p>
                )}
              </div>

              {/* Signature Block */}
              <div className="pt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-t border-slate-800">
                <blockquote className="italic text-[11px] text-slate-400 max-w-sm">
                  &ldquo;A healthy lifestyle is built on a foundation of clean water, clear financial integrity, and a peaceful spirit.&rdquo;
                </blockquote>
                <div className="text-right">
                  <p className="font-serif italic text-amber-200 text-sm leading-none">Hironari Ohshiro</p>
                  <p className="text-[9px] font-mono text-slate-500 font-black uppercase tracking-widest mt-1">Founder, Enagic Co., Ltd.</p>
                  <a 
                    href="https://www.enagic.com/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-[9.5px] font-mono text-blue-400 hover:text-blue-300 font-bold block mt-1.5 transition-colors"
                  >
                    www.enagic.com &rarr;
                  </a>
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* Replicated Certifications Section matching attached photo */}
      <CertificationsSection />

      {/* 3. Global Hardworking Presentations Hub */}
      <section className="bg-white py-12 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center font-sans">
            
            {/* Team details */}
            <div className="lg:col-span-5 space-y-6 text-left">
              <span className="text-[10px] font-mono tracking-widest uppercase text-blue-600 font-black bg-blue-50 px-3 py-1.5 rounded-full border border-blue-200">
                ACTIVE ADVOCACY IN YOUR MARKET
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight text-slate-900 leading-tight">
                How Our Kangen Team <br />
                <span className="bg-gradient-to-r from-blue-600 to-sky-600 bg-clip-text text-transparent italic font-serif">Demonstrates Globally</span>
              </h2>
              <p className="text-slate-500 text-xs leading-relaxed font-semibold">
                Our collaborative distributor networks hold presentations daily to explain properties of active hydrogen water, providing verified clinical benchmarks and explaining healthy hydration.
              </p>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 bg-slate-50 p-3.5 border border-slate-200 rounded-xl shadow-xs">
                  <Video className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-xs text-left leading-tight">Daily Live Scientific Webinars (VC)</h4>
                    <p className="text-[11px] text-slate-500 leading-relaxed text-left mt-1 font-semibold">
                      New interested visitors learn how systemic acidity stresses human metabolism. Live pH drop tests and organic emulsification tests are broadcast globally.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 bg-slate-50 p-3.5 border border-slate-200 rounded-xl shadow-xs">
                  <Calendar className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-xs text-left leading-tight">Collaborative Leadership Workshops</h4>
                    <p className="text-[11px] text-slate-500 leading-relaxed text-left mt-1 font-semibold">
                      Distributors of the Kangen Club meet to plan educational field tours, share demonstration guidelines, and support global customer orders seamlessly.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Video Call visual Mockup styled as light premium panel */}
            <div className="lg:col-span-7 w-full relative">
              <div className="absolute inset-0 bg-blue-100/30 rounded-3xl filter blur-3xl pointer-events-none" />
              <div className="relative bg-white border border-slate-205 rounded-xl p-6 shadow-3d">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                  <div className="flex items-center space-x-2">
                    <span className="h-3 w-3 rounded-full bg-red-500 animate-pulse" />
                    <span className="text-xs text-slate-900 font-mono font-black uppercase tracking-wider">LIVE VIRTUAL SYMPOSIUM</span>
                  </div>
                  <span className="text-[10px] bg-slate-50 text-slate-500 px-6 py-0.5 rounded font-mono font-bold">152 active connections</span>
                </div>

                {/* Virtual Call Mockup Box */}
                <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-4">
                  {isSymposiumPlaying ? (
                    <div className="h-60 sm:h-80 md:h-[400px] bg-slate-900 rounded-lg relative overflow-hidden shadow-inner border border-slate-800">
                      <iframe
                        src="https://www.youtube.com/embed/nTR4LQiFCqk?autoplay=1&rel=0"
                        title="Enagic Kangen Water Demonstration Video"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                        className="h-full w-full rounded-lg"
                      ></iframe>
                      <button 
                        onClick={() => setIsSymposiumPlaying(false)}
                        className="absolute bottom-2 right-2 bg-black/80 hover:bg-black text-[9px] font-mono font-bold text-white px-2 py-1 rounded border border-white/20 transition-all cursor-pointer z-10"
                      >
                        Reset Screen
                      </button>
                    </div>
                  ) : (
                    <div 
                      onClick={() => setIsSymposiumPlaying(true)}
                      className="h-60 sm:h-80 md:h-[400px] bg-slate-900 rounded-lg relative overflow-hidden flex items-center justify-center cursor-pointer group/video hover:bg-slate-850/90 transition-colors"
                      title="Click to play Enagic Live Symposium Video"
                    >
                      {/* Speaker info */}
                      <div className="text-center p-4 transition-transform duration-300 group-hover/video:scale-95 opacity-40 group-hover/video:opacity-20">
                        <div className="h-10 w-10 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-500 mx-auto mb-2 flex items-center justify-center font-bold text-sm text-white relative">
                          KT
                          <div className="absolute -bottom-1 -right-1 bg-blue-600 border border-slate-950 p-0.5 rounded-full text-white shadow-lg">
                            <Play className="h-1.5 w-1.5 fill-current" />
                          </div>
                        </div>
                        <p className="text-xs text-white font-bold leading-none">Osaka Support Presenter</p>
                        <p className="text-[10px] text-cyan-405 mt-1 font-semibold">Active pH Reactant Indicators</p>
                      </div>

                      {/* Pulse Play Ring & Play Icon Button Overlay - Permanently Visible */}
                      <div className="absolute inset-0 bg-black/10 flex items-center justify-center transition-colors duration-300 group-hover/video:bg-black/30">
                        <div className="relative flex items-center justify-center">
                          <span className="absolute inline-flex h-16 w-16 rounded-full bg-blue-500/25 animate-pulse" />
                          <span className="absolute inline-flex h-24 w-24 rounded-full bg-blue-500/10 animate-ping duration-1000" />
                          <div className="relative bg-blue-650 hover:bg-blue-700 text-white p-4 rounded-full shadow-2xl transform scale-100 group-hover/video:scale-110 transition-transform duration-300 border border-blue-400 flex items-center justify-center">
                            <Play className="h-6 w-6 fill-current text-white ml-1" />
                          </div>
                        </div>
                      </div>

                      {/* Click helper badge */}
                      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-3.5 py-1.5 rounded-full text-[9px] font-mono font-black tracking-wider uppercase flex items-center space-x-1.5 border border-blue-500/30 shadow-lg shadow-blue-600/30 transition-all duration-300 group-hover/video:scale-105 group-hover/video:bg-blue-500">
                        <Play className="h-2.5 w-2.5 fill-current text-white animate-pulse" />
                        <span>Play Video Demo</span>
                      </div>

                      {/* Live indicator overlay */}
                      <div className="absolute top-2 right-2 bg-blue-600 text-[8px] text-white px-1.5 py-0.5 rounded uppercase font-extrabold tracking-widest font-mono flex items-center space-x-1">
                        <span className="h-1.5 w-1.5 rounded-full bg-red-400 animate-ping" />
                        <span>LIVE STREAM DEMO</span>
                      </div>
                    </div>
                  )}


                </div>

                <div className="mt-4 text-center">
                  <p className="text-[11px] text-blue-600 italic font-bold leading-relaxed">
                    &ldquo;Our team coordinates daily calls. Together we carry out the message of true metabolic wealth globally!&rdquo;
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 4. Interactive Global Offices Search/Filter Directory */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 space-y-6 text-left">
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <Globe className="h-8 w-8 text-blue-600 mx-auto animate-pulse" />
          <h2 className="text-2xl font-black text-slate-900">Enagic Worldwide Offices & Logistics Directory</h2>
          <p className="text-xs text-slate-500 font-semibold leading-relaxed">
            All devices ship directly from authorized centers. Search by country or select a region below to locate physical distributor check-in channels.
          </p>
        </div>

        {/* Filters and search input */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          {/* Region Tabs */}
          <div className="flex flex-wrap gap-1.5 w-full sm:w-auto">
            {regions.map((region) => (
              <button
                id={`region-tab-${region}`}
                key={region}
                onClick={() => setSelectedRegion(region)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition-all ${
                  selectedRegion === region
                    ? 'bg-blue-605 bg-blue-600 text-white shadow shadow-blue-500/10'
                    : 'bg-slate-50 border border-slate-200 text-slate-600 hover:text-slate-800 hover:bg-slate-100'
                }`}
              >
                {region}
              </button>
            ))}
          </div>

          {/* Search box */}
          <div className="relative w-full sm:max-w-xs">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3">
              <MapPin className="h-4 w-4 text-slate-400" />
            </span>
            <input
              type="text"
              placeholder="Search by country or city..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-white border border-slate-200 rounded-lg pl-9 pr-3 py-2 text-slate-800 focus:outline-none focus:border-blue-500 shadow-sm font-bold"
            />
          </div>
        </div>

        {/* Global offices grid results */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {filteredOffices.length > 0 ? (
            filteredOffices.map((office, idx) => (
              <div
                key={idx}
                className="bg-white border border-slate-201/80 p-4.5 rounded-xl flex items-start space-x-3 hover:border-blue-400 transition-all shadow-3d hover:shadow-3d-hover"
              >
                <div className="h-8 w-8 rounded-lg bg-blue-50 flex items-center justify-center shrink-0 border border-blue-200 text-blue-600 font-bold uppercase font-mono text-xs">
                  {office.country.substring(0, 2)}
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-xs leading-none">{office.city}</h4>
                  <p className="text-[10px] text-slate-500 font-bold mt-1">{office.country}</p>
                  <span className="inline-block px-1.5 py-0.5 rounded bg-blue-50 text-[8px] font-bold text-blue-700 uppercase tracking-widest mt-1.5">
                    {office.region}
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-1 sm:col-span-2 md:col-span-4 text-center py-10 bg-white rounded-xl border border-dashed border-slate-250">
              <p className="text-slate-400 text-xs font-semibold">No global offices matching your search filters were located.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
