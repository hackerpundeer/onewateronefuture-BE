export interface Celebrity {
  id: string;
  name: string;
  role: string;
  quote: string;
  image: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  location: string;
  text: string;
  rating: number;
}

export interface EnagicOffice {
  country: string;
  city: string;
  region: 'Americas' | 'Europe' | 'Asia-Pacific' | 'Middle East & Africa';
}

export interface WaterType {
  id: string;
  name: string;
  ph: string;
  color: string;
  description: string;
  uses: string[];
  imageDesc: string;
}

export interface ClubSignupInput {
  fullName: string;
  email: string;
  phone: string;
  country: string;
  sponsorName: string;
  interestType: 'both' | 'customer' | 'distributor';
}

export interface DemoBookingInput {
  fullName: string;
  email: string;
  phone: string;
  country: string;
  demoType: 'zoom' | 'in-person' | 'office-visit';
  preferredDate: string;
  preferredTime: string;
  message: string;
}
